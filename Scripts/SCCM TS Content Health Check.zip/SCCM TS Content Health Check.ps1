<#
.SYNOPSIS
    GUI tool to find and redistribute FAILED content (Packages, Driver Packages,
    Boot Images, OS Images, Applications) belonging to a Task Sequence, per-DP,
    without having to walk the Content Status node manually for every site.

.NOTES
    Author: Eswar (SCCM/Intune MVP)
    Date: 23-Aug-2026
    Requires: ConfigMgr console installed (ConfigurationManager.psd1), and rights
              to query SMS Provider + trigger redistribution.

    VERIFY BEFORE PRODUCTION USE ON A LARGE HIERARCHY
      - SMS_PackageStatusDistPointsSummarizer.State mapping (package-type content)
        is stable across CM builds:
            0 = Installed (Success)
            1 = Install Pending
            2 = Install Retrying
            3 = Install Failed          <-- treated as FAILED
            4 = Removal Pending
            5 = Removal Retrying
            6 = Removal Failed          <-- treated as FAILED
            7 = Content Updating
            8 = Content Monitoring
      - Application content status uses a different code path (apps are keyed by
        Content Unique ID, not PackageID). This script queries SMS_DPContentInfo
        first and falls back to SMS_CIContentStatus-style parsing if that returns
        nothing on your site. Test against one known-failed app before bulk use.

#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ----------------------------------------------------------------------------
# CONFIG - Prompts for Site Code and Site Server
# ----------------------------------------------------------------------------
Add-Type -AssemblyName Microsoft.VisualBasic

# Function to prompt for Site Code
function Get-UserInput {
    param([string]$Prompt, [string]$Title, [string]$DefaultValue = "")

    $input = [Microsoft.VisualBasic.Interaction]::InputBox($Prompt, $Title, $DefaultValue)
    return $input.Trim()
}

# Prompt for the Site Code
$SiteCode = Get-UserInput -Prompt "Please enter your 3-character SCCM Site Code (e.g., CM1):" -Title "SCCM Connection - Site Code" -DefaultValue ""

# If they cancel or leave it blank, exit gracefully
if ([string]::IsNullOrWhiteSpace($SiteCode)) {
    [System.Windows.Forms.MessageBox]::Show("No Site Code entered. Script will exit.", "Cancelled", 'OK', 'Warning') | Out-Null
    exit
}

# Prompt for the Site Server (SMS Provider)
$SiteServer = Get-UserInput -Prompt "Please enter the FQDN of your SMS Provider / Site Server (e.g., SG-CM01.contoso.com):" -Title "SCCM Connection - Site Server" -DefaultValue ""

# If they cancel or leave it blank, exit gracefully
if ([string]::IsNullOrWhiteSpace($SiteServer)) {
    [System.Windows.Forms.MessageBox]::Show("No Site Server entered. Script will exit.", "Cancelled", 'OK', 'Warning') | Out-Null
    exit
}

# Suppress Fast check warning
$CMPSSuppressFastNotUsedCheck = $true

# ----------------------------------------------------------------------------
# LOGGING SETUP
# ----------------------------------------------------------------------------
# Creates a log file in the current directory (or temp if cannot write)
$script:LogFilePath = Join-Path (Split-Path $MyInvocation.MyCommand.Path -ErrorAction SilentlyContinue) "TS-ContentRedistribute.log"
if ([string]::IsNullOrWhiteSpace($script:LogFilePath)) { $script:LogFilePath = Join-Path $env:TEMP "TS-ContentRedistribute.log" }

function Log-Message {
    param([Parameter(Mandatory)][string]$Message)
    $TimeStamp = Get-Date -Format "MM/dd/yyyy HH:mm:ss"
    $LogLine = "[$TimeStamp] $Message"

    # Write to log file
    try {
        Add-Content -Path $script:LogFilePath -Value $LogLine -ErrorAction SilentlyContinue
    } catch {}

    # Write to console
    Write-Host $LogLine
}

Log-Message "=================================================="
Log-Message "Script started. Site: $SiteCode, Server: $SiteServer"
Log-Message "Log file will be written to: $script:LogFilePath"
Log-Message "=================================================="

# ----------------------------------------------------------------------------
# Connect to ConfigMgr module / PSDrive
# ----------------------------------------------------------------------------
function Connect-CMSite {
    if (-not (Get-Module ConfigurationManager)) {
        $cmModulePath = Join-Path $(Split-Path $env:SMS_ADMIN_UI_PATH) 'ConfigurationManager.psd1'
        if (Test-Path $cmModulePath) {
            Import-Module $cmModulePath -ErrorAction Stop
        } else {
            [System.Windows.Forms.MessageBox]::Show("Could not locate ConfigurationManager.psd1. Run this from a machine with the CM console installed.", "Error", 'OK', 'Error') | Out-Null
            exit 1
        }
    }
    if (-not (Get-PSDrive -Name $SiteCode -ErrorAction SilentlyContinue)) {
        try {
            New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $SiteServer -Description "SCCM Site" -ErrorAction Stop | Out-Null
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to connect to Site '$SiteCode' on Server '$SiteServer'. Check your Site Code and Server Name.`r`n`r`nError: $($_.Exception.Message)", "Connection Error", 'OK', 'Error') | Out-Null
            exit 1
        }
    }
    Set-Location "$($SiteCode):"
    Log-Message "Connected to ConfigMgr site '$SiteCode'."
}


# ----------------------------------------------------------------------------
# RECURSIVE: Get all references from a TS, including child Task Sequences
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# RECURSIVE: Get all references from a TS, including child Task Sequences
# ----------------------------------------------------------------------------
function Get-TSDeepReferences {
    param([Parameter(Mandatory)][string]$TaskSequenceId, [System.Collections.Generic.HashSet[string]]$SeenTSIds)

    if (-not $SeenTSIds) { $SeenTSIds = [System.Collections.Generic.HashSet[string]]::new() }

    if (-not $SeenTSIds.Add($TaskSequenceId)) { return @() }

    Write-Host "  Scanning Task Sequence: $TaskSequenceId..."

    try {
        $tsObject = Get-CMTaskSequence -TaskSequencePackageId $TaskSequenceId -ErrorAction Stop
    } catch {
        Write-Host "    ERROR: Could not load TS $TaskSequenceId"
        return @()
    }

    $items = @()

    if ($tsObject.References) {
        foreach ($r in $tsObject.References) {
            $pkgId = ([string]$r.Package).Trim()
            if ($pkgId -match '^[0-9A-Za-z]{3}[0-9A-F]{5}$') {
                $isTS = $false
                try {
                    $checkTS = Get-CMTaskSequence -TaskSequencePackageId $pkgId -Fast -ErrorAction SilentlyContinue
                    if ($checkTS) { $isTS = $true }
                } catch {}

                if ($isTS) {
                    $items += Get-TSDeepReferences -TaskSequenceId $pkgId -SeenTSIds $SeenTSIds
                } else {
                    $items += [PSCustomObject]@{
                        ContentID   = $pkgId
                        ContentName = $null
                        ContentType = "PackageOrImage"
                    }
                }
            }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($tsObject.Sequence)) {
        try {
            $seqStr = $tsObject.Sequence -join "`n"

            # Capture OSDAppXName, clean up commas
            $matches = [regex]::Matches($seqStr, 'name="OSDApp(\d+)Name"[^>]*>([^<]+)<')

            foreach ($match in $matches) {
                $appID = $match.Groups[2].Value.Trim().TrimEnd(',').Trim()

                if ($appID -and $appID -match '^ScopeId_') {

                    $appName = $appID

                    # TS steps can reference a specific pinned VERSION of an app,
                    # whose CI_UniqueID has a trailing "/<n>" that won't match the
                    # latest version's unversioned ID. Strip it for a base-ID match.
                    $appIDBase = $appID -replace '/\d+$', ''

                    # ATTEMPT 1: Get-CMApplication (covers normal/latest apps)
                    try {
                        $app = Get-CMApplication -Fast | Where-Object {
                            $_.CI_UniqueID -eq $appID -or $_.CI_UniqueID -eq $appIDBase -or
                            $_.CI_UniqueID -like "*$appIDBase*" -or $_.ModelName -like "*$appIDBase*"
                        } | Select-Object -First 1
                        if ($app) { $appName = $app.LocalizedDisplayName }
                    } catch {}

                    # ATTEMPT 2: direct WMI against SMS_Application - catches cases
                    # where the cmdlet's caching/latest-version view misses it.
                    if ($appName -eq $appID) {
                        try {
                            $appWmi = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" `
                                -Class SMS_Application -Filter "CI_UniqueID LIKE '%$appIDBase%'" -ErrorAction Stop | Select-Object -First 1
                            if ($appWmi) { $appName = $appWmi.LocalizedDisplayName }
                        } catch {}
                    }

                    # ATTEMPT 3: SMS_CIAll - includes non-latest/expired CI versions
                    # that SMS_Application (latest-only) and Get-CMApplication -Fast
                    # can both miss, e.g. a retired or superseded app version still
                    # pinned by an older TS step.
                    if ($appName -eq $appID) {
                        try {
                            $ciWmi = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" `
                                -Class SMS_CIAll -Filter "CI_UniqueID LIKE '%$appIDBase%'" -ErrorAction Stop | Select-Object -First 1
                            if ($ciWmi) { $appName = $ciWmi.LocalizedDisplayName }
                        } catch {}
                    }

                    if ($appName -eq $appID) {
                        Write-Host "    Could not resolve app name for CI_UniqueID: $appID (likely deleted/retired - check the TS step in the console, it will show a broken/missing reference icon)"
                    }

                    $items += [PSCustomObject]@{
                        ContentID   = $appID
                        ContentName = $appName
                        ContentType = "Application"
                    }
                }
            }
        } catch {
            Write-Host "    Error parsing sequence XML for apps in $TaskSequenceId"
        }
    }

    # Dedupe by ContentID (an app can be referenced by more than one TS step)
    # while keeping ContentName - the previous "Select-Object -Unique -Property
    # ContentID, ContentType" dropped ContentName entirely since -Property
    # limits output to exactly the listed properties, which is why every
    # resolved application name was getting discarded before it reached the grid.
    return $items | Group-Object -Property ContentID | ForEach-Object { $_.Group | Select-Object -First 1 }
}

# ----------------------------------------------------------------------------
# Resolve friendly name + type
# ----------------------------------------------------------------------------
function Resolve-ContentInfo {
    param([string]$PackageID)


    $typeMap = @{
        0 = "Package"
        3 = "Driver Package"
        4 = "Task Sequence Package"
        5 = "Software Update"
        6 = "Device Setting"
        7 = "Virtual App"
        8 = "Application"
        257 = "OS Image"
        258 = "Boot Image"
				259 = "OS Upgrade"

    }

    try { $obj = Get-CMPackage -Id $PackageID -Fast -ErrorAction Stop; if ($obj) { $type = if ($typeMap.ContainsKey([int]$obj.PackageType)) { $typeMap[[int]$obj.PackageType] } else { "Package" }; return [PSCustomObject]@{ Name = $obj.Name; Type = $type } } } catch {}

    try { $obj = Get-CMBootImage -Id $PackageID -Fast -ErrorAction Stop; if ($obj) { return [PSCustomObject]@{ Name = $obj.Name; Type = "Boot Image" } } } catch {}
    try { $obj = Get-CMOperatingSystemImage -Id $PackageID -Fast -ErrorAction Stop; if ($obj) { return [PSCustomObject]@{ Name = $obj.Name; Type = "OS Image" } } } catch {}
    try { $obj = Get-CMOperatingSystemInstaller -Id $PackageID -ErrorAction Stop; if ($obj) { return [PSCustomObject]@{ Name = $obj.Name; Type = "OSD Package (Upgrade)" } } } catch {}
    try { $wmiObj = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" -Class SMS_PackageBaseclass -Filter "PackageID='$PackageID'" -ErrorAction Stop; if ($wmiObj) { $type = if ($typeMap.ContainsKey([int]$wmiObj.PackageType)) { $typeMap[[int]$wmiObj.PackageType] } else { "Package" }; return [PSCustomObject]@{ Name = $wmiObj.Name; Type = $type } } } catch {}
    try { $obj = Get-CMDriverPackage -Id $PackageID -Fast -ErrorAction Stop; if ($obj) { return [PSCustomObject]@{ Name = $obj.Name; Type = "Driver Package" } } } catch {}
    try { $obj = Get-CMTaskSequence -TaskSequencePackageId $PackageID -Fast -ErrorAction Stop; if ($obj) { return [PSCustomObject]@{ Name = $obj.Name; Type = "Task Sequence" } } } catch {}

    return [PSCustomObject]@{ Name = $PackageID; Type = "Unknown" }
}

# ----------------------------------------------------------------------------
# Get per-DP status for Packages
# ----------------------------------------------------------------------------
function Get-PackageDPStatus {
    param([string]$PackageID)

    $PackageID = ([string]$PackageID).Trim()

    # 1. Get Clean List of DPs
    $dpObjects = $null
    try {
        $dpObjects = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" -Class SMS_DistributionPoint -Filter "PackageID='$PackageID'" -ErrorAction Stop
    } catch {
        Write-Host "ERROR: Could not query SMS_DistributionPoint for $PackageID : $($_.Exception.Message)"
        return @()
    }

    if (-not $dpObjects) { return @() }

    # 2. Get Status Summarizer (Matches what the Console highlights in Red/Yellow/Green)
    $statusRows = $null
    try {
        $statusRows = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" -Class SMS_PackageStatusDistPointsSummarizer -Filter "PackageID='$PackageID'" -ErrorAction Stop
    } catch {
        Write-Host "WARNING: Could not query status summarizer for $PackageID. Defaulting to Success."
    }

    $results = @()

    foreach ($dp in $dpObjects) {
        # Parse DP Name from the NAL Path property
        $dpName = "Unknown DP"
        if ($dp.ServerNALPath) {
            $temp = $dp.ServerNALPath -replace '.*\\\\', ''
            $dpName = ($temp -split '\\')[0].Trim('"', ']', ' ')
        }

        # Default to Success (State 0 = Installed)
        $state = 0
        $statusText = "Success"

        # Look for matching status row for THIS specific DP
        if ($statusRows) {
            foreach ($sRow in $statusRows) {
                # Match the summarizer ServerNALPath to our DP object
                if ($sRow.ServerNALPath -eq $dp.ServerNALPath) {
                    $state = [int]$sRow.State
                    break
                }
            }
        }

        # ------------------------------------------------------------------
        # EXACT SCCM Console Mapping (Perfectly aligned with your screenshot):
        # 0 = Installed -> Success
        # 1 = Install Pending -> In Progress
        # 2 = Install Retrying -> In Progress
        # 3 = Install Failed -> Failed
        # 4 = Removal Pending -> In Progress
        # 5 = Removal Retrying -> In Progress
        # 6 = Removal Failed -> Failed
        # 7 = Content Updating -> In Progress
        # 8 = Content Monitoring -> In Progress
        # ------------------------------------------------------------------
        switch ($state) {
            0 { $statusText = "Success" }
            1 { $statusText = "In Progress" }
            2 { $statusText = "In Progress" }
            3 { $statusText = "Failed" }
            4 { $statusText = "In Progress" }
            5 { $statusText = "In Progress" }
            6 { $statusText = "Failed" }  # <-- Changed this to simply "Failed" to match your Console
            7 { $statusText = "In Progress" }
            8 { $statusText = "In Progress" }
            default { $statusText = "Unknown" }
        }

        $results += [PSCustomObject]@{
            PackageID   = $PackageID
            DPName      = $dpName
            State       = $state
            Status      = $statusText
            LastUpdate  = $dp.LastUpdateDate
        }
    }

    return $results
}
# ----------------------------------------------------------------------------
# Get per-DP status for Applications
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# Map an Application's CI_UniqueID to its underlying content PackageID(s).
# Each DeploymentType's content gets its own package-style Content ID (looks
# like a normal PackageID, e.g. "CB1000F5") via SMS_CIContentPackage - THAT ID
# is what actually appears in SMS_DistributionPoint / SMS_PackageStatusDistPointsSummarizer,
# not the app's CI_UniqueID. An app can have more than one DeploymentType, so
# this can return multiple content PackageIDs for a single application.
# ----------------------------------------------------------------------------
function Get-AppContentPackageIDs {
    param([string]$AppCIUniqueID)

    $baseId = $AppCIUniqueID -replace '/\d+$', ''
    $ciId = $null

    try {
        $app = Get-CMApplication -Fast | Where-Object {
            $_.CI_UniqueID -eq $AppCIUniqueID -or $_.CI_UniqueID -eq $baseId -or
            $_.ModelName -eq $AppCIUniqueID -or $_.ModelName -eq $baseId
        } | Select-Object -First 1
        if ($app) { $ciId = $app.CI_ID }
    } catch {}

    if (-not $ciId) {
        try {
            $ciWmi = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" `
                -Class SMS_CIAll -Filter "CI_UniqueID LIKE '%$baseId%'" -ErrorAction Stop | Select-Object -First 1
            if ($ciWmi) { $ciId = $ciWmi.CI_ID }
        } catch {}
    }

    if (-not $ciId) { return @() }

    try {
        $rows = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" `
            -Class SMS_CIContentPackage -Filter "CI_ID=$ciId" -ErrorAction Stop
        return @($rows | Select-Object -ExpandProperty PackageID -Unique)
    } catch {
        return @()
    }
}

function Get-ApplicationDPStatus {
    param([string]$AppCIUniqueID)

    $AppCIUniqueID = ([string]$AppCIUniqueID).Trim()

    # Resolve the app's actual content PackageID(s) (one per DeploymentType with
    # content) via SMS_CIContentPackage, then reuse the already-proven
    # Get-PackageDPStatus for each one - same DP-status mechanism that's
    # already correct for Packages/Boot Images/OS Images.
    $contentPkgIds = Get-AppContentPackageIDs -AppCIUniqueID $AppCIUniqueID

    if (-not $contentPkgIds -or $contentPkgIds.Count -eq 0) {
        return @([PSCustomObject]@{
            PackageID  = $AppCIUniqueID
            DPName     = "(no content package found - check the app's deployment type has content)"
            State      = 0
            Status     = "Unknown"
            LastUpdate = $null
        })
    }

    $results = @()
    foreach ($pkgId in $contentPkgIds) {
        # Get-PackageDPStatus returns rows with PackageID = the content PkgID
        # (e.g. "CB1000F5") - keep that; it's what Invoke-TargetedRedistribute
        # needs to actually trigger redistribution correctly.
        $results += Get-PackageDPStatus -PackageID $pkgId
    }
    return $results
}

# ----------------------------------------------------------------------------
# Targeted redistribution
# ----------------------------------------------------------------------------
function Invoke-TargetedRedistribute {
    param(
        [Parameter(Mandatory)][string]$PackageID,
        [Parameter(Mandatory)][string]$DPName
    )
    try {
        $contentObject = $null

        try { $contentObject = Get-CMPackage -Id $PackageID -ErrorAction Stop } catch {}
        if (-not $contentObject) { try { $contentObject = Get-CMBootImage -Id $PackageID -ErrorAction Stop } catch {} }
        if (-not $contentObject) { try { $contentObject = Get-CMOperatingSystemImage -Id $PackageID -ErrorAction Stop } catch {} }
        if (-not $contentObject) { try { $contentObject = Get-CMOperatingSystemInstaller -Id $PackageID -ErrorAction Stop } catch {} }
        if (-not $contentObject) { try { $contentObject = Get-CMDriverPackage -Id $PackageID -ErrorAction Stop } catch {} }

        # Application content: $PackageID here is the DeploymentType's content
        # PackageID (e.g. "CB1000F5"), not the app's CI_UniqueID. Reverse-map
        # it back to the parent Application via SMS_CIContentPackage, then
        # resolve that CI_ID to the actual Application object to redistribute.
        if (-not $contentObject) {
            try {
                $ciMap = Get-WmiObject -ComputerName $SiteServer -Namespace "root\sms\site_$SiteCode" `
                    -Class SMS_CIContentPackage -Filter "PackageID='$PackageID'" -ErrorAction Stop | Select-Object -First 1
                if ($ciMap -and $ciMap.CI_ID) {
                    $contentObject = Get-CMApplication -Id $ciMap.CI_ID -ErrorAction Stop
                }
            } catch {}
        }

        if (-not $contentObject) {
            Log-Message "ERROR: Could not find content object for PackageID: $PackageID"
            return "ERROR: Could not find content object for PackageID: $PackageID"
        }

        $contentObject | Invoke-CMContentRedistribution -DistributionPointName $DPName -ErrorAction Stop
        Log-Message "SUCCESS: Redistribution triggered for '$PackageID' on DP '$DPName'."
        return "OK - Redistribution triggered"
    } catch {
        Log-Message "ERROR: Failed to redistribute '$PackageID' on DP '$DPName'. Error: $($_.Exception.Message)"
        return "ERROR: $($_.Exception.Message)"
    }
}

# ============================================================================
# GUI
# ============================================================================
Connect-CMSite

$form = New-Object System.Windows.Forms.Form
$form.Text = "SCCM TS Content Health Check"
$form.Size = New-Object System.Drawing.Size(1330, 760)
$form.StartPosition = "CenterScreen"

# --- TS selection ---
$lblTS = New-Object System.Windows.Forms.Label
$lblTS.Text = "Task Sequence:"
$lblTS.Location = New-Object System.Drawing.Point(10,15)
$lblTS.Size = New-Object System.Drawing.Size(100,20)
$form.Controls.Add($lblTS)

$cmbTS = New-Object System.Windows.Forms.ComboBox
$cmbTS.Location = New-Object System.Drawing.Point(115,12)
$cmbTS.Size = New-Object System.Drawing.Size(500,20)
$cmbTS.DropDownStyle = 'DropDownList'
$form.Controls.Add($cmbTS)

Write-Host "Loading task sequences..."
$allTS = Get-CMTaskSequence -Fast | Sort-Object Name
$tsMap = @{}
foreach ($t in $allTS) {
    $label = "$($t.Name)  [$($t.PackageID)]"
    [void]$cmbTS.Items.Add($label)
    $tsMap[$label] = $t.PackageID
}

$btnLoad = New-Object System.Windows.Forms.Button
$btnLoad.Text = "Load Content Status"
$btnLoad.Location = New-Object System.Drawing.Point(625,10)
$btnLoad.Size = New-Object System.Drawing.Size(150,25)
$form.Controls.Add($btnLoad)

$chkFailedOnly = New-Object System.Windows.Forms.CheckBox
$chkFailedOnly.Text = "Show Failed Only"
$chkFailedOnly.Location = New-Object System.Drawing.Point(790,14)
$chkFailedOnly.Size = New-Object System.Drawing.Size(140,20)
$chkFailedOnly.Checked = $true
$form.Controls.Add($chkFailedOnly)

$btnSelectAllFailed = New-Object System.Windows.Forms.Button
$btnSelectAllFailed.Text = "Select All Failed"
$btnSelectAllFailed.Location = New-Object System.Drawing.Point(940,10)
$btnSelectAllFailed.Size = New-Object System.Drawing.Size(130,25)
$form.Controls.Add($btnSelectAllFailed)

$btnExportGrid = New-Object System.Windows.Forms.Button
$btnExportGrid.Text = "Export Grid to CSV"
$btnExportGrid.Location = New-Object System.Drawing.Point(1080,10)
$btnExportGrid.Size = New-Object System.Drawing.Size(150,25)
$form.Controls.Add($btnExportGrid)

# --- Grid ---
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(10,50)
$grid.Size = New-Object System.Drawing.Size(1290,580)
$grid.AutoSizeColumnsMode = 'Fill'
$grid.AllowUserToAddRows = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.ReadOnly = $false

# 1. Numbering Column
$colIndex = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
$colIndex.Name = "Index"; $colIndex.HeaderText = "#"; $colIndex.Width = 40
$colIndex.ReadOnly = $true
$grid.Columns.Add($colIndex) | Out-Null

# 2. Select Checkbox
$colSel = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$colSel.Name = "Select"; $colSel.HeaderText = "Select"; $colSel.Width = 60
$grid.Columns.Add($colSel) | Out-Null

# 3. Other columns
foreach ($c in @("ContentName","ContentType","PackageID","DPName","Status")) {
    $col = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $col.Name = $c; $col.HeaderText = $c; $col.ReadOnly = $true
    if ($c -eq "Status") { $col.Width = 130 }
    $grid.Columns.Add($col) | Out-Null
}
$form.Controls.Add($grid)

# --- Action buttons ---
$btnRedistribute = New-Object System.Windows.Forms.Button
$btnRedistribute.Text = "Redistribute Selected"
$btnRedistribute.Location = New-Object System.Drawing.Point(10,640)
$btnRedistribute.Size = New-Object System.Drawing.Size(180,32)
$btnRedistribute.BackColor = [System.Drawing.Color]::LightGreen
$form.Controls.Add($btnRedistribute)

$btnExportLog = New-Object System.Windows.Forms.Button
$btnExportLog.Text = "Export Log to CSV"
$btnExportLog.Location = New-Object System.Drawing.Point(200,640)
$btnExportLog.Size = New-Object System.Drawing.Size(150,32)
$form.Controls.Add($btnExportLog)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Location = New-Object System.Drawing.Point(360,645)
$lblStatus.Size = New-Object System.Drawing.Size(940,25)
$form.Controls.Add($lblStatus)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(10,680)
$txtLog.Size = New-Object System.Drawing.Size(1290,45)
$txtLog.Multiline = $true
$txtLog.ScrollBars = 'Vertical'
$form.Controls.Add($txtLog)

$script:AllRows = @()
$script:RedistributeLog = @()

function Export-GridColl {
    param([Parameter(Mandatory)]$Data, [string]$DefaultName)
    if (-not $Data -or $Data.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("Nothing to export.") | Out-Null
        return
    }
    $sfd = New-Object System.Windows.Forms.SaveFileDialog
    $sfd.Filter = "CSV files (*.csv)|*.csv"
    $sfd.FileName = "$DefaultName`_$(Get-Date -Format 'yyyyMMdd_HHmmss').csv"
    if ($sfd.ShowDialog() -eq 'OK') {
        $Data | Export-Csv -Path $sfd.FileName -NoTypeInformation -Encoding UTF8
        [System.Windows.Forms.MessageBox]::Show("Exported $($Data.Count) row(s) to:`r`n$($sfd.FileName)") | Out-Null
        Log-Message "Exported data to CSV: $($sfd.FileName)"
    }
}

function Refresh-Grid {
    $grid.Rows.Clear()
    $rowsToShow = if ($chkFailedOnly.Checked) { $script:AllRows | Where-Object { $_.Status -eq "Failed" -or $_.Status -eq "Removal Failed" } } else { $script:AllRows }
    $i = 0
    foreach ($r in $rowsToShow) {
        $i++
        $rowIdx = $grid.Rows.Add($i, $false, $r.ContentName, $r.ContentType, $r.PackageID, $r.DPName, $r.Status)
        # Full, untruncated ID as a tooltip - lets you identify a row (e.g. an
        # unresolved app showing its raw ScopeId_.../Application_XXX) without
        # having to widen the column or guess from truncated text.
        $grid.Rows[$rowIdx].Cells["ContentName"].ToolTipText = "ID: $($r.PackageID)"
        $grid.Rows[$rowIdx].Cells["PackageID"].ToolTipText = $r.PackageID
    }

    # Calculate the correct count explicitly for both the GUI and the log
    $script:CurrentFailedCount = @($script:AllRows | Where-Object { $_.Status -eq 'Failed' -or $_.Status -eq 'Removal Failed' }).Count

    # Unique content items (distinct PackageID+ContentType) - the grid shows one
    # row per Content/DP pair, so this gives a "how many actual pieces of
    # content" reference distinct from the per-DP row count.
    $script:UniqueContentCount = @($script:AllRows | Group-Object -Property PackageID, ContentType).Count

    $lblStatus.Text = "Showing $($rowsToShow.Count) rows (Total: $($script:AllRows.Count), Failed: $($script:CurrentFailedCount), Unique Content Items: $($script:UniqueContentCount))"
    Log-Message "Grid refreshed. Total: $($script:AllRows.Count), Failed: $($script:CurrentFailedCount), Unique Content Items: $($script:UniqueContentCount)"
}

$btnLoad.Add_Click({
    if (-not $cmbTS.SelectedItem) {
        [System.Windows.Forms.MessageBox]::Show("Select a Task Sequence first.") | Out-Null
        return
    }
    $lblStatus.Text = "Loading content and DP status (recursive scan)... this can take a while."
    $form.Refresh()

    $tsId = $tsMap[$cmbTS.SelectedItem.ToString()]
    Log-Message "Loading content for TS: $($cmbTS.SelectedItem) (ID: $tsId)"

    Write-Host "Starting recursive scan..."
    $allRefs = Get-TSDeepReferences -TaskSequenceId $tsId
    Write-Host "Total references found: $($allRefs.Count)"
    Log-Message "Found $($allRefs.Count) unique content references."

    $rows = @()

    foreach ($ref in $allRefs) {
        if ($ref.ContentType -eq "Application") {
            $dpStatuses = Get-ApplicationDPStatus -AppCIUniqueID $ref.ContentID
            foreach ($dp in $dpStatuses) {
                $rows += [PSCustomObject]@{
                    ContentName = $ref.ContentName
                    ContentType = "Application"
                    PackageID   = $dp.PackageID   # actual content PkgID (e.g. "CB1000F5") - needed for redistribution to work, not the app's CI_UniqueID
                    DPName      = $dp.DPName
                    Status      = $dp.Status
                }
            }
        } else {
            $info = Resolve-ContentInfo -PackageID $ref.ContentID
            $dpStatuses = Get-PackageDPStatus -PackageID $ref.ContentID
            foreach ($dp in $dpStatuses) {
                $rows += [PSCustomObject]@{
                    ContentName = $info.Name
                    ContentType = $info.Type
                    PackageID   = $ref.ContentID
                    DPName      = $dp.DPName
                    Status      = $dp.Status
                }
            }
        }
    }

    $script:AllRows = $rows
    Refresh-Grid
})

$chkFailedOnly.Add_CheckedChanged({ Refresh-Grid })

$btnSelectAllFailed.Add_Click({
    foreach ($row in $grid.Rows) {
        if ($row.Cells["Status"].Value -eq "Failed" -or $row.Cells["Status"].Value -eq "Removal Failed") {
            $row.Cells["Select"].Value = $true
        }
    }
})

$btnRedistribute.Add_Click({
    $selected = $grid.Rows | Where-Object { $_.Cells["Select"].Value -eq $true }
    if ($selected.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No rows selected.") | Out-Null
        return
    }
    $confirm = [System.Windows.Forms.MessageBox]::Show("Redistribute $($selected.Count) content/DP pair(s)?", "Confirm", 'YesNo', 'Question')
    if ($confirm -ne 'Yes') { return }

    Log-Message "User initiated redistribution of $($selected.Count) content/DP pairs."
    $txtLog.Text = ""
    foreach ($row in $selected) {
        $pkgId = $row.Cells["PackageID"].Value
        $dp    = $row.Cells["DPName"].Value
        $name  = $row.Cells["ContentName"].Value
        $type  = $row.Cells["ContentType"].Value
        $result = Invoke-TargetedRedistribute -PackageID $pkgId -DPName $dp
        $txtLog.AppendText("[$name / $dp] -> $result`r`n")

        $script:RedistributeLog += [PSCustomObject]@{
            Timestamp   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            ContentName = $name
            ContentType = $type
            PackageID   = $pkgId
            DPName      = $dp
            Result      = $result
        }
    }
    [System.Windows.Forms.MessageBox]::Show("Redistribution requests submitted. Content status will update as DPs process the refresh (check Content Status node or re-run Load).") | Out-Null
})

$btnExportGrid.Add_Click({
    Export-GridColl -Data $script:AllRows -DefaultName "TS_ContentStatus"
})

$btnExportLog.Add_Click({
    Export-GridColl -Data $script:RedistributeLog -DefaultName "TS_RedistributeLog"
})

$form.Add_Shown({ $form.Activate() })

# Log when the form is closed
$form.Add_FormClosed({
    Log-Message "Script ended."
})

[void]$form.ShowDialog()