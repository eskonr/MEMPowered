﻿# Define variables
$scriptlocation = $MyInvocation.MyCommand.Path
$directory = Split-Path $scriptlocation
$scriptPath = "$directory\ChangeDateFormat.ps1"
$iconpath="$directory\Date.ico"
$shortcutName = 'Change Date Format.lnk'
$startMenuPath = 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs'
$shortcutPath = Join-Path -Path $startMenuPath -ChildPath $shortcutName
$TargetDir = 'C:\ProgramData\eskonr\ChangeSystemDate'
$TargetScriptPath = "$TargetDir\ChangeDateFormat.ps1"
$logFilePath = 'C:\ProgramData\eskonr\InstallLogs\InstallDateFormatChange.log'
$iconloc = "$TargetDir\Date.ico"  # Path to your custom .ico file

# Function to log messages
function Log-Message {
    param (
        [string]$message
    )
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $logMessage = "$timestamp > $message"
    Add-Content -Path $logFilePath -Value $logMessage
}

# Ensure the log directory exists
$logDir = Split-Path -Path $logFilePath -Parent
if (-not (Test-Path -Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory | Out-Null
}

# Log the start of the script
Log-Message 'Script execution started.'

# Ensure the target paths exist
if (-not (Test-Path -Path "$TargetDir")) {
    New-Item -Path "$TargetDir" -ItemType Directory | Out-Null
    Log-Message "Created directory: $TargetDir"
} else {
    Log-Message "Directory already exists: $TargetDir"
}

# Copy the script and icon to their locations if not already there
Copy-Item $scriptPath -Destination $TargetDir -Force -ErrorAction SilentlyContinue
Log-Message "Copied script to $TargetDir"
Copy-Item $iconPath -Destination $TargetDir -Force -ErrorAction SilentlyContinue
Log-Message "Copied icon to $TargetDir"

# Add a COM object to create a shortcut
$WScriptShell = New-Object -ComObject WScript.Shell
$Shortcut = $WScriptShell.CreateShortcut($shortcutPath)

# Set the target path to PowerShell with the execution command
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-Windowstyle Hidden -ExecutionPolicy Bypass -File `"$TargetScriptPath`""

# Set the working directory
$Shortcut.WorkingDirectory = "$TargetDir"

# Set the icon location
$Shortcut.IconLocation = $iconloc

# Set the shortcut description
$Shortcut.Description = "Change Date Format"

# Save the shortcut
$Shortcut.Save()

# Confirm the shortcut creation
Write-Host "Shortcut created successfully at $shortcutPath with custom icon."
Log-Message "Shortcut created successfully at $shortcutPath with custom icon."

# Log the end of the script
Log-Message 'Script execution completed.'