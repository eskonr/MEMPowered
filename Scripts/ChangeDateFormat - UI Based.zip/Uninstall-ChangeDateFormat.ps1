﻿# Define variables
$shortcutName = 'Change Date Format.lnk'
$startMenuPath = 'C:\ProgramData\Microsoft\Windows\Start Menu\Programs'
$shortcutPath = Join-Path -Path $startMenuPath -ChildPath $shortcutName
$TargetDir = "C:\ProgramData\eskonr\ChangeSystemDate"
$logFilePath = "C:\ProgramData\eskonr\InstallLogs\InstallDateFormatChange.log"

# Function to log messages
function Log-Message {
    param (
        [string]$message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "$timestamp > $message"
    Add-Content -Path $logFilePath -Value $logMessage
}

# Ensure the log directory exists
$logDir = Split-Path -Path $logFilePath -Parent
if (-not (Test-Path -Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory | Out-Null
}

# Log the start of the uninstaller
Log-Message "Uninstaller execution started."

# Delete the shortcut if it exists
if (Test-Path -Path $shortcutPath) {
    Remove-Item -Path $shortcutPath -Force
    Log-Message "Shortcut deleted: $shortcutPath"
} else {
    Log-Message "Shortcut not found: $shortcutPath"
}

# Delete the target directory if it exists
if (Test-Path -Path $TargetDir) {
    Remove-Item -Path $TargetDir -Recurse -Force
    Log-Message "Directory deleted: $TargetDir"
} else {
    Log-Message "Directory not found: $TargetDir"
}

# Log the end of the uninstaller
Log-Message "Uninstaller execution completed."