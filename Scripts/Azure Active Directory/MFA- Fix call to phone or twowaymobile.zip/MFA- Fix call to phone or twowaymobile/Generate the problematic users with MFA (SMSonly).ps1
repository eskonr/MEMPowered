﻿
<#
Name: Generate the report for list of users whose authentication method with phone number is set to SMS only, no call based.
Author: Eswar Koneti @eskonr
#>

$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$date = (Get-Date -f dd-MM-yyyy-hhmmss)
$users  = "$dir\problemUsers.csv"

Connect-MsolService
$users = Get-MsolUser -All
$problemUsers = @()
 
foreach ($user in $users)
{
If  (-Not ($user.StrongAuthenticationMethods.MethodType -Match 'TwoWayVoiceMobile') -and ($user.StrongAuthenticationMethods.MethodType -Match 'OneWaySMS'))
{
     $problemUsers += $user
}
}
$problemUsers |Select-Object -Property UserPrincipalName -ExpandProperty StrongAuthenticationMethods | export-csv $users -NoTypeInformation