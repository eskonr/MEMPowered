﻿<#
Name: Set StrongAuthenticationMethods to include both “OneWaySMS” and “TwoWayVoiceMobile”.  
Author: Eswar Koneti @eskonr
#>
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$date = (Get-Date -f dd-MM-yyyy-hhmmss)
$users  = "$dir\problemUsers.csv"
Connect-MsolService
foreach ($user in $users)
{
    $upn = $user.UserPrincipalName
    $user = Get-MsolUser -UserPrincipalName $upn
    $user.StrongAuthenticationMethods
         
    $sm1 = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationMethod
    $sm1.IsDefault = $true
    $sm1.MethodType = "OneWaySMS"
    
    $sm2 = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationMethod
    $sm2.IsDefault = $false
    $sm2.MethodType = "TwoWayVoiceMobile"
    
    $sm = @($sm1,$sm2)
    
    Set-MsolUser -UserPrincipalName $upn -StrongAuthenticationMethods $sm
}
