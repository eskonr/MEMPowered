﻿    Connect-MsolService
    $upn = "Email Address or UPN"
    $user = Get-MsolUser -UserPrincipalName $upn
    $user.StrongAuthenticationMethods
    $sm1 = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationMethod
    $sm1.IsDefault = $true
    $sm1.MethodType = "OneWaySMS"
    $sm2 = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationMethod
    $sm2.IsDefault = $false
    $sm2.MethodType = "TwoWayVoiceMobile"
    $sm = @($sm1,$sm2)
    Set-MsolUser -UserPrincipalName $upn -StrongAuthenticationMethods $sm
