﻿<#	
.NOTES
	===========================================================================
	 Created on:   	1/26/2022
	 Created by:   	Eswar Koneti @eskonr
	 Organization: 	Eskonr
	 Filename: CAP-Audit-Report.ps1    	
	===========================================================================
	.DESCRIPTION
		Backup the Azure AD conditional Access Policies and Audit report.
#>

#Fetch the current directory of the script location
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
#Get the current date
$date = (Get-Date -f ddMMyyyy-HHmmss)

#Information for email notification
<#
$From = "o365automation@eskonr.com"
$To = "username1@eskonr.com","group@eskonr.com"
$smtp="smtp details"
$Subject = "Conditional Access Audit Report  |  $(Get-Date -Format dd-MM-yyyy)"
$Body = "Hi Team,
Please find the list of Conditional Access Policies that are created or modified in the last 24 hours.

Thanks,
O365 Automation
Note: This is an auto generated email, please do not reply to this.
"
#>

#If you want to run the script in unattended way, you will need to store the account credetials securely in key file and pass it while connecting to azure AD.
<#
#Store the account password in the key file, run line 37 only to store the password and change the dir location.
#Read-Host -Prompt "Enter your tenant password" -AsSecureString | ConvertFrom-SecureString | Out-File "Dir\o365.key"
$TenantUname = "username@domain.com"
$TenantPass = cat ""Dir\o365.key" | ConvertTo-SecureString
$TenantCredentials = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $TenantUname,$TenantPass
#>

if (!(Get-Module azureadpreview))
{
	Write-host "There are no Azure AD modules installed, Installing the Azure AD module" -ForegroundColor Red
	Install-module -Name azureadpreview -ErrorAction SilentlyContinue
	Import-module -Name azureadpreview -ErrorAction SilentlyContinue
	if (!(Get-Module azureadpreview))
	{
		Write-host "couldnt able to install Azure AD Module" -ForegroundColor Red
		break
	}
	else
	{
		Write-host "Azure AD module installed, Continue Script"
	}
}
if (Get-Module azureadpreview)
{
	try
	{
		Connect-AzureAD -Credential $TenantCredentials
	}
	catch [System.Exception]
	{
		$WebReqErr = $error[0] | Select-Object * | Format-List -Force
		Write-Error "An error occurred while attempting to connect to the requested service. The error was $WebReqErr.Exception"
		Send-MailMessage -From $From -To $To -SmtpServer $smtp -Subject "Failed to connect to AzureAD" -Body "Please check the script."
	}
}
#create a backup folder
$dir1 = "$dir\CABackup"
New-Item -Path $dir1 -ItemType Directory -Force -ErrorAction SilentlyContinue
$BackupPath = "$dir1\$date"
If (!(Test-Path $BackupPath))
{
	New-Item -Path $BackupPath -ItemType Directory -Force
}
$Currentdate = (Get-Date).AddDays(-1)
$Modifiedpolicies = "$BackupPath\ChangestoCAPolicies.txt"
$AllPolicies = Get-AzureADMSConditionalAccessPolicy
foreach ($Policy in $AllPolicies)
{
	Write-host "Backing up $($Policy.DisplayName)"
	$Policy | ConvertTo-Json | Out-File "$BackupPath\$($Policy.Id).json"
	$policyModifieddate = nullable[datetime]
	$policyCreationdate = nullable[datetime]
	if (($policyModifieddate -gt $Currentdate) -or ($policyCreationdate -gt $Currentdate))
	{
		#write-host "------There are policies updated in the last 24 hours, please refer txt file." -ForegroundColor Green
		IF (($policyModifieddate))
		{
			"PolicyID:$($policy.ID) & Name:$($policy.DisplayName) & Modified date:$policyModifieddate" | Out-File $Modifiedpolicies -Append
		}
		else
		{
			"PolicyID:$($policy.ID) & Name:$($policy.DisplayName) & Creation date:$policyCreationdate" | Out-File $Modifiedpolicies -Append
		}
	}
}
#send email if any changes to the Conditional Access Policies in the last 24 hours
If ((Get-Content $Modifiedpolicies) -ne $Null)
{
	write-host "Found policies" -ForegroundColor Yellow
	Send-MailMessage -From $From -To $To -SmtpServer $smtp -Subject $Subject -Body $Body -Attachments "$Modifiedpolicies"
}


