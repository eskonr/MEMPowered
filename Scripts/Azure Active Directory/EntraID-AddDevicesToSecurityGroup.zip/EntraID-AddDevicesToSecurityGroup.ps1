﻿<#
Name:Get device info from Azure AD and add to the AAD group.
Description: This script helps to get the objectID from Azure AD and add it to the group that you specify as part of the script.
Author:Eswar Koneti (@eskonr)
Date:15-Jul-2022
Create txt file somedevices.txt and place it in the folder where the script resides..
#>

#Get the script location
$scriptpath = $MyInvocation.MyCommand.Path
$directory = Split-Path $scriptpath

$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
#Get the script execution date                  
$date = (Get-Date -f ddMMyyyy_hhmmss)
$o_ScriptLaunchTime = Get-Date
$s_Year = [string]($o_ScriptLaunchTime.Year)
$s_Month = [string]($o_ScriptLaunchTime.Month)
if ($s_Month.Length -eq 1) { $s_Month = "0$s_Month" }
$s_Day = [string]($o_ScriptLaunchTime.Day)
if ($s_Day.Length -eq 1) { $s_Day = "0$s_Day" }

#Get the script execution date                  
$date = (Get-Date -f dd-MM-yyyy-hhmmss)

#input the list of devices to retrieve the information from AAD.
#$input = "$directory\Listofdevices.txt"

#Output file for storing the Azure AD device info which will be used for adding the devices during the script running.
$Output = "$directory\ObjectIDinfo.csv"
$log = "$directory\add-devices-aad.log"

#remove if the output file already exist with old content
if (Test-Path $Output -ErrorAction SilentlyContinue) {
  Remove-Item $Output -ErrorAction SilentlyContinue
}

#Check the Azure AD module
if (!(Get-Module -ListAvailable *AzureAD*)) {
  Write-Host "Azure AD module not installed, installing now" -BackgroundColor Red
  Install-Module -Name AzureAD

  $Modules = Get-Module -ListAvailable *AzureAD*
  if ($Modules.count -eq 0) {
    Write-Host "Unable to install the required modules, please install and run the script again" -BackgroundColor Red
    exit
  }
}

$azureADConnected = $false

try {
  $tenant = Get-AzureADTenantDetail -ErrorAction Stop
  $azureADConnected = $true
}
catch {
  Write-Host "Unable to retrieve Azure AD tenant details." -ForegroundColor Red
}

if (!$azureADConnected) {
  try {
    Connect-AzureAD -ErrorAction Stop
    $azureADConnected = $true
  }
  catch {
    Write-Host "Unable to connect to Azure AD services." -ForegroundColor Red
  }
}

if ($azureADConnected) {
  
  <#
  #Read the devices
  $deviceList = Get-Content -Path $input

  foreach ($dev in $deviceList)
  {
  #>
  Write-Host "To search Intune for assigned objects, enter either the full name of an Azure AD device or a filename (e.g. 'Somedevices.txt') in this script's folder containing multiple Azure AD devices: " -ForegroundColor Yellow
  $DeviceName = "somedevices.txt"
  #Read-Host
  #What was provided?
  if ($DeviceName.EndsWith(".txt", "CurrentCultureIgnoreCase")) {
    #It's a file
    #Confirm the file exists
    if (!(Test-Path -Path "$Dir\$DeviceName")) {
      #File does not exist
      Write-Host ""
      Write-Host "Provided filename of devices cannot be found.  Try again." -ForegroundColor Red
      Write-Host ""
      #Wait for the user...
      Read-Host -Prompt "When ready, press 'Enter' to exit..."
      exit
    }
    else {
      #File exists - get data into an array
      $a_DeviceNames = Get-Content "$Dir\$DeviceName"
      if ($a_DeviceNames.count -eq 0) {
        #No data in file
        Write-Host ""
        Write-Host "Provided filename of devices is empty.  Try again." -ForegroundColor Red
        Write-Host ""
        #Wait for the user...
        Read-Host -Prompt "When ready, press 'Enter' to exit..."
        exit
      }
      elseif ($a_DeviceNames.count -eq 1) {
        #It's a single device
        #No need to pause
        $b_Pause = $false
      }
    }
  }
  else {
    #It's a single device
    $a_DeviceNames = @($DeviceName)

    #No need to pause
    $b_Pause = $false
  }
  Write-Host ""

  Clear-Host
  Write-Host "Data validation is in progress ..." -ForegroundColor Green
  $i_TotalDevices = $a_DeviceNames.count
  Write-Host ""
  Write-Host "Total devices found : $i_TotalDevices . Press 'Enter' to add all devices, or type 'n' then press 'Enter' to exit the script: " -ForegroundColor Yellow -NoNewline
  $Scope = Read-Host
  Write-Host "Input file is recieved, Script execution is in progress..." -ForegroundColor green

  if ($Scope -ieq "n") {
    $b_ScopeAll = $false
  }
  else {
    $b_ScopeAll = $true
  }
  Write-Host ""

  #Continue to report the data for all device objects
  if ($b_ScopeAll) {

    foreach ($DeviceName in $a_DeviceNames) {

      Get-AzureADDevice -SearchString $DeviceName | Select-Object DisplayName, ObjectID | Export-Csv $Output -Append -NoTypeInformation
    }

    #Add the devices to the AAD group.
    $groupName = Read-Host -Prompt "Enter the AAD Security group name to add Devices into"

    if (!(Get-AzureADGroup -SearchString $groupName)) {
      Write-Host "Group name $Groupname not found, exit script" -BackgroundColor Red
      exit
    }

    try {
      $deviceList = Import-Csv -Path $Output
      "-----processing the device count $($devicelist.count) for adding to '$groupName' ----------" | Out-File $log -Append
      $groupObj = Get-AzureADGroup -SearchString $groupName
      "Adding $($devicelist.count) devices found in Entra ID for actual device count $i_TotalDevices to '$groupName'"
      foreach ($dev in $deviceList) {
        $Computer = $dev.DisplayName #computer Name
        $ObjID = $dev.ObjectId #Computer Object ID
        try {
          Add-AzureADGroupMember -ObjectId $groupObj.ObjectId -RefObjectId $ObjID
        }
        catch {
          "Failed to add device $Computer to the group '$groupName'" | Out-File $log -Append
        }
      }

    }
    catch {
      Write-Host -Message $_ | Out-File $log -Append
    }

    Write-Host "Script execution is completed.See file `'$log`' for failed status." -ForegroundColor Green
    $date2 = (Get-Date -f dd-MM-yyyy-hhmmss)
    "----------------- script ended at $date2---------------------" | Out-File $log -Append
  }
  else {
    Write-Host "User has stopped the script due to revalidation of the input objects.." -ForegroundColor Red
    exit
  }

}
