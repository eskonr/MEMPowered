$dir="C:\programdata\Autopilot\BLRNotification"
$Duration = New-TimeSpan -Minutes 30
$Interval = New-TimeSpan -Minutes 10
$TimeAdd = New-TimeSpan -Minutes 1
$Startime = (get-date) + $TimeAdd
$path="Autopilot"
$expiry=(Get-Date).AddSeconds(1920).ToString('s')
$Settings = New-ScheduledTaskSettingsSet -Compatibility Win8 -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 1) -DeleteExpiredTaskAfter (New-TimeSpan -Seconds 600)
$action = New-ScheduledTaskAction -Execute 'PowerShell.exe' -Argument "-exec bypass -NonInteractive -WindowStyle Hidden -file `"$dir\Toast_Notify.ps1`""
$trigger = New-ScheduledTaskTrigger -Once -At $Startime -RepetitionDuration $Duration -RepetitionInterval $Interval -ErrorAction SilentlyContinue
$trigger.EndBoundary = $expiry
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "Reboot Toast_Notify" -Description "Run the Toast Notify for every 10 min for device restart" -User 'nt authority\system' -Settings $Settings -TaskPath $path -ErrorAction SilentlyContinue
