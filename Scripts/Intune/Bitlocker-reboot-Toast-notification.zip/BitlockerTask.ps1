﻿<#
Description: This script will reboot the device upon the completion of the bitlocker encryption based on the event viewer ID:24667
When we use intune device compliance policy, the DHA policy does require device reboot for successful compliance check.
For more info https://techcommunity.microsoft.com/t5/intune-customer-success/support-tip-using-device-health-attestation-settings-as-part-of/ba-p/282643
Author:Eswar Koneti
Date:14-Jan-2022
#>

#Create a folder and copy the files needed for reboot
$scriptPath = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
#Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
#$script:MyInvocation.MyCommand.Path
$dir="C:\programdata\Autopilot\BLRNotification"
if(!(Test-Path -path $dir))  
{
New-Item -ItemType directory -Path $dir
Copy-Item -Path "$scriptPath\*" -Destination "$dir\" -Recurse
}
else
{
Copy-Item -Path "$scriptPath\*" -Destination "$dir\" -Recurse
}
$class = cimclass MSFT_TaskEventTrigger root/Microsoft/Windows/TaskScheduler
$Trigger_onEvent = $class | New-CimInstance -ClientOnly
#Event viewer ID for bitlocker completion: 24667 , the same event ID also used for bitlocker decryption.
$trigger_onEvent.Enabled = $true
$trigger_onEvent.Subscription = @"
<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[EventID=24667]]</Select></Query></QueryList>
"@
$path="Autopilot"
$Trigger_atLogon = New-ScheduledTaskTrigger -AtLogOn

#The action to execute
$action = New-ScheduledTaskAction -Execute "C:\programdata\Autopilot\BLRNotification\Restart.bat"

#Default settings
$settings = New-ScheduledTaskSettingsSet -Compatibility Win8 -DontStopIfGoingOnBatteries -AllowStartIfOnBatteries

#$task = New-ScheduledTask -Trigger $Trigger_atLogon, $Trigger_onEvent -Action $action -Settings $settings -Description "System will reboot after the bitlocker completion'"
$task = New-ScheduledTask -Trigger $Trigger_onEvent -Action $action -Settings $settings -Description "System will reboot after the bitlocker completion with event viewer 24667"

Register-ScheduledTask -User "NT AUTHORITY\SYSTEM" -TaskName "Bitlocker-Reboot-Device" -InputObject $task -TaskPath $path

