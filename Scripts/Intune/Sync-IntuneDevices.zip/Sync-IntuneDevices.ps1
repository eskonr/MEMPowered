﻿<#
.SYNOPSIS
This PowerShell script interacts with Microsoft Intune and Microsoft Graph API to synchronize devices in Intune.

.DESCRIPTION
This script automates the process of synchronizing managed devices in Microsoft Intune by performing the following steps:
1. Ensures the required Microsoft.Graph module is installed and connected.
2. Accepts user input for either a single device name or a file containing a list of device names.
3. Creates an output folder for logging the synchronization results.
4. Verifies the data and prompts the user for confirmation before initiating the sync process.
5. Searches for devices in Intune based on the provided names, attempts to synchronize each device, and logs the success or failure for each device.
6. Logs all synchronization attempts in a log file with timestamps, including successful and failed sync operations.
7. Provides feedback to the user via the console and generates a log file for review.

.EXAMPLE
    .\Sync-IntuneDevices.ps1

.Author: Eswar Koneti

#>

# Define variables
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$date = (Get-Date -Format "dd-MM-yyyy_hhmmss")
$log = "$dir\IntuneDeviceSyncStatus_$date.log"

# Function to connect to Microsoft Graph
# This function ensures that the Microsoft Graph module is installed and connects to Graph API with the necessary permissions.
function ConnectToGraph {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph)) {
        Write-Host "Microsoft.Graph module not found. Installing..."
        Install-Module Microsoft.Graph -Scope CurrentUser -Force
    }
    
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph)) {
        Write-Host "Installation failed! Try installing manually from an elevated prompt: Install-Module Microsoft.Graph"
        Read-Host "Press Enter to exit..."
        exit
    }

    # Try connecting to Microsoft Graph
    try {
        Connect-Graph -Scopes "DeviceManagementManagedDevices.PrivilegedOperations.All"
    } catch {
        Write-Host "Failed to connect to Microsoft Graph. Try again." -ForegroundColor Red
        exit
    }
}

# Ensure Graph is connected, if not, call ConnectToGraph
if (-not (Get-MgContext)) { ConnectToGraph }

# Prompt user for device name or file
Write-Host "Enter device name or filename that contains the list of devices (e.g.'devices.txt'):" -ForegroundColor Yellow
$DeviceName = Read-Host

# Handle input: device name or file
# If a file is provided, check if it exists and is not empty. Read device names into an array.
if ($DeviceName.EndsWith(".txt", "CurrentCultureIgnoreCase")) {
    if (-not (Test-Path "$dir\$DeviceName")) {
        Write-Host "File not found. Exiting..." -ForegroundColor Red
        Read-Host "Press Enter to exit..."
        exit
    }
    $a_DeviceNames = Get-Content "$dir\$DeviceName"
    if ($a_DeviceNames.Count -eq 0) {
        Write-Host "File is empty. Exiting..." -ForegroundColor Red
        Read-Host "Press Enter to exit..."
        exit
    }
} else {
    $a_DeviceNames = @($DeviceName)
}

# Create output folder based on the current date if it doesn't exist
$folder = "$dir\$($date.Substring(0, 8))"
if (-not (Test-Path $folder)) { New-Item -Path $folder -Type Directory }

# Inform the user about the validation process and ask for confirmation
Write-Host "Validating data..." -ForegroundColor Green
Write-Host "Total devices: $($a_DeviceNames.Count). Press 'Enter' to sync or 'n' to exit:" -ForegroundColor Yellow -NoNewline
$Scope = Read-Host

# If the user presses 'n', exit the script
if ($Scope -ieq "n") {
  Write-Host "User has stopped the script due to revalidation of input devices.." -ForegroundColor Red
  exit
}

# Process each device
# The script attempts to find each device in Intune and perform a sync. If successful, logs the result.
foreach ($DeviceName in $a_DeviceNames) {
    # Search for device in Intune using partial matching
    $Device = Get-MgDeviceManagementManagedDevice -Filter "contains(deviceName, '$DeviceName')"

    # If the device is found, attempt to sync it
    if ($device) {
        try {
            Sync-MgDeviceManagementManagedDevice -managedDeviceId $Device.id
            # Log the successful sync operation
            "$(Get-Date -Format 'dd-MM-yyyy-hhmmss') Sync successful on $DeviceName" | Out-File $log -Append
        } catch {
            # Log the failed sync attempt
            "$(Get-Date -Format 'dd-MM-yyyy-hhmmss') Sync failed on $DeviceName" | Out-File $log -Append
        }
    } else {
        # Log if the device is not found in Intune
        "$(Get-Date -Format 'dd-MM-yyyy-hhmmss') Device $DeviceName not found in Intune" | Out-File $log -Append
    }
}

# Inform the user that the script execution is completed and provide the log file location for review.
Write-Host "Script execution completed. See log file '$log' for status." -ForegroundColor Yellow
