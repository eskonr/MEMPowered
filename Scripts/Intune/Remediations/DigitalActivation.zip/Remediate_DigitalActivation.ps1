﻿<#
.Synopsis
   Check the windows activation status if KMS or subscription activated, if licensed, check if subscription activation or not
.DESCRIPTION
    Updated by: Eswar Koneti (@eskonr)
     Dated: 24-Jun-2023
Ref: https://learn.microsoft.com/en-us/windows/deployment/deploy-enterprise-licenses#step-4-verify-that-enterprise-edition-is-enabled
 #>

# Check Windows Activation Status
$activation = Get-CimInstance -ClassName SoftwareLicensingProduct | ? { $_.PartialProductKey -ne $null }

if ($activation.LicenseStatus -eq '1') {
    # Windows is activated, check PartialProductKey
    if ($activation.PartialProductKey -like "3V66T") {
        Write-output "Subscription"
        exit 0
        }
      else {
      Write-output "KMS or other method"
      exit 0
      }
} else {
    Write-output "Not activated."
     exit 0
    }