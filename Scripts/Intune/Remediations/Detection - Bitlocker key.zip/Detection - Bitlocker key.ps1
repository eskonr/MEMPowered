﻿﻿<#
Deteect if drivbe is bitlocker or not
#>
$BLinfo = Get-BitLockerVolume -MountPoint $env:SystemDrive

if($blinfo.ProtectionStatus -eq 'On')
{
   Write-Host "Drive is bitlocker"
}