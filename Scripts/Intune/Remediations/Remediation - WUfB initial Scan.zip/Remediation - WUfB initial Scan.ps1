﻿<#
.SYNOPSIS
This PowerShell script checks for the existence of a specific registry key and creates a new registry key with a DWORD value if the key does not exist.
This script Allow Windows updates to install before initial user sign-in

.DESCRIPTION
The script checks if the registry key "Microsoft\Windows\CurrentVersion\OOBE\OOBECompleteTimestamp" exists. If the key is present, the script exits. Otherwise, it creates a new registry key "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator" with a DWORD value named "ScanBeforeInitialLogonAllowed" and sets the value data to 1. Additionally, the script logs each action in the specified log file located at "C:\ProgramData\Azure\InstallLogs\install.log".

.NOTES
File Name      : ConfigureRegistry.ps1
Author         : Eswar Koneti
Date           :20-Jan-2024
Reference      :https://learn.microsoft.com/en-us/windows/deployment/update/waas-wu-settings#allow-windows-updates-to-install-before-initial-user-sign-in
#>
# Define registry key paths
$existingRegKeyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\OOBE\OOBECompleteTimestamp"
$checkValue = "OOBECompleteTimestamp"
$createRegKeyPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Orchestrator"
$regValueName = "ScanBeforeInitialLogonAllowed"
$regValueData = 1

# Define log folder and file path
$logFolderPath = "C:\ProgramData\OrgName\InstallLogs"
$logFilePath = Join-Path $logFolderPath "WUfBScan.log"

# Check if the log folder exists, create if not
if (-not (Test-Path $logFolderPath)) {
    Write-Host "Log folder does not exist. Creating folder: $logFolderPath"
    New-Item -Path $logFolderPath -ItemType Directory -Force | Out-Null
    Add-Content -Path $logFilePath -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Log folder created: $logFolderPath.`r`n"
}
# Check if the registry key exists for validation
if (Test-Path $existingRegKeyPath) {
    $registryProperties = Get-ItemProperty -Path $existingRegKeyPath -ErrorAction SilentlyContinue
    if ($registryProperties -and $registryProperties.PSObject.Properties.Name -contains $checkValue) {
        Write-Host "Key '$checkValue' exists"
        Add-Content -Path $logFilePath -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - OOBE completed already. Script exiting.`r`n"
        exit
     }
     }
          
# Create the registry key to allow WUfB scanning without user login
New-Item -Path $createRegKeyPath -Force -ErrorAction SilentlyContinue | Out-Null
New-ItemProperty -Path $createRegKeyPath -Name $regValueName -Value $regValueData -PropertyType DWORD -Force | Out-Null

# Log the registry key creation
Add-Content -Path $logFilePath -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Registry key created: $createRegKeyPath\$regValueName `r`n"
Write-Host "Registry key created."

# End of script