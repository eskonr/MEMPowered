﻿<#
.SYNOPSIS
    Checks if a specific host entry exists in the host file.

.DESCRIPTION
    This function checks if a given IP address and hostname pair exists in the host file.
    For AVD devices, and due to zscalar support matrix, there is a security concern to block the personal emails such as outlook, onedrive storage etc.
    
.PARAMETER HostFile
    The path to the host file where the entries will be checked.

.PARAMETER IPAddress
    The IP address to check in the host file.

.PARAMETER HostName
    The hostname to check in the host file.

. Created by : Eswar Koneti
Dated: 20/07/2023

#>
function Check-HostsEntries {
    param([string]$HostFile, [string]$IPAddress, [string]$HostName)
    $entry = "$IPAddress`t$HostName"
    $existingEntries = Get-Content $HostFile
    $entryExists = $existingEntries -contains $entry
    return $entryExists
}

<#
.SYNOPSIS
    Logs a message to a specified log file.

.DESCRIPTION
    This function logs a message to a log file with the current date and time.

.PARAMETER Message
    The message to be logged.

.PARAMETER LogFile
    The path to the log file where the message will be logged.

#>
function Log-Message {
    param([string]$Message, [string]$LogFile)
    Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $Message"
}

<#
.SYNOPSIS
    Checks and adds host entries to the host file if not already present.

.DESCRIPTION
    This script checks if specified IP address and hostname pairs exist in the host file.
    If all the entries are present, it exits with code 0. Otherwise, it logs the missing entry
    and exits with code 1.

#>
# Define the folder
$folderPath = "C:\programdata\Manulife\Logs"
$logFileName = "lmhost.log"
$logFilePath = Join-Path $folderPath $logFileName

# Check if the folder exists, if not, create it
if (-Not (Test-Path -Path $folderPath -PathType Container)) {
    New-Item -ItemType Directory -Path $folderPath -Force
    Write-Host "Folder created: $folderPath"
}

$hostFile = "C:\windows\system32\drivers\etc\hosts"

# Specify the entries to check
$entriesToCheck = @(
    @{ IPAddress = "127.0.0.1"; HostName = "login.live.com" },
    @{ IPAddress = "127.0.0.1"; HostName = "onedrive.live.com" }
)

$allEntriesExist = $true
foreach ($entry in $entriesToCheck) {
    $entryExists = Check-HostsEntries -HostFile $hostFile -IPAddress $entry.IPAddress -HostName $entry.HostName
    if (-not $entryExists) {
        $allEntriesExist = $false
        Write-Host "Entry not found: $($entry.IPAddress) - $($entry.HostName)"
    }
}

if ($allEntriesExist) {
    Write-Host "All entries found in the host file."
    exit 0
} else {
    Log-Message -Message "Entry $($entry.values) not found in the host file, proceeding to add" -LogFile $logFilePath
    exit 1
}