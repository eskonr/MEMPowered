﻿<#
.SYNOPSIS
    Checks if a specific host entry exists in the host file and correct it as part of the remediation script.

.DESCRIPTION
    This function checks if a given IP address and hostname pair exists in the host file.

.PARAMETER HostFile
    The path to the host file where the entries will be checked.

.PARAMETER IPAddress
    The IP address to check in the host file.

.PARAMETER HostName
    The hostname to check in the host file.

. Created by : Eswar Koneti

#>

function Add-HostEntry {
    param([string]$HostFile, [string]$IPAddress, [string]$HostName)

    $entry = "$IPAddress`t$HostName"
    $existingEntries = Get-Content $HostFile
    $entryExists = $existingEntries -contains $entry

    if (-not $entryExists) {
        # Add the entry to the hosts file
        Add-Content -Path $HostFile -Value $entry
        $result = "Success"
    } else {
        $result = "AlreadyExists"
    }

    return $result
}

function Log-Message {
    param([string]$Message, [string]$LogFile)
    Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $Message"
}


# Define the host entries to add
$hostEntries = @(
    @{ IPAddress = "127.0.0.1"; HostName = "login.live.com" },
    @{ IPAddress = "127.0.0.1"; HostName = "onedrive.live.com" }
)

# Set the path to the host file
$hostFile = "C:\Windows\System32\drivers\etc\hosts"

# Log file path
# Define the folder
$folderPath = "C:\programdata\manulife\Logs"
$logFileName = "lmhost.log"
$logFilePath = Join-Path $folderPath $logFileName

# Check if the folder exists, if not, create it
if (-Not (Test-Path -Path $folderPath -PathType Container)) {
    New-Item -ItemType Directory -Path $folderPath -Force
    Write-Host "Folder created: $folderPath"
}


# Loop through each entry and add it to the hosts file
foreach ($entry in $hostEntries) {
    $result = Add-HostEntry -HostFile $hostFile -IPAddress $entry.IPAddress -HostName $entry.HostName
    if ($result -eq "Success")
    {
    Write-Host "Added entry: $($entry.IPAddress) - $($entry.HostName)"
    Log-Message -Message "Added $($entry.values) to host file" -LogFile $logFilePath
    }
    # Log the result
    #$logEntry = "{0} - {1} {2}" -f (Get-Date), $entry.HostName, $result
    #$logEntry | Out-File -Append -FilePath $logFilePath
}
