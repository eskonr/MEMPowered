﻿#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Remediation script for Intune Proactive Remediation.
    Enables Microsoft-Windows-PrintService/Operational log, sets max size to 10 MB,
    and configures it to overwrite oldest events as needed.

    Author: Eswar Koneti
#>

$LogName    = "Microsoft-Windows-PrintService/Operational"
$TargetSizeKB = 10240   # 10 MB in KB for wevtutil /ms: (bytes)
$TargetSizeBytes = 10485760

try {
    # wevtutil requires the log to be disabled before changing max size in some OS builds,
    # so disable first, apply size/retention, then re-enable.
    & wevtutil.exe set-log $LogName /enabled:false 2>$null

    & wevtutil.exe set-log $LogName /ms:$TargetSizeBytes /rt:false

    & wevtutil.exe set-log $LogName /enabled:true

    # Verify
    $Log = Get-WinEvent -ListLog $LogName -ErrorAction Stop

    if ($Log.IsEnabled -and $Log.MaximumSizeInBytes -ge $TargetSizeBytes) {
        Write-Output "Remediated:Enabled with max size $($Log.MaximumSizeInBytes) bytes."
        exit 0
    }
    else {
        Write-Output "Remediation failed verification: IsEnabled=$($Log.IsEnabled), MaxSize=$($Log.MaximumSizeInBytes)."
        exit 1
    }
}
catch {
    Write-Output "Remediation error: $($_.Exception.Message)"
    exit 1
}