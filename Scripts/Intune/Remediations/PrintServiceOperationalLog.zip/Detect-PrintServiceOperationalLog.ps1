﻿#Detect-PrintServiceOperationalLog.ps1 
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Detection script for Intune Proactive Remediation.
    Checks whether Microsoft-Windows-PrintService/Operational log is enabled
    and sized at 10 MB (10240 KB).

    Author: Eswar Koneti
#>

$LogName    = "Microsoft-Windows-PrintService/Operational"
$TargetSize = 10485760   # 10 MB in bytes (matches wevtutil /ms: units)

try {
    $Log = Get-WinEvent -ListLog $LogName -ErrorAction Stop

    if (-not $Log.IsEnabled) {
        Write-Output "Non-Compliant: Logging is disabled"
        exit 1
    }

    if ($Log.MaximumSizeInBytes -lt $TargetSize) {
        Write-Output "Non-Compliant: Max log size is $($Log.MaximumSizeInBytes) bytes, expected at least $TargetSize bytes."
        exit 1
    }

    Write-Output "Compliant:Enabled with max size $($Log.MaximumSizeInBytes) bytes."
    exit 0
}
catch {
    Write-Output "Non-Compliant: Unable to query log '$LogName'. Error: $($_.Exception.Message)"
    exit 1
}