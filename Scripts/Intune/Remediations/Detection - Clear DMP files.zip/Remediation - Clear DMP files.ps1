<#
.SYNOPSIS
Deletes DMP files from the LocalService Temp folder when the cumulative
size of DMP files is greater than or equal to 1 GB.

.DESCRIPTION
This script checks:

C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp

for *.dmp files.

Cleanup is performed when:
- One or more DMP files exist
- Total DMP size is 1 GB or larger

The script reports:
- Number of files deleted
- Space reclaimed in GB

.NOTES
Author: Eswar Koneti
Purpose: Intune Remediation Script
#>

$FolderPath = 'C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp'
$LogFolder = 'C:\ProgramData\eskonr\InstallLogs'
$LogFilePath = Join-Path $LogFolder 'remediation-cleandmpfiles.log'

# Ensure log folder exists
if (-not (Test-Path $LogFolder)) {
	New-Item -Path $LogFolder -ItemType Directory -Force | Out-Null
}

function Write-Log {
	param(
		[string]$Message
	)

	$timestamp = Get-Date -Format 'dd-MM-yyyy HH:mm:ss'
	$entry = "[$timestamp] $Message"

	# Write to console (for Intune) and to log file
	Write-Output $entry
	Add-Content -Path $LogFilePath -Value $entry
}

Write-Log "Script started. Checking folder: $FolderPath"

if (-not (Test-Path $FolderPath)) {
	Write-Log 'Folder not found'
	exit 0
}

$DmpFiles = Get-ChildItem -Path $FolderPath -Filter '*.dmp' -File -ErrorAction SilentlyContinue
$FileCount = @($DmpFiles).Count
$TotalBytes = ($DmpFiles | Measure-Object -Property Length -Sum).Sum

if ($null -eq $TotalBytes) {
	$TotalBytes = 0
}

$TotalGB = [math]::Round(($TotalBytes / 1GB), 2)

Write-Log "Found files: $FileCount; TotalBytes=$TotalBytes; TotalGB=$TotalGB"

if ($FileCount -eq 0) {
	Write-Log 'No DMP files found'
	exit 0
}

if ($TotalGB -lt 1) {
	Write-Log "Files found but below threshold. Files=$FileCount; SizeGB=$TotalGB"
	exit 0
}

try {
	Write-Log 'Threshold met. Starting cleanup of *.dmp files.'

	Remove-Item -Path (Join-Path $FolderPath '*.dmp') -Force -ErrorAction Stop

	Write-Log "Cleanup successful. DeletedFiles=$FileCount; ReclaimedGB=$TotalGB"
	exit 0
} catch {
	Write-Log "Cleanup failed. Error=$($_.Exception.Message)"
	exit 1
}