<#
.SYNOPSIS
Detects DMP files in the LocalService Temp folder and triggers Intune Remediation
when one or more DMP files exist and the combined size is greater than or equal
to 1 GB.

.DESCRIPTION
This script checks:

C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp

for *.dmp files.

The script calculates:
- Number of DMP files
- Total size of DMP files

Detection result:
- Exit 0 = No remediation required
- Exit 1 = Remediation required

Remediation is triggered when:
- At least 1 DMP file exists
- Total DMP size is 1 GB or larger

.NOTES
Author: Eswar Koneti
Purpose: Intune Remediation Detection Script
#>

$FolderPath = "C:\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"

if (-not (Test-Path $FolderPath)) {
    Write-Output "Folder not found"
    exit 0
}

$DmpFiles = Get-ChildItem -Path $FolderPath -Filter "*.dmp" -File -ErrorAction SilentlyContinue

$FileCount  = @($DmpFiles).Count
$TotalBytes = ($DmpFiles | Measure-Object -Property Length -Sum).Sum

if ($null -eq $TotalBytes) {
    $TotalBytes = 0
}

$TotalGB = [math]::Round($TotalBytes / 1GB, 2)

if ($FileCount -ge 1 -and $TotalGB -ge 1) {
    Write-Output "Files=$FileCount; SizeGB=$TotalGB"
    exit 1
}
else {
    Write-Output "No DMP files found or size below threshold"
    exit 0
}