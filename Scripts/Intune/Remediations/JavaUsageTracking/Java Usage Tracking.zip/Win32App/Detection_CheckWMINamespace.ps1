﻿<#
Description:
This PowerShell script checks for the existence of the CM_JavaUsageTracking class within the root\cimv2 namespace.
It is designed to be used as a detection method in environments such as Microsoft Intune, where detecting the presence of specific configurations is necessary for compliance and management.
Author:Eswar Koneti
Date:29-Jul-2025
Reference: https://github.com/ChrisKibble/JavaUsageTracking/blob/master/JavaUsageTracking.ps1

#>

# Define the namespace and class name to check
$namespace = 'root\cimv2'
$className = 'CM_JavaUsageTracking'

if ( Get-WmiObject -Namespace $namespace -Class $className -ErrorAction Stop) {
    # If successful, the class exists
    Write-Host 'JavaNameClassExist'
    exit 0
} else {
    # If an error occurs, the class does not exist
    Write-Host 'JavaNameClassNOTExist'
    exit 1
}