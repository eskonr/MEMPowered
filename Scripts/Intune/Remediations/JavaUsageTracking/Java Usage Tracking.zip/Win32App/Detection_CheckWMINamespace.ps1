﻿<#
Description: 
This PowerShell script checks for the existence of the CM_JavaUsageTracking class within the root\cimv2 namespace.
It is designed to be used as a detection method in environments such as Microsoft Intune, where detecting the presence of specific configurations is necessary for compliance and management.
Author:Eswar Koneti
Date:29-Jul-2025
Reference: https://github.com/ChrisKibble/JavaUsageTracking/blob/master/JavaUsageTracking.ps1

#>

# Define the namespace and class name to check
$namespace = "root\cimv2"
$className = "CM_JavaUsageTracking"

try {
    # Attempt to get the CIM class
    Get-CimClass -Namespace $namespace -ClassName $className -ErrorAction Stop | Out-Null
    
    # If successful, the class exists
    Write-Host "Namespace and class exist"
    exit 0
} catch {
    # If an error occurs, the class does not exist
    Write-Host "Namespace or class does not exist"
    exit 1
}