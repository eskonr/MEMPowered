﻿<#
Description: 
This PowerShell script checks for the existence of Java 32 or 64 bit as part of the intune requirement rule.
If Java installed then the script will allow to run on the device to create custom WMI namespace for Java usage tracking.
This WMI instance data is being captured using Log analytics at a later part.
Author:Eswar Koneti
Date:29-Jul-2025
Reference: https://github.com/ChrisKibble/JavaUsageTracking/blob/master/JavaUsageTracking.ps1
#>

# Define the registry paths to check
$registryPaths = @(
    'HKLM:\Software\WOW6432Node\JavaSoft\Java Runtime Environment',
    'HKLM:\Software\JavaSoft\Java Runtime Environment'
)

# Check if any of the registry keys exists
$javaInstalled = $false

foreach ($path in $registryPaths) {
    if (Test-Path -Path $path) {
        $javaInstalled = $true
        break
    }
}

# Determine exit code based on whether Java is installed
if ($javaInstalled) {
    Write-Host "FoundJava"
    exit 0
} else {
    Write-Host "NotFoundJava"
    exit 1
}