# Define the namespace and class name to check
$namespace = 'root\cimv2'
$className = 'CM_JavaUsageTracking'

# Define the namespace and class name to check
$namespace = "root\cimv2"
$className = "CM_JavaUsageTracking"

    # Check if the WMI class exists in the specified namespace
    $cimClass = Get-WmiObject -Namespace $namespace -Class $className -ErrorAction Stop
    if ($cimClass)
    {
    try {
    # If the class is found, proceed to delete it
    Write-Host "Namespace and class exist. Deleting..."
    $cimClass.Delete()
    Write-Host "Class deleted successfully."
    exit 0
} catch {
    # If an error occurs, it might be because the class does not exist
    if ($_.Exception.Message -like "*not found*") {
        Write-Host "Namespace or class does not exist. Nothing to delete."
    } else {
        Write-Host "An error occurred: $_"
    }
    exit 1
}
}
else {
Write-Host "WMI class not found."
    exit 0

}