﻿<#
.SYNOPSIS
    Collect Java Usage tracking information from the WMI name class CM_JavaUsageTracking, that is being generated on devices using remediation/other methods.

.DESCRIPTION
    This script will collect the Java usage tracking details to the Log analytics for custom reporting.
    Based on this data, we can analyse the devices that are using Java application and take deceision if the Java can be removed from devices where Java has no value.

.EXAMPLE
    Invoke-CustomInventory.ps1 (Required to run as System or Administrator)

.NOTES
    FileName:    Invoke-CustomInventory.ps1
    Author:      Eswar Koneti
    This requires the Java usage tracking that create namespace as per https://github.com/ChrisKibble/JavaUsageTracking/blob/master/JavaUsageTracking.ps1
#>

#region initialize
# Enable TLS 1.2 support
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# Replace with your Log Analytics Workspace ID
$CustomerId = "dfdfdfdfdf-4a4f-8dfdfdfe45-dfdfdfdfdfdfdf"

# Replace with your Primary Key
$SharedKey = "dffdfdfdfdfULZpsTSm0p9Rvdfdfdfdfdfflr+ZzvFtQ=="

#Control if you want to collect App or Device Inventory or both (True = Collect)
$CollectJavaUsageTracking = $true

#Log Analytics table to be created
$CollectJavaUsageTrackingLogName="JavaUsageTracking"

$Date = (Get-Date)

# You can use an optional field to specify the timestamp from the data. If the time field is not specified, Azure Monitor assumes the time is the message ingestion time
# DO NOT DELETE THIS VARIABLE. Recommened keep this blank.
$TimeStampField = ""

# Function to send data to log analytics
Function Send-LogAnalyticsData() {
	<#
   .SYNOPSIS
	   Send log data to Azure Monitor by using the HTTP Data Collector API

   .DESCRIPTION
	   Send log data to Azure Monitor by using the HTTP Data Collector API

   .NOTES

   #>
   param(
	   [string]$sharedKey,
	   [array]$body,
	   [string]$logType,
	   [string]$customerId
   )
   #Defining method and datatypes
   $method = "POST"
   $contentType = "application/json"
   $resource = "/api/logs"
   $date = [DateTime]::UtcNow.ToString("r")
   $contentLength = $body.Length
   #Construct authorization signature
   $xHeaders = "x-ms-date:" + $date
   $stringToHash = $method + "`n" + $contentLength + "`n" + $contentType + "`n" + $xHeaders + "`n" + $resource
   $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
   $keyBytes = [Convert]::FromBase64String($sharedKey)
   $sha256 = New-Object System.Security.Cryptography.HMACSHA256
   $sha256.Key = $keyBytes
   $calculatedHash = $sha256.ComputeHash($bytesToHash)
   $encodedHash = [Convert]::ToBase64String($calculatedHash)
   $signature = 'SharedKey {0}:{1}' -f $customerId, $encodedHash

   #Construct uri
   $uri = "https://" + $customerId + ".ods.opinsights.azure.com" + $resource + "?api-version=2016-04-01"

   #validate that payload data does not exceed limits
   if ($body.Length -gt (31.9 *1024*1024))
   {
	   throw("Upload payload is too big and exceed the 32Mb limit for a single upload. Please reduce the payload size. Current payload size is: " + ($body.Length/1024/1024).ToString("#.#") + "Mb")
   }
   $payloadsize = ("Upload payload size is " + ($body.Length/1024).ToString("#.#") + "Kb ")

   #Create authorization Header
   $headers = @{
	   "Authorization"        = $signature;
	   "Log-Type"             = $logType;
	   "x-ms-date"            = $date;
	   "time-generated-field" = $TimeStampField;
   }
   #Sending data to log analytics
   $response = Invoke-WebRequest -Uri $uri -Method $method -ContentType $contentType -Headers $headers -Body $body -UseBasicParsing
   $statusmessage = "$($response.StatusCode) : $($payloadsize)"
   return $statusmessage
}#end function

#Region to collect the WMI namespace for Java tracking usage



if ($CollectJavaUsageTracking) {

 # Define the namespace and class name
$namespace = "root\cimv2"
$className = "CM_JavaUsageTracking"
$checkNameClass=Get-WmiObject -Namespace $namespace -Class $className -ErrorAction SilentlyContinue
if ($checkNameClass)
{
  #Get all instances of the WMI class
  #Write-Host "Name class found"
    $wmiInstances = Get-WmiObject -Namespace $namespace -Class $className -ErrorAction SilentlyContinue

    # Select only the desired properties
    $selectedAttributes = $wmiInstances | Select-Object Command, DateTime, HostIP, JavaVen, JavaVer, JREPath, JREVer, JVMVen, Type, User, PSComputerName
    $CollectJavaUsageTrackingjson = $selectedAttributes | ConvertTo-Json
}
else
{Write-host "WMi nameclass '$className' not found"}

}
if ($null -ne $CollectJavaUsageTrackingjson)
{
Write-host "We got data to send to Log analytics"
#endregion DEVICEINVENTORY

# Submit the data to the API endpoint
$ResponseCollectJavaUsageTracking = Send-LogAnalyticsData -customerId $customerId -sharedKey $sharedKey -body ([System.Text.Encoding]::UTF8.GetBytes($CollectJavaUsageTrackingjson)) -logType $CollectJavaUsageTrackingLogName

#Report back status
$date = Get-Date -Format "dd-MM HH:mm"
$OutputMessage = "InventoryDate:$date "


if ($CollectJavaUsageTracking) {
    if ($ResponseCollectJavaUsageTracking -match "200 :") {

        $OutputMessage = $OutPutMessage + "CollectJavaUsageTracking:OK " + $ResponseCollectJavaUsageTracking
    }
    else {
        $OutputMessage = $OutPutMessage + "CollectJavaUsageTracking:Fail "
    }
}


Write-Output $OutputMessage
}
Exit 0
#endregion script