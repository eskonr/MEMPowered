﻿
# Check if the Maps app is installed
$appFound = Get-AppxPackage -Name *windowsmaps* -AllUsers -ErrorAction SilentlyContinue

# Output a result code for Intune
if ($appFound) {
    # If the app is found, output a non-zero exit code, go to remediation
    write-host "Maps found, Remediation required"
    exit 1
} else {
    # If the app is not found, output a zero exit code, no remediation required
    write-host "Maps not found, all good"
    exit 0
}