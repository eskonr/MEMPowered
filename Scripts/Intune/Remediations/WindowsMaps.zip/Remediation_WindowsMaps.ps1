﻿#This script removes the Maps app if it is detected and logs the action.
<#
Microsoft has deprecated the Windows Maps app starting july 2025.
This script is going to check if windowsmaps installed, perform uninstall and create a log for reference
https://learn.microsoft.com/en-us/windows/whats-new/deprecated-features-resources

Author: Eswar Koneti
Date:10-Sep-2025
#>

# Define the log file path
$logFilePath = "C:\ProgramData\eskonr\InstallLogs\UninstallWindowsMaps.log"

# Function to write to the log file
function Write-Log {
    param (
        [string]$message
    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "$timestamp - $message"
    Add-Content -Path $logFilePath -Value $logMessage
}

# Check if the Maps app is installed
$appFound = Get-AppxPackage -Name *windowsmaps* -AllUsers -ErrorAction SilentlyContinue

if ($appFound) {
    # If the app is found, remove it
    try {
        Remove-AppxPackage -Package $appFound.PackageFullName -AllUsers
        Write-Log "Maps app detected and removed successfully."
        } catch {
        Write-Log "Error removing Maps app: $_"
        exit 1
    }
} else {
    # If the app is not found, log that no action was needed
    Write-Log "Maps app not detected. No removal action needed."
}

# Output a zero exit code to indicate successful remediation
exit 0