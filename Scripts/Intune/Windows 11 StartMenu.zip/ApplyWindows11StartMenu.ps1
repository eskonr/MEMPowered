<#
File:ApplyWindows11CustomStartMenu.ps1

Description:
With vendor shipping Windows 11 pro devices and the stattmenu has all junk/bloatware application links in the startmenu,
We will need to have mechanism that helps to clean the startmenu and apply a new startmenu.
The following script helps to copy the custom captured statemenu with Office, company portal and Teams application in Startmenu for all new users logged into the device
If you want to create custom startmenu, on windows 11, pin the apps, and copy the bin file to deploy to other devices.
Location where startmenu located: %LocalAppData%\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState

Author: Eswar Koneti
Date:19-Nov-2024

#>
# Define the source and destination paths
$scriptpath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$sourceFile = "$dir\start2.bin"
$destinationFolder = "C:\Users\default\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState"
$logFolder = 'C:\ProgramData\eskonr\InstallLogs'
$logFile = "$logFolder\Startmenu.log"

# Function to write log
function Write-Log {
	param (
		[string]$message
	)
	$timestamp = Get-Date -Format 'dd-MM-yyyy HH:mm:ss'
	$logMessage = "$timestamp - $message"
	Add-Content -Path $logFile -Value $logMessage
}

# Create log folder if it doesn't exist
if (-not (Test-Path -Path $logFolder)) {
	New-Item -Path $logFolder -ItemType Directory -Force
}

# Create $destinationFolder folder if it doesn't exist
if (-not (Test-Path -Path $destinationFolder)) {
	New-Item -Path $destinationFolder -ItemType Directory -Force
}

	# Copy the file
	try
	{
	Copy-Item -Path $sourceFile -Destination $destinationFolder -Force

	# Verify if the copy was successful
	$destinationFile = Join-Path -Path $destinationFolder -ChildPath (Get-Item $sourceFile).Name
	if (Test-Path -Path $destinationFile) {
		Write-Log -message "File $($sourceFile) copied successfully to $destinationFile"
	} else {
		throw 'File copy failed'
	}
}
	catch {
	# Log any errors
	Write-Log -message "Error: $_"
}
exit