<#
File:DetectionCustomWindows11StartMenu.ps1

Description:
This script helps to check if Start2.bin file exist or not.
Start2.bin file is custom startmenu that is used to replace the default startmenu with boatware apps/links in Windows pro edition.
If you want to create custom startmenu, on windows 11, pin the apps, and copy the bin file to deploy to other devices.
Location where startmenu located: %LocalAppData%\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState

Author: Eswar Koneti
Date:19-Nov-2024

#>

$fileExists = Test-Path -Path "C:\Users\Default\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState\start2.bin"

if ($fileExists) {
	Write-Host 'The file exists.'
	Write-Output $true
	exit 0
}