@echo off
REM Title Applying Windows 11 Custom Start Menu
powershell.exe -executionpolicy bypass -file ".\ApplyWindows11StartMenu.ps1"