﻿<#
.Synopsis
   Get the list of settings along with policy names deployed to the devices.
   This does not list applications, remediations, scripts etc. This is purely for device configuration policies, endpoint security, wufb update rings.
.DESCRIPTION
  For a given Intune device name (or a file containing device names), this script connects to Microsoft Graph (Mg Graph) and Azure AD, performing the following actions:
    -Validates that each device is present in Azure AD and is Windows-based; otherwise, it skips to the next device.
    -Identifies all policies assigned to the specified device object and generates a report detailing the status of each setting along with its overall status.
  This script handles the installation of the required PowerShell module, Microsoft.Graph.Devicemanagement.
  Users must have access to the Microsoft Graph PowerShell application with scoped permissions for DeviceManagementConfiguration.Read.All and DeviceManagementManagedDevices.Read.All.
 
.Author: Eswar Koneti ( special thanks to Leon Zhu (MS support engineer))
.Dated: 12-Jan-2024
.Usage:
  Running the script prompts for a device or a list of devices from a text file.
  The script then creates a folder with the current date and generates a CSV file for each device. 
  Each csv file contains a list of all settings, status, and associated profile names.
  Script also has html code which can be enabled at line 667.
     
#>

#Define variables
#Get the current script directory
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
#Get the script execution date                  
$date = (Get-Date -f ddMMyyyy_hhmmss)
$o_ScriptLaunchTime = Get-Date
$s_Year = [string]($o_ScriptLaunchTime.Year)
$s_Month = [string]($o_ScriptLaunchTime.Month)
if ($s_Month.Length -eq 1) { $s_Month = "0$s_Month" }
$s_Day = [string]($o_ScriptLaunchTime.Day)
if ($s_Day.Length -eq 1) { $s_Day = "0$s_Day" }

#Dont modify anything below this section unless you know what you are doing.

#######################################################################

function ConnectToGraph
{
  $requiredModules = @("Microsoft.Graph.Devicemanagement","Microsoft.Graph","Microsoft.Graph.Authentication")

  foreach ($module in $requiredModules) {
    if (Get-Module -ListAvailable -Name $module) {
      Write-Host "$module Module is already installed."
    } else {
      Write-Host "$module Module does not exist, installing..."
      Install-Module -Name $module -Scope CurrentUser -Force
    }
  }

  #Perform Authentication
  try {
    Connect-MgGraph -Scopes "DeviceManagementManagedDevices.ReadWrite.All","DeviceManagementConfiguration.ReadWrite.All" -ErrorAction Stop
  } catch {
    Write-Host ""
    Write-Host "Unable to make connection to MG Graph, please try again.." -ForegroundColor Red

    # Check the exit code
    if ($LASTEXITCODE -ne 0) {
      Write-Host "Authentication unsuccessful. Exiting script." -ForegroundColor Red
      exit $LASTEXITCODE
    }

    # Handle other exceptions
    Write-Host "An unexpected error occurred. Exiting script." -ForegroundColor Red
    exit 1
  }

}

#######################################################################

function Get-devicepolicies ()
{
  param
  (
    [Parameter(Mandatory = $true)] $deviceId
  )
  $allreuslt = @()
  $skiptop = 0
  do {
    $json = @{
      select = @(
        "IntuneDeviceId",
        "PolicyBaseTypeName",
        "PolicyId",
        "PolicyStatus",
        "UPN",
        "UserId",
        "PspdpuLastModifiedTimeUtc",
        "PolicyName",
        "UnifiedPolicyType"
      )
      filter = "((PolicyBaseTypeName eq 'Microsoft.Management.Services.Api.DeviceConfiguration') or (PolicyBaseTypeName eq 'DeviceManagementConfigurationPolicy') or (PolicyBaseTypeName eq 'DeviceConfigurationAdmxPolicy') or (PolicyBaseTypeName eq 'Microsoft.Management.Services.Api.DeviceManagementIntent')) and (IntuneDeviceId eq '$deviceID' )"
      skip = $skiptop
      top = 50
      orderBy = @("PolicyName") } | ConvertTo-Json

    Write-Output $json
    $filePath = "$dir\policytempfile.txt"
    $deviceinfo = Invoke-MgGraphRequest `
       -Uri "beta/deviceManagement/reports/getConfigurationPoliciesReportForDevice" `
       -Method POST `
       -Body $json `
       -OutputFilePath $filePath

    # Read the contents of the text file
    $text = Get-Content -Path $filePath -Raw
    # Convert the text to JSON
    $jsonResult = $text | ConvertFrom-Json
    $skiptop += 50
    $allreuslt += $jsonResult
  } while ($jsonResult.values.count -ge 50)
  #$subsettinginfo += $Fomatpolicysettings
  # Access the converted JSON object
  return $allreuslt
}

####################################################
function Export-policyDetail () {
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)] $Policies
  )
  $policyInfo = @()
  foreach ($policy in $Policies) {
    $info = New-Object -TypeName psobject
    $info | Add-Member -MemberType NoteProperty -Name PolicyID -Value $policy[2]
    $info | Add-Member -MemberType NoteProperty -Name PolicyBaseTypeName -Value $policy[1]
    $info | Add-Member -MemberType NoteProperty -Name PolicyNAme -Value $policy[3]
    $info | Add-Member -MemberType NoteProperty -Name PolicyType -Value $policy[7]
    $info | Add-Member -MemberType NoteProperty -Name LoggedUser -Value $policy[8]
    $info | Add-Member -MemberType NoteProperty -Name UserID -Value $policy[9]
    <#
                    PolicyStatus
                    0= unknown
                    1= notApplicable
                    2= Compliant
                    3= Remediated
                    4= Noncompliant
                    5= Error
                    6= Conflict
                    7= InProgress
                    #>

    switch ($policy[4]) {
      "1" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Not applicable"
      }
      "2" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Compliant"
      }
      "3" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Remediated"
      }
      "4" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Noncompliant"
      }
      "5" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Error"
      }
      "6" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Conflict"
      }
      "7" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "InProgress"
      }
      "0" {
        $info | Add-Member -MemberType NoteProperty -Name Stats -Value "Unknown"
      }
    }

    # get policySettinDetails 
    <#
                    $deviceId = $policy[0]
                    $policyId = $policy[2]
                    $userId = $policy[5]
                    #>
    #  $thispolicysetting = Get-PolicySettingsReport -policyId $policy[2] -userId $policy[9] -deviceId $policy[0] -PolicyBaseTypeName $policy[1]
    #$info | Add-Member -MemberType NoteProperty -Name Subsettings -Value  $thispolicysetting
    $policyInfo += $info
  }
  return $policyInfo
}
####################################################
<#
            PolicyBaseTypeName.DeviceConfiguration,
            PolicyBaseTypeName.DeviceManagementConfigurationPolicy,
            PolicyBaseTypeName.DeviceConfigurationAdmxPolicy,
            PolicyBaseTypeName.DeviceIntent
#>
function Get-PolicySettingsReport
{
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)] $policyId,
    $deviceId,
    $userId,
    $PolicyBaseTypeName
  )

  $json = @()
  $allreuslt = @()
  $skiptop = 0

  do {
    $jsonforothers = @{
      select = @(
        "SettingName"
        "SettingStatus"
        "ErrorCode"
        "SettingInstanceId"
        "SettingInstancePath"
      )
      skip = $skiptop
      top = 50
      filter = "(PolicyId eq '$policyId') and (DeviceId eq '$deviceId') and (UserId eq '$userId')"
      orderBy = @()
    } | ConvertTo-Json

    $jsonforConfigurationSettingsReport = @{
      select = @(
        "SettingName"
        "SettingStatus"
        "ErrorCode"
        "SettingId"
        "SettingInstanceId"
      )
      skip = $skiptop
      top = 50
      filter = "(PolicyId eq '$policyId') and (DeviceId eq '$deviceId') and (UserId eq '$userId')"
      orderBy = @()
    }

    switch ($PolicyBaseTypeName) {
      "Microsoft.Management.Services.Api.DeviceConfiguration" {
        $url = "beta/deviceManagement/reports/getConfigurationSettingNoncomplianceReport"
        $json = $jsonforothers
      }
      "DeviceConfigurationAdmxPolicy" {
        $url = "beta/deviceManagement/reports/getGroupPolicySettingsDeviceSettingsReport"
        $json = $jsonforothers
      }
      "DeviceManagementConfigurationPolicy" {
        $url = "beta/deviceManagement/reports/getConfigurationSettingsReport"
        $json = $jsonforConfigurationSettingsReport
      }
    }

    if (-not $url) {
      #  Write-Host "Error: The URL is null. Please ensure it is properly set." -ForegroundColor Red
      return $null
    }

    $filePath = "$dir\configurationtempfile.txt"

    try {
      # Use try-catch to handle errors during Invoke-MgGraphRequest
      $policySettings = Invoke-MgGraphRequest -Uri $url -Method POST -Body $json -OutputFilePath $filePath -ErrorAction Stop
    } catch {
      Write-Host "Error: $_" -ForegroundColor Red
      return $null
    }

    $text = Get-Content -Path $filePath -Raw
    $skiptop += 50

    # Convert the text to JSON
    $policySettings = $text | ConvertFrom-Json
    $allreuslt += $policySettings
  } while ($policySettings.values.count -ge 50)

  return $allreuslt
}
#######################################################################
function Export-policySettingDetail () {
  #This function use to modify output from getConfigurationPoliciesReportForDevice and format as policy status and result.
  [CmdletBinding()]
  param
  (
    [Parameter(Mandatory = $true)] $PolicySettings
  )
  <#
                                    "SettingName"
		                            "SettingStatus"
		                            "ErrorCode"
		                            "SettingInstanceId"
		                            "SettingInstancePath"
                            #>
  $info = New-Object -TypeName psobject

  $info | Add-Member -MemberType NoteProperty -Name SettingName -Value $PolicySettings[3]
  $info | Add-Member -MemberType NoteProperty -Name SettingPath -Value $PolicySettings[2]

  <#
                                        SettingStatus

 
                                        case 0: return Unknown;
                                        case 1: return NotApplicable;
                                        case 2: return Compliant;
                                        case 3: return Remediated;
                                        case 4: return NotCompliant;
                                        case 5: return Error;
                                        case 6: return Conflict;
 
                                        #>
  switch ($PolicySettings[4]) {
    "1" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Not applicable"
    }
    "2" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Compliant"
    }
    "3" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Remediated"
    }
    "4" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Noncompliant"
    }
    "5" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Error"
    }
    "6" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Conflict"
    }
    "0" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Unknown"
    }
  }
  return $info
}

#######################################################################

function Export-DeviceManagementConfigurationPolicySettingDetail () {


  #This function use to modify output from getConfigurationPoliciesReportForDevice and format as policy status and result.

  [CmdletBinding()]

  param
  (
    [Parameter(Mandatory = $true)] $PolicySettings
  )

  <#
                                    "SettingName"
		                            "SettingStatus"
		                            "ErrorCode"
		                            "SettingInstanceId"
		                            "SettingInstancePath"
                            #>
  $info = New-Object -TypeName psobject

  $info | Add-Member -MemberType NoteProperty -Name SettingName -Value $PolicySettings[5]
  #   $info | Add-Member -MemberType NoteProperty -Name SettingPath -Value $PolicySettings[2]


  <#
                                        SettingStatus

 
                                        case 0: return Unknown;
                                        case 1: return NotApplicable;
                                        case 2: return Compliant;
                                        case 3: return Remediated;
                                        case 4: return NotCompliant;
                                        case 5: return Error;
                                        case 6: return Conflict;
 
                                        #>
  switch ($PolicySettings[4]) {
    "1" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Not applicable"
    }
    "2" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Compliant"
    }
    "3" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Remediated"
    }
    "4" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Noncompliant"
    }
    "5" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Error"
    }
    "6" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Conflict"
    }
    "0" {
      $info | Add-Member -MemberType NoteProperty -Name SettingStatus -Value "Unknown"
    }
  }
  return $info
}

#######################################################################

#Start gathering the data from the above functions using below section

#######################################################################

ConnectToGraph
#Select-MgProfile -Name "beta"
Write-Host "To search Intune for assigned objects, enter either the full name of an Intune device or a filename (e.g. 'Somedevices.txt') in this script's folder containing multiple Intune devices: " -ForegroundColor Yellow
$DeviceName = Read-Host
#What was provided?
if ($DeviceName.EndsWith(".txt"))
{
  #It's a file
  #Confirm the file exists
  if (!(Test-Path -Path "$Dir\$DeviceName"))
  {
    #File does not exist
    Write-Host ""
    Write-Host "Provided filename of devices cannot be found.  Try again." -ForegroundColor Red
    Write-Host ""
    #Wait for the user...
    Read-Host -Prompt "When ready, press 'Enter' to exit..."
    exit
  }
  else
  {
    #File exists - get data into an array
    $a_DeviceNames = Get-Content "$Dir\$DeviceName"
    if ($a_DeviceNames.count -eq 0)
    {
      #No data in file
      Write-Host ""
      Write-Host "Provided filename of devices is empty.  Try again." -ForegroundColor Red
      Write-Host ""
      #Wait for the user...
      Read-Host -Prompt "When ready, press 'Enter' to exit..."
      exit
    }
    elseif ($a_DeviceNames.count -eq 1)
    {
      #It's a single device
      #No need to pause
      $b_Pause = $false
    }
  }
}
else
{
  #It's a single device
  $a_DeviceNames = @($DeviceName)

  #No need to pause
  $b_Pause = $false
}
Write-Host ""

#Ensure output folder is created
$s_Folder = "$Dir\" + "$s_Year$s_Month$s_Day"
if (!(Test-Path -Path $s_Folder))
{
  #Folder does not exist
  New-Item $s_Folder -Type directory
}

Clear-Host
Write-Host "Data validation is in progress ..." -ForegroundColor Green
$i_TotalDevices = $a_DeviceNames.count
Write-Host ""
Write-Host "Total devices found : $i_TotalDevices . Press 'Enter' to report on all objects, or type 'n' then press 'Enter' exit the script: " -ForegroundColor Yellow -NoNewline
$Scope = Read-Host
if ($Scope -ieq "n")
{
  $b_ScopeAll = $false
}
else
{
  $b_ScopeAll = $true
}
Write-Host ""
Clear-Host

#Continue to report the data for all device objects
if ($b_ScopeAll)
{

  foreach ($DeviceName in $a_DeviceNames)
  {
    #Clear-Host

    $device = (Get-MgDeviceManagementManagedDevice -Filter "devicename eq '$DeviceName'" | Select-Object id,deviceName,AzureAdDeviceId,userprincipalname)
    if ($device)
    {

      Write-Host "Device Name: `'$DeviceName`' found in Entra ID. Searching for policies, please wait..." -ForegroundColor Green

      $deviceID = $device.id

      $jsonResult = Get-devicepolicies -DeviceId $deviceID
      $PolicyConfigurationresults = Export-policyDetail -Policies $jsonResult.values
      $allPolicyInformationofdevice = @()

      #$thispolicysetting = Get-policySettings -policyId $policyId -userId $userId -deviceId $deviceId
      foreach ($configuration in $PolicyConfigurationresults)
      {

        $thispolicysetting = Get-PolicySettingsReport -policyId $configuration.PolicyID -UserId $configuration.userId -DeviceId $deviceID -PolicyBaseTypeName $configuration.PolicyBaseTypeName

        $info = New-Object -TypeName psobject
        $info | Add-Member -MemberType NoteProperty -Name PolicyType -Value $configuration.PolicyType
        $info | Add-Member -MemberType NoteProperty -Name PolicyNAme -Value $configuration.PolicyNAme
        $info | Add-Member -MemberType NoteProperty -Name LoggedUser -Value $configuration.LoggedUser
        $info | Add-Member -MemberType NoteProperty -Name Status -Value $configuration.Stats


        $subsettinginfo = @()
        foreach ($setting in $thispolicysetting.values)
        {


          if ($configuration.PolicyBaseTypeName -eq "DeviceManagementConfigurationPolicy")
          {
            $Fomatpolicysettings = Export-DeviceManagementConfigurationPolicySettingDetail -PolicySettings $setting

          }
          else
          {
            $Fomatpolicysettings = Export-policySettingDetail -PolicySettings $setting

          }

          # Write-host  $Fomatpolicysettings
          # Write-host "##############################################################################################################"


          $subsettinginfo += $Fomatpolicysettings
        }

        $subsettinginfo | Add-Member -MemberType NoteProperty -Name LoggedUser -Value $configuration.LoggedUser
        $subsettinginfo | Add-Member -MemberType NoteProperty -Name PolicyName -Value $configuration.PolicyNAme

        #$subsettinginfoString =  ($subsettinginfo | Out-String).Trim()

        # $subsettinginfo | Add-Member -MemberType NoteProperty -Name SubsettingInfo -Value $subsettinginfoString

        $allPolicyInformationofdevice += $subsettinginfo
      }

      #export report in CSV format
      $allPolicyInformationofdeviceCSV = $allPolicyInformationofdevice
      #The following line is used to export the data into csv format
      $allPolicyInformationofdeviceCSV | Export-Csv "$s_Folder\RSOP_$($device.DeviceName)_$($date).csv" -NoTypeInformation
      #export report in HTML format

      $allPolicyInformationofdevice = $allPolicyInformationofdevice | Select-Object | ConvertTo-Html -Property SettingName,SettingPath,SettingStatus,LoggedUser,PolicyName
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Compliant</td>','<td class="Compliant">Compliant</td>'
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Conflict</td>','<td class="Conflict">Conflict</td>'
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Not applicable</td>','<td class="NotApplicable">Not applicable</td>'
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Error</td>','<td class="Error">Error</td>'
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Noncompliant</td>','<td class="Noncompliant">Noncompliant</td>'
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Remediated</td>','<td class="Remediated">Remediated</td>'
      $allPolicyInformationofdevice = $allPolicyInformationofdevice -replace '<td>Unknown</td>','<td class="Unknown">Unknown</td>'

      #export the data to output CSV file
      #Thanks to https://adamtheautomator.com/html-report/

      $ComputerName = "<h1>Computer name: $($device.DeviceName)</h1>"

      #CSS codes
      $header = @"
<style>
 
    h1 {
 
        font-family: Arial, Helvetica, sans-serif;
        color: #e68a00;
        font-size: 28px;
 
    }
 
    
    h2 {
 
        font-family: Arial, Helvetica, sans-serif;
        color: #000099;
        font-size: 16px;
 
    }
 
    
   table {
		font-size: 12px;
		border: 0px; 
		font-family: Arial, Helvetica, sans-serif;
	} 
    td {
		padding: 4px;
		margin: 0px;
		border: 0;
	}
    th {
        background: #395870;
        background: linear-gradient(#49708f, #293f50);
        color: #fff;
        font-size: 11px;
        text-transform: uppercase;
        padding: 10px 15px;
        vertical-align: middle;
	}
 
    tbody tr:nth-child(even) {
        background: #f0f0f2;
    }
#CreationDate {
 
        font-family: Arial, Helvetica, sans-serif;
        color: #ff3300;
        font-size: 13px;
 
    }
 
 
    .Error {
 
        color: #ff0000;
    }

    .Compliant {
 
        color: #008000;
    }
 
    .NotApplicable {
 
        color: #008000;
    }
        .Conflict {
 
        color: #FF7F50;
    }
 
     .Noncompliant {
 
        color: #FF7F50;
    }
 
    .Remediated {
 
        color: #008000;
    }
 
 
     .Unknown {
 
        color: #ff0000;
    }
     
</style>
"@

      <#
        $Report = ConvertTo-Html -Body $allPolicyInformationofdevice -Title "$($device.DeviceName) Information Report" -Head $header -PostContent "<p id='CreationDate'>Creation Date: $(Get-Date)</p>"
        # $allPolicyInformationofdevice | ConvertTo-Html -Body "$($device.DeviceName) RSOP info" -Title "$($device.DeviceName) Information Report" -Head $header -PostContent "<p id='CreationDate'>Creation Date: $(Get-Date)</p>" | Out-File "$dir\RSOP_$($device.DeviceName)_$($date).html"
        $Report | Out-File "$s_Folder\RSOP_$($device.DeviceName)_$($date).html"
 
        #>

      #$deviceCount += 1
    }

    else
    {
      Write-Host "Device $($device.DeviceName) not found in Azure AD. Please check the device and run the script again.. " -ForegroundColor Red
    }

    #Remove the temp files that were created for data filteration
    Remove-Item "$dir\configurationtempfile.txt" -ErrorAction SilentlyContinue
    Remove-Item "$dir\policytempfile.txt" -ErrorAction SilentlyContinue
  }
}
else
{
  Write-Host "User has stopped the script due to revalidation of the input objects.." -ForegroundColor Red
  exit
}
#Write-Host ""
Write-Host "Execution of the script is completed. For output, please check '$s_Folder' " -ForegroundColor Green
