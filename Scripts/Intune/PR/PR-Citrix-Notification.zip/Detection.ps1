﻿# *****************************************************
# # Check Citrix Client version and notify user to update
# *****************************************************

[CmdletBinding()]

param(     
      [Parameter(
	  Mandatory = $false)]
	  [version]$WindowsClientMin = "22.10.5.14", # define minimum client version here
	       
      [Parameter(
	  Mandatory = $false)]  
      [version]$MacClientMin = "22.10.0.44", # define minimum client version here
	  
	  [Parameter(
	  Mandatory = $false)]  
      [version]$LinuxClientMin = "22.10.5.14" # define minimum client version here
)

# General variables
$CitrixSessionID = Get-ChildItem -Path "HKCU:\Volatile Environment" -Name
[version]$CitrixClientVersion = Get-WmiObject -Namespace root\citrix\hdx -Class Citrix_Client_Enum | Where-Object {$_.SessionID -eq $CitrixSessionID} | Select-Object -ExpandProperty Version

$CitrixClientName = Get-WmiObject -Namespace root\citrix\hdx -Class Citrix_Client_Enum | Where-Object {$_.SessionID -eq $CitrixSessionID} | Select-Object -ExpandProperty Name

# Citrix Client platform
$ClientProductId=(Get-ItemProperty HKLM:\Software\Citrix\ICA\Session\$CitrixSessionID\Connection -name ClientProductId).ClientproductId

if ($ClientProductId -eq 1) {$ClientPlatform="Windows"}
if ($ClientProductId -eq 81) {$ClientPlatform="Linux"}
if ($ClientProductId -eq 82) {$ClientPlatform="Mac"}
if ($ClientProductId -eq 257) {$ClientPlatform="HTML5"}
	
if($CitrixClientName -like 'WT*') 
{
      write-output "WYSE client and nothing to display"
      Exit 0
} 
else
{
    if ($ClientPlatform -eq "HTML5") 
    {
        Write-Output "Citrix workspace is not latest, notify user to upgrade Citrix workspace"	
        Exit 1
    }  
    switch ($ClientPlatform)
    {
	    'Windows'	
        {                
	        if ($CitrixClientVersion -lt $WindowsClientMin) 
            {
		        Write-Output "Citrix workspace is not latest, notify user to upgrade Citrix workspace"
                Exit 1
            }
            else
            {
                write-output "Already upgraded, all good"
                Exit 0
            }
	    }
				
	    'Mac'		
        {
		    if ($CitrixClientVersion -lt $MacClientMin)
            {
		        Write-Output "Citrix workspace is not latest, notify user to upgrade Citrix workspace"
                Exit 1
            }
            else
            {
                write-output "Already upgraded, all good"
                Exit 0
            }
        }
				
	    'Linux'		
        {
            if ($CitrixClientVersion -lt $LinuxClientMin) 
            {
		        Write-Output "Citrix workspace is not latest, notify user to upgrade Citrix workspace"
                Exit 1
            }
            else
            {
                write-output "Already upgraded, all good"
                Exit 0
            }
        }
    }
}
