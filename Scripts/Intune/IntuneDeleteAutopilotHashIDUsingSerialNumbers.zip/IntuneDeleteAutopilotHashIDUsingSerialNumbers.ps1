﻿<#
.SYNOPSIS
This script connects to Microsoft Graph and remove Autopilot info if found based on serial numbers provided in a file.
It logs each step of the execution and outputs a CSV file with details about the processed devices.

Modules require to install:

Microsoft.Graph.DeviceManagement.Enrollment

Graph Scope permissions:
DeviceManagementServiceConfig.Read.All
DeviceManagementServiceConfig.ReadWrite.All

Author: Eswar Koneti
Date: 15-Apr-2025
#>

# Get the script location and execution date
$scriptpath = $MyInvocation.MyCommand.Path
$directory = Split-Path $scriptpath
$date = (Get-Date -Format "ddMMyyyy-HHmmss")

# Output file for storing the Azure AD device info and logging
$OutputCsv = "$directory\AutopilotInfoRemovalOutput_$date.csv"
$LogFile = "$directory\AutopilotInfoRemovalStatus_$date.log"

# Function to log messages
function Log-Message {
    param (
        [string]$Message
    )
    $timestamp = Get-Date -Format "dd-MM-yyyy HH:mm:ss"
    "$timestamp - $Message" | Out-File -FilePath $LogFile -Append
}

# Define the module names
$modulesToCheck = @('Microsoft.Graph.DeviceManagement.Enrollment')
foreach ($moduleName in $modulesToCheck) {
    # Check if the module is installed
    if (-not (Get-Module -ListAvailable -Name $moduleName)) {
        Log-Message "Module '$moduleName' not found. Installing..."
        try {
            Install-Module -Name $moduleName -Scope CurrentUser -Force -AllowClobber
         #   Log-Message "Module '$moduleName' installed successfully."
        } catch {
            Log-Message "Failed to install module '$moduleName'. Error: $_"
            exit
        }
    } else {
        #Log-Message "Module '$moduleName' is already installed."
    }

    # Import the required modules
    try {
        Import-Module -Name $moduleName -Force
        #Log-Message "Module '$moduleName' imported successfully."
    } catch {
        Log-Message "Failed to import module '$moduleName'. Error: $_"
        exit
    }
}
if (!$GraphConnected) {
    try {
       if ( Connect-MgGraph -NoWelcome -Scopes "DeviceManagementServiceConfig.Read.All, DeviceManagementServiceConfig.ReadWrite.All" )
       {
        $GraphConnected = $true
        }
     #   Log-Message "Connected to Microsoft Graph successfully."
    }
    catch {
        Log-Message "Unable to connect to Microsoft Graph.Please check"
    }
}

if ($GraphConnected) {
# Log script start
Log-Message "Script execution started."
    Write-Host "To search for Autopilot info, enter the serial number of the device OR a filename (e.g. 'Somedevices.txt') in this script's folder containing multiple serial numbers. " -ForegroundColor Yellow
    $SerialNumber = Read-Host
    # Check what was provided
    if ($SerialNumber.EndsWith(".txt", "CurrentCultureIgnoreCase")) {
        # It's a file
        if (!(Test-Path -Path "$directory\$SerialNumber")) {
            Write-Host "The file name '$directory\$SerialNumber' cannotbe found. Try again." -ForegroundColor Red
            Log-Message "The file name '$directory\$SerialNumber' cannotbe found."
            exit
        } else {
            $a_SerialNumbers = Get-Content "$directory\$SerialNumber"
            if ($a_SerialNumbers.count -eq 0) {
                Write-Host "The file is empty. Try again." -ForegroundColor Red
                Log-Message "The file is empty."
                exit
            }
        }
    } else {
        $a_SerialNumbers = @($SerialNumber)
    }

    $i_TotalDevices = $a_SerialNumbers.count
    Write-Host "Total serial numbers found: $i_TotalDevices. Press 'Enter' to process all serial numbers, or type 'n' then press 'Enter' to exit the script: " -ForegroundColor Yellow -NoNewline
    $Scope = Read-Host
    if ($Scope -ieq "n") {
        Log-Message "User opted to exit the script."
        write-host "User opted to exit the script."
        exit
    }

    Write-Host "Input data received, script execution is in progress..." -ForegroundColor Green
    Log-Message "Total serial numbers to process: $i_TotalDevices."

    # Initialize CSV output
    $OutputData = @()

# Fetch all Autopilot devices once
$allAutopilotDevices = Get-MgDeviceManagementWindowsAutopilotDeviceIdentity -All

# Initialize an array to store output data
$OutputData = @()

# Process each serial number
foreach ($SerialNumber in $a_SerialNumbers) {
    $serialNumberTrimmed = $SerialNumber.Trim()

    # Find the device details by matching the serial number
    $details = $allAutopilotDevices | Where-Object { $_.SerialNumber -eq $serialNumberTrimmed } | Select-Object SerialNumber, GroupTag, Model, Id, AzureActiveDirectoryDeviceId

    if ($details) {
        try {
            # Remove the Autopilot device
            Remove-MgDeviceManagementWindowsAutopilotDeviceIdentity -WindowsAutopilotDeviceIdentityId $details.Id -ErrorAction Stop
          #  Log-Message "Deleted the Autopilot device with Serial Number: $serialNumberTrimmed."
            $status = "Deleted"
        } catch {
            $errorMessage = $_.Exception.Message
           # Log-Message "Failed to delete the Autopilot device with Serial Number: $serialNumberTrimmed. Error: $errorMessage"
            $status = "Failed: $errorMessage"
        }
        # Add the status to the details
        $details | Add-Member -MemberType NoteProperty -Name Status -Value $status
        # Append the details to the output data
        $OutputData += $details
    } else {
        Log-Message "Autopilot device info NOT found for Serial Number: $serialNumberTrimmed."
    }
}

    # Export the results to CSV
    $OutputData | Export-Csv -Path $OutputCsv -NoTypeInformation
    Write-Host "Script execution is completed. See file '$OutputCsv' for status." -ForegroundColor Green
    Log-Message "Script execution completed. Results exported to '$OutputCsv'."
} else {
    Write-Host "Failed to connect to Microsoft Graph." -ForegroundColor Red
    Log-Message "Failed to connect to Microsoft Graph.."
}

# Log script end
Log-Message "Script execution ended."