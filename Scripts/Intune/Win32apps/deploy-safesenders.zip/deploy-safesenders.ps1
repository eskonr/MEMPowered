<#
.SYNOPSIS
    Copies 'safesenders.txt' into the managed safe sender folder, logs actions, and stamps a registry version.

.DESCRIPTION
    This script automates deployment of an Outlook Safe Senders file by copying 'safesenders.txt' to 'C:\ProgramData\eskonr\outlooksafesender'.
    It creates necessary folders and logs status/activity to 'C:\ProgramData\eskonr\logs\outlooksafesender.log'.
    The script checks for (and if needed, creates) the registry key 'HKLM\Software\eskonr\outlooksafesender', stamping a 'Version' value of '1' for deployment tracking.
    Designed by eskonr for endpoint automation requirements.

.PARAMETER None
    All paths and actions are defined internally.

.EXAMPLE
    Run as Administrator:
        powershell.exe -ExecutionPolicy Bypass -File .\deploy-safesenders.ps1

.NOTES
    Author: Eswar Koneti @eskonr
    Created: September 2025

#>

# Define variables
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SourceFile = Join-Path -Path $ScriptDir -ChildPath 'safesenders.txt'
$TargetFolder = 'C:\ProgramData\eskonr\outlooksafesender'
$TargetFile = "$TargetFolder\safesenders.txt"
$LogFolder = 'C:\ProgramData\eskonr\logs'
$LogFile = "$LogFolder\outlooksafesender.log"
$RegPath = 'HKLM:\Software\eskonr\outlooksafesender'
$RegValueName = 'Version'
$RegValue = '1'

# Ensure directories exist
if (!(Test-Path $TargetFolder)) { New-Item -Path $TargetFolder -ItemType Directory -Force }
if (!(Test-Path $LogFolder)) { New-Item -Path $LogFolder -ItemType Directory -Force }

# Logging function
function Write-Log {
    param([string]$message)
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $LogFile -Value "$timestamp $message"
}

Write-Log 'Script started.'

# Copy the file
try {
    Copy-Item -Path $SourceFile -Destination $TargetFile -Force -ErrorAction Stop
    Write-Log "File copied from $SourceFile to $TargetFile successfully."
} catch {
    Write-Log "Error copying file: $_"
}

# Only proceed with registry if copy succeeded
if (Test-Path $TargetFile) {
    if (-not (Test-Path $RegPath)) {
        New-Item -Path $RegPath -Force | Out-Null
        Write-Log "Registry key $RegPath created."
    }
    Set-ItemProperty -Path $RegPath -Name $RegValueName -Value $RegValue -Type String
    Write-Log "Registry value '$RegValueName' set to '$RegValue' in $RegPath."
} else {
    Write-Log 'Registry NOT updated as file copy failed or file not found.'
}

Write-Log 'Script completed.'