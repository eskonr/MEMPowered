﻿<#
Name:Export members of the Azure AD/Entra ID group include all devices to CSV format
Description: This script helps to export the members of specific Azure AD/Entra ID group membership including direct members and all members.
Entra ID portal, does not allow to export all members , it allow only direct members.
The account that runs the script must have delegated permissions to the power Graph as per https://learn.microsoft.com/en-us/powershell/module/microsoft.graph.groups/get-mggroup?view=graph-powershell-1.0
Author:Eswar Koneti (@eskonr)
Date:15-May-2024
The output will be created in the script folder with groupname.csv
#>

#Get the script location

$scriptpath = $MyInvocation.MyCommand.Path
$directory = Split-Path $scriptpath
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
#Get the script execution date
$date = (Get-Date -f dd-MM-yyyy-hhmmss)

#Check the Azure AD module
if (!(Get-Module -ListAvailable Microsoft.Graph.Groups))
{
Write-Host "Microsoft.Graph.Groups module not installed, installing now" -BackgroundColor Red
Install-Module -Name Microsoft.Graph.Groups
$Modules = Get-Module -ListAvailable Microsoft.Graph.Groups
if ($Modules.count -eq 0)
{
Write-Host "Unable to install the required modules, please install module and run the script again" -BackgroundColor Red
exit
}
}

$EntraIDConnected = $false

try {

#MS Graph permissions to the account listed https://learn.microsoft.com/en-us/powershell/module/microsoft.graph.groups/get-mggroup?view=graph-powershell-1.0

$tenant = Connect-MgGraph -Scopes 'Group.Read.All'-ErrorAction Stop
$EntraIDConnected = $true
}
catch {
Write-Host "Unable to retrieve Entra IDtenant details." -ForegroundColor Red
}

if (!$EntraIDConnected) {
try {
Connect-MgGraph -Scopes 'Group.Read.All' -ErrorAction Stop
$EntraIDConnected = $true
}
catch {
Write-Host "Unable to connect to Entra ID services." -ForegroundColor Red
}
}

if ($EntraIDConnected)
{

#Provide Entra Group name , translates the group name to Group ID

Write-Host "Enter Entra ID Group Name to export the direct members of all: " -ForegroundColor Yellow
$GroupName = Read-Host
$Groupfound=(Get-MgGroup -Filter "DisplayName eq '$GroupName'" | Select-Object Id).id
#What was provided?
if(!($Groupfound))
{
Write-Host "Provided Entra ID group name '$GroupName' not found . Try again." -ForegroundColor Red
Write-Host ""
#Wait for the user…
Read-Host -Prompt "When ready, press 'Enter' to exit…"
exit
}
elseif ($Groupfound)
{

Write-Host ""
Write-Host "Group Name '$GroupName' found in Entra ID . Press 'Enter' to report data, or type 'n' then press 'Enter' to exit the script: " -ForegroundColor green -NoNewline
$Scope = Read-Host
Write-Host "Input is recieved, Script execution is in progress…" -ForegroundColor green

if ($Scope -ieq "n")
{
$b_ScopeAll = $false
}
else
{
$b_ScopeAll = $true
}
Write-Host ""

#Continue to export all direct members in the group
if ($b_ScopeAll)
{

(Get-MgGroupMember -GroupId $Groupfound -All) | Select-Object @{Name='DeviceName'; Expression={$_.additionalProperties['displayName']}},
@{Name='OS'; Expression={$_.additionalProperties['operatingSystem']}}, @{Name='OSVersion'; Expression={$_.additionalProperties['operatingSystemVersion']}},
@{Name='createdDateTime'; Expression={$_.additionalProperties['createdDateTime']}}, @{Name='RegistrationDate'; Expression={$_.additionalProperties['registrationDateTime']}},
@{Name='LastSigninDate'; Expression={$_.additionalProperties['approximateLastSignInDateTime']}}, @{Name='Enabled'; Expression={$_.additionalProperties['accountEnabled']}},
@{Name='deviceId'; Expression={$_.additionalProperties['deviceId']}}` | Export-Csv "$directory\$GroupName-$date.csv" -NoTypeInformation

}
else
{
Write-Host "User has stopped the script due to revalidation of the Entra ID Group object.." -ForegroundColor Red
exit
}
}
}