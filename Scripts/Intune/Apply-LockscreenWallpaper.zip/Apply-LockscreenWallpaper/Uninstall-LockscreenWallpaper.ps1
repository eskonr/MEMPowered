﻿<#
Description: This script automates the process of removing the custom desktop lock screen image from a Windows machine.
             It checks if the registry key exists and removes it if necessary, and deletes the lock screen image files
             from the specified folder.

Name: Uninstall-LockscreenWallpaper.ps1

Date: 25-Mar-2025

Author: Eswar Koneti
#>

# Function to log output with date and time
function Log-Output {
    param (
        [string]$message,
        [string]$status
    )
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logMessage = "$timestamp - $status - $message"
    $logMessage | Out-File $log -Append
}

# Define the path of the current script and the directory
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath

# Define log file path
$log="C:\ProgramData\eskonr\LockScreenWallpaper\Uninstall-LockscreenWallpaper.log"

# Ensure the directory exists before logging
$logDirectory = [System.IO.Path]::GetDirectoryName($log)
if (-not (Test-Path -Path $logDirectory)) {
    New-Item -Path $logDirectory -ItemType Directory -Force
    Log-Output "Log directory created: $logDirectory" "SUCCESS"
}

# Define the registry path for lock screen personalization settings
$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP"

# Check if the registry key exists, if so, remove it
if (Test-Path -Path $RegPath) {
    try {
        Remove-Item -Path $RegPath -Force -ErrorAction SilentlyContinue
        Log-Output "Registry key $RegPath removed successfully" "SUCCESS"
    }
    catch {
        Log-Output "Failed to remove registry key $RegPath" "ERROR"
        Log-Output $_ "ERROR"
    }
} else {
    Log-Output "Registry key $RegPath not found" "INFO"
}

# Remove the lock screen image files/folder if they exist
$imageFolder = "C:\ProgramData\eskonr\LockScreenWallpaper"
if (Test-Path -Path $imageFolder) {
    try {
       Get-ChildItem -Path $imageFolder -Recurse | Where-Object { $_.Extension -ne ".log" } | Remove-Item -Force -ErrorAction SilentlyContinue
       Log-Output "Lock screen image folder $imageFolder removed successfully" "SUCCESS"
    }
    catch {
        Log-Output "Failed to remove lock screen image folder $imageFolder" "ERROR"
        Log-Output $_ "ERROR"
    }
} else {
    Log-Output "Lock screen image folder $imageFolder not found" "INFO"
}
