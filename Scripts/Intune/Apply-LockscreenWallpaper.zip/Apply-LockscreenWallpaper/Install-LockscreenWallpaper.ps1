﻿<#
Description: This script automates the process of setting a custom lock screen image on a Windows machine.
             It checks if the required registry key exists and creates it if necessary, sets up the folder 
             for the lock screen image, removes old files if they exist, and updates registry settings 
             to apply the new lock screen image

Name: Install-LockscreenWallpaper.ps1

Date: 25-Mar-2025

Author: Eswar Koneti
#>

# Function to log output with date and time
function Log-Output {
    param (
        [string]$message,
        [string]$status
    )
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logMessage = "$timestamp - $status - $message"
    $logMessage | Out-File $log -Append
}

# Define the path of the current script and the directory
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath

# Define log file path
$log="C:\ProgramData\eskonr\LockScreenWallpaper\Install-LockscreenWallpaper.log"

# Ensure the directory exists before logging
$logDirectory = [System.IO.Path]::GetDirectoryName($log)
if (-not (Test-Path -Path $logDirectory)) {
    New-Item -Path $logDirectory -ItemType Directory -Force
    Log-Output "Log directory created: $logDirectory" "SUCCESS"
}

# Define the registry path for lock screen personalization settings
$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\PersonalizationCSP"

# Check if the registry key exists, if not, create it
if (!(Test-Path -Path $RegPath)) {
    try {
        Log-Output "Reg key doesn't exist, creating now" "INFO"
        New-Item -Path $RegPath -Force
        Log-Output "Reg key is created successfully" "SUCCESS"
    }
    catch {
        Log-Output "Failed to create reg key" "ERROR"
        Log-Output $_ "ERROR"
    }
}

# Variable creation for image path and lock screen file
$ImageDestinationFolder = "C:\ProgramData\eskonr\LockScreenWallpaper"
$LockscreenFile = "LockScreenWallpaper25032025.jpg"
$LockScreenImage = "$ImageDestinationFolder\$LockscreenFile"

# Remove old lock screen files if they exist before copying the new one.
Get-ChildItem -Path $ImageDestinationFolder -Recurse | Where-Object { $_.Extension -ne ".log" } | Remove-Item -Force -ErrorAction SilentlyContinue
Log-Output "Old lock screen files removed (if any)" "INFO"

# Create the directory if it doesn't exist or re-create if new image to update.
md $ImageDestinationFolder -ErrorAction SilentlyContinue
Log-Output "Lock screen image folder created (if it didn't exist)" "INFO"

# Copy the lock screen image file to the destination folder
Copy-Item -Path $dir\$LockscreenFile -Destination $ImageDestinationFolder -Force
Log-Output "Lock screen image copied to destination folder" "SUCCESS"

# Set the registry keys for lock screen image settings
New-ItemProperty -Path $RegPath -Name LockScreenImagePath -Value $LockScreenImage -PropertyType String -Force | Out-Null
Log-Output "LockScreenImagePath registry key set" "SUCCESS"
New-ItemProperty -Path $RegPath -Name LockScreenImageUrl -Value $LockScreenImage -PropertyType String -Force | Out-Null
Log-Output "LockScreenImageUrl registry key set" "SUCCESS"
New-ItemProperty -Path $RegPath -Name LockScreenImageStatus -Value 1 -PropertyType DWORD -Force | Out-Null
Log-Output "LockScreenImageStatus registry key set" "SUCCESS"
