<#
File:CopyShortCutsLocation.ps1

Description:
This scripts help to copy the specific shortcuts from the specific folder specified in the script to default profile for all users.

Author: Eswar Koneti
Date:19-Nov-2024
#>

# Define source and destination paths
$scriptpath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$sourceIcons = "$dir\1-Icon\*.*"
$destinationDesktop = "C:\Users\Public\Desktop"
$sourceSignOff = "$dir\2-Sign Off\*.*"
$destinationSignOffFolder = "C:\Users\Public\Downloads\User Sign Off"
$logFolder = "C:\ProgramData\eskonr\InstallLogs"
$logFile = "$logFolder\CopyShortcutOperations.log"
$registryPath = "HKLM:\SOFTWARE\eskonr\CopyShortCuts"
$registryValueName = 'Success'

# Function to write log
function Write-Log {
	param (
		[string]$message
	)
	$timestamp = Get-Date -Format 'dd-MM-yyyy HH:mm:ss'
	$logMessage = "$timestamp - $message"
	Add-Content -Path $logFile -Value $logMessage
}

# Create $destinationSignOffFolder folder if it doesn't exist
if (-not (Test-Path -Path $destinationSignOffFolder)) {
	New-Item -Path $destinationSignOffFolder -ItemType Directory -Force
}

# Create log folder if it doesn't exist
if (-not (Test-Path -Path $logFolder)) {
	New-Item -Path $logFolder -ItemType Directory -Force
}

# Function to copy files and log the status
function Copy-Files {
	param (
		[string]$source,
		[string]$destination
	)

	try {
		Copy-Item -Path $source -Destination $destination -Recurse -Force
		Write-Log -message "Files copied successfully from $source to $destination"
		return $true
	} catch {
		Write-Log -message "Error copying files from $source to $destination : $_"
		return $false
	}
}

# Function to create registry key and set value
function Set-RegistryValue {
	param (
		[string]$path,
		[string]$name,
		[String]$value
	)
	try {
		if (-not (Test-Path -Path $path)) {
			New-Item -Path $path -Force | Out-Null
		}
		Set-ItemProperty -Path $path -Name $name -Value $value
		Write-Log -message "Registry key set: $path\$name = $value"
	} catch {
		Write-Log -message "Error setting registry key: $path\$name - $_"
	}
}

# Copy Icons to Desktop
$iconsCopied=Copy-Files -source $sourceIcons -destination $destinationDesktop

# Copy Sign Off files
$signOffCopied=Copy-Files -source $sourceSignOff -destination $destinationSignOffFolder

# Check if both copy operations were successful
if ($iconsCopied -and $signOffCopied) {
	Set-RegistryValue -path $registryPath -name $registryValueName -value 1
	Set-RegistryValue -path $registryPath -name "LogFile" -value $logFile
}

