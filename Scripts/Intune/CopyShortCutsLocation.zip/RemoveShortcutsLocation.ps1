<#
FileName:RemoveShortcutsLocation.ps1
This script will remove the designated shortcuts for the  location which was copied part of the install script.
#>
# Define paths
$desktopPath = 'C:\Users\Public\Desktop'
$downloadsPath = 'C:\Users\Public\Downloads\User Sign Off'
$registryPath = 'HKLM:\SOFTWARE\eskonr\CopyShortCuts'

# Define shortcuts to delete
$shortcuts = @(
	'Azure CAP.url',
	'Azure CAD.url',
	'Staff Login - eskonr.url'
)

# Function to delete shortcuts from Desktop
function DeleteShortcuts {
	param (
		[string[]]$shortcuts,
		[string]$desktopPath
	)
	foreach ($shortcut in $shortcuts) {
		$shortcutPath = Join-Path -Path $desktopPath -ChildPath $shortcut
		if (Test-Path -Path $shortcutPath) {
			try {
				Remove-Item -Path $shortcutPath -Force
				Write-Host "Deleted: $shortcutPath"
			} catch {
				Write-Host "Failed to delete: $shortcutPath - $_"
			}
		} else {
			Write-Host "Shortcut does not exist: $shortcutPath"
		}
	}
}

# Function to delete folder
function DeleteFolder {
	param (
		[string]$folderPath
	)
	if (Test-Path -Path $folderPath) {
		try {
			Remove-Item -Path $folderPath -Recurse -Force
			Write-Host "Deleted: $folderPath"
		} catch {
			Write-Host "Failed to delete: $folderPath - $_"
		}
	} else {
		Write-Host "Folder does not exist: $folderPath"
	}
}

# Function to delete registry key
function DeleteRegistryKey {
	param (
		[string]$registryPath
	)
	if (Test-Path -Path $registryPath) {
		try {
			Remove-Item -Path $registryPath -Recurse -Force
			Write-Host "Deleted registry key: $registryPath"
		} catch {
			Write-Host "Failed to delete registry key: $registryPath - $_"
		}
	} else {
		Write-Host "Registry key does not exist: $registryPath"
	}
}

# Delete shortcuts from Desktop
DeleteShortcuts -shortcuts $shortcuts -desktopPath $desktopPath

# Delete User Sign Off folder from Downloads
DeleteFolder -folderPath $downloadsPath

# Delete the registry key
DeleteRegistryKey -registryPath $registryPath