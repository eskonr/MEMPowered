#Requirements for Windows 10 22H2 and specific patch KB5046613 (19045.5131)
$OSCurrentVersion = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
$Win1022H2 = '19045'
$ReqPatch = '5131'

 #Retrieve the OS Product Name and Release ID
$OSDisplay = $OSCurrentVersion.DisplayVersion
$OSVersion = $OSCurrentVersion.CurrentBuild
$ReleaseId = $OSCurrentVersion.ReleaseId

 #Determine the OS Name
if ($OSVersion -ge 22000) {
    $OSName = "Windows 11"
} else {
    $OSName = "Windows 10"
}
 #Check the OS version and patch
if ($OSVersion -eq $Win1022H2 -and $ReleaseId -eq "22H2") {
    #Write-Output "This system is running Windows 10 22H2 (19045). Current version: $OSVersion"
    if (($OSCurrentVersion.CurrentBuildRevision -ge $ReqPatch) -or ($OSCurrentVersion.UBR -ge $ReqPatch)) {
        exit 0
        #Write-Output "Eligible for Windows 10 ESU."
    } else {
      exit 1
     #   Write-Output "Not Eligible for Windows 10 ESU."
    }
} else {
    exit 1
    #    Write-Output "Not Eligible for Windows 10 ESU. Detected OS: $OSName ($OSDisplay). OS version: $OSVersion"
}