# SCCM Detection Rule Script for Windows 10 ESU Activation
$OSCurrentVersion = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
$Win1022H2 = '19045'
$ReqPatch = '5131'
$win10_Y1_Key = 'Your-Year-1-ESU-Key-Here' #replace the key if exist, otherwise leave it as-is
$win10_Y2_Key = 'Your-Year-2-ESU-Key-Here' #replace the key if exist, otherwise leave it as-is
$win10_Y3_Key = 'Your-Year-3-ESU-Key-Here' #replace the key if exist, otherwise leave it as-is

function Test-ESUKey {
	param (
		[string]$Key
	)
	$PartialKey = $Key.Substring($Key.Length - 5)
	$Licensed = Get-WmiObject -Query ('SELECT ID, Name, OfflineInstallationId, ProductKeyID FROM SoftwareLicensingProduct WHERE PartialProductKey = "{0}"' -f $PartialKey)
	$ActivationStatus = Get-WmiObject -Query ('SELECT LicenseStatus FROM SoftwareLicensingProduct WHERE PartialProductKey = "{0}"' -f $PartialKey)
	return $Licensed -and $ActivationStatus.LicenseStatus -eq 1
}

# Check if the system meets the prerequisites for Windows 10 ESU
$OSVersion = $OSCurrentVersion.CurrentBuild
$PatchLevel = $OSCurrentVersion.CurrentBuildRevision

if ($OSVersion -eq $Win1022H2 -and $PatchLevel -ge $ReqPatch) {
	$ESUY1Status = Test-ESUKey -Key $win10_Y1_Key
	$ESUY2Status = if ($win10_Y2_Key -ne 'Your-Year-2-ESU-Key-Here') { Test-ESUKey -Key $win10_Y2_Key } else { $null }
	$ESUY3Status = if ($win10_Y3_Key -ne 'Your-Year-3-ESU-Key-Here') { Test-ESUKey -Key $win10_Y3_Key } else { $null }

	# Determine activation status
	if (($null -ne $ESUY2Status) -and ($null -ne $ESUY3Status)) {
		if ($ESUY1Status -and $ESUY2Status -and $ESUY3Status) {
			exit 0 # All ESU keys are valid and activated
		}
	} elseif (($null -ne $ESUY2Status)) {
		if ($ESUY1Status -and $ESUY2Status) {
			exit 0 # Y1 and Y2 ESU keys are valid and activated
		}
	} else {
		if ($ESUY1Status) {
			exit 0 # Y1 ESU key is valid and activated
		}
	}
}

# If prerequisites are not met or ESU activation is not valid
exit 1