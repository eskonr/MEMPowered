# Define the ESU keys and product IDs
$win10_Y1_ESU = 'f520e45e-7413-4a34-a497-d2765967d094'
$win10_Y2_ESU = '1043add5-23b1-4afb-9a0f-64343c8f3f8d'
$win10_Y3_ESU = '83d49986-add3-41d7-ba33-87c7bfb5c0fb'
$win10_Y1_Key = 'Your-Year-1-ESU-Key-Here' #replace the key if exist, otherwise leave it as-is
$win10_Y2_Key = 'Your-Year-2-ESU-Key-Here' #replace the key if exist, otherwise leave it as-is
$win10_Y3_Key = 'Your-Year-3-ESU-Key-Here' #replace the key if exist, otherwise leave it as-is

# Define the log file path
$logFilePath = 'C:\ProgramData\eskonr\InstallLogs\Win10ESUActivation.log'

# Function to log messages
function Log-Message {
	param (
		[string]$message
	)
	$timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
	$logEntry = "$timestamp - $message"
	Add-Content -Path $logFilePath -Value $logEntry
}

# Ensure the log directory exists
if (-not (Test-Path -Path 'C:\ProgramData\eskonr\InstallLogs')) {
	New-Item -Path 'C:\ProgramData\eskonr' -ItemType Directory -Force
}

# Function to test and activate ESU key
function Test-ESUKey {
	param ([string]$Key)

	$PartialKey = $Key.Substring($Key.Length - 5)
	$Licensed = Get-WmiObject -Query ('SELECT ID, Name, OfflineInstallationId, ProductKeyID FROM SoftwareLicensingProduct where PartialProductKey = "{0}"' -f $PartialKey)
	$ActivationStatus = Get-WmiObject -Query ('SELECT LicenseStatus FROM SoftwareLicensingProduct where PartialProductKey = "{0}"' -f $PartialKey)

	if ($Licensed -and $ActivationStatus.LicenseStatus -eq 1) {
		Log-Message "ESU key $PartialKey is valid and activated."
		return $true
	} else {
		if (!$Licensed) {
			Log-Message "No valid ESU key found for $PartialKey."
		} else {
			Log-Message "Valid ESU key found for $PartialKey, but not activated."
		}
		return $false
	}
}

# Function to install and activate ESU key
function Install-ESUKey {
	param (
		[string]$Key,
		[string]$ProductID
	)
	Log-Message "Installing and activating ESU key $Key."
	Start-Process -FilePath 'cscript.exe' -ArgumentList '//Nologo "C:\windows\System32\slmgr.vbs" /ipk $($Key)' -NoNewWindow -Wait
	Start-Sleep -Seconds 15
	Start-Process -FilePath 'cscript.exe' -ArgumentList '//Nologo "C:\windows\System32\slmgr.vbs" /ato $($ProductID)' -NoNewWindow -Wait
	Start-Sleep -Seconds 15
}

# Check and process each key
foreach ($entry in @(
		@{Key = $win10_Y1_Key; ESU = $win10_Y1_ESU },
		@{Key = $win10_Y2_Key; ESU = $win10_Y2_ESU },
		@{Key = $win10_Y3_Key; ESU = $win10_Y3_ESU }
	)) {
	if ($entry.Key -and $entry.Key -ne 'Your-Year-1-ESU-Key-Here' -and $entry.Key -ne 'Your-Year-2-ESU-Key-Here' -and $entry.Key -ne 'Your-Year-3-ESU-Key-Here') {
		$status = Test-ESUKey -Key $entry.Key
		if (-not $status) {
			Install-ESUKey -Key $entry.Key -ProductID $entry.ESU
			$status = Test-ESUKey -Key $entry.Key
		}
		if ($status) {
			Log-Message "ESU Key $entry.Key is valid and activated."
		} else {
			Log-Message "ESU Key $entry.Key is not valid or not activated."
		}
	}
}

# Final evaluation
if ($ESUY1Status -and $ESUY2Status -and $ESUY3Status) {
	Log-Message 'All ESU keys are valid and activated.'
	exit 0
} else {
	Log-Message 'Not all ESU keys are valid or activated.'
	exit 1
}