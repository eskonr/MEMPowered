use SUSDB;
select
(Select count (*) 'Total Updates' from vwMinimalUpdate ) 'Total Updates',
(Select count (*) 'Live updates'  from vwMinimalUpdate where declined=0) as 'Live Updates',
(Select count (*) 'Live updates'  from vwMinimalUpdate where declined=0 and IsSuperseded =0) as 'Live Updates no superseded',
(Select count (*) 'Superseded'  from vwMinimalUpdate where IsSuperseded =1) as 'Superseded',
(Select count (*) 'Superseded But NoDeclined'  from vwMinimalUpdate where IsSuperseded =1 and declined=0) as 'Superseded but not declined',
(Select count (*) 'Declined'  from vwMinimalUpdate where declined=1) as 'Declined',
(Select count (*) 'Superseded & Declined' from vwMinimalUpdate where IsSuperseded =1 and declined=1) 'Superseded & Declined'