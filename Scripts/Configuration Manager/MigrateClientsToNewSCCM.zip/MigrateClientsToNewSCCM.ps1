<#
Description: Assign the devices from the current SCCM site to the new SCCM site. As part of the client migration from one SCCM to another, there are several steps to be taken care of for successful migration of the client. Otherwise, the obsolete/old SCCM MP entries could cause the assignment of the site failures. This script does the following as part of the client assignment/Migration to a new SCCM site:
1. Change the site code
2. Assign the DNSSuffix (This is pre-validation to ensure the SCCM domain DNSSuffix entries are added to the endpoint devices that are in the new forest. (Domain A (forest A) is the where SCCM server exsit but the clients are in the seperate domain (forest B))
3. Add allowedMPs multi-string with the FQDN "sccmserver.domain.com"
4. Remove TrustedRootKey instance from root\ccm\locationservices
5. Remove entries in SMS_MPInformation instance from namespace root\ccm\locationservices
6. Finally, restart SMS Agent host service
Name:AssignDeviceToNEWSite.ps1
Author: Eswar Koneti
#>

# Initialize variables for output aggregation
$output = ''

# 1. Change the Site code
$DesiredSiteCode = 'NEW'
$smsClient = New-Object -ComObject Microsoft.SMS.Client
$Result = $smsClient.GetAssignedSite()

if ($Result -eq $DesiredSiteCode) {
	$output += "Sitecode already set to $DesiredSiteCode. "
} else {
	$smsClient.SetAssignedSite($DesiredSiteCode)
	Start-Sleep 5
	$output += "Sitecode changed to $DesiredSiteCode. "
}

# 2. Check and update the DNSSuffix
if ($smsClient.GetAssignedSite() -eq $DesiredSiteCode) {
	$regPath = 'HKLM:\software\microsoft\ccm\locationservices'
	$valueName = 'DNSSuffix'
	if (Test-Path $regPath) {
		$dnsSuffix = Get-ItemProperty -Path $regPath -Name $valueName -ErrorAction SilentlyContinue
		if (-not $dnsSuffix.$valueName) {
			Set-ItemProperty -Path $regPath -Name $valueName -Value 'mfcgd.com'
			$output += "DNSSuffix was empty. Set to 'mfcgd.com'. "
			Start-Sleep 5
			# $output += "Service restarted. "
		}
	}
}


# 3. Add allowedMPs multi-string with the FQDN "sccmserver.domain.com"
$registryPath = 'HKLM:\SOFTWARE\Microsoft\CCM'
$propertyName = 'AllowedMPs'
$allowedMPsValue = 'sccmserver.domain.com'

$smsslpValueName = 'SMSSLP'
$lookupMPListValueName = 'LookupMPList'
$newLookupMPListValue = 'sccmserver.domain.com'

#clear SMSSLP and set SMSMPLISTs
try {
	# Check if the registry path exists
	if (Test-Path $registryPath) {
		# Clear the SMSSLP value
		Set-ItemProperty -Path $registryPath -Name $smsslpValueName -Value ''

		# Update the LookupMPList value
		Set-ItemProperty -Path $registryPath -Name $lookupMPListValueName -Value $newLookupMPListValue

		$output += 'Registry values updated successfully.'
	} else {
		$output += "Registry path $regPath does not exist."
	}
} catch {
	$output += "An error occurred: $_"
}

#Set allowedMPs

try {
	$currentValues = Get-ItemProperty -Path $registryPath -Name $propertyName -ErrorAction SilentlyContinue
	if ($currentValues) {
		$currentValues = $currentValues.AllowedMPs
		if (-not ($currentValues -contains $allowedMPsValue)) {
			$currentValues = $currentValues + $allowedMPsValue
			Set-ItemProperty -Path $registryPath -Name $propertyName -Value $currentValues
		}
	} else {
		New-ItemProperty -Path $registryPath -Name $propertyName -Value @($allowedMPsValue) -PropertyType MultiString -Force
	}
	$output += "AllowedMPs updated with $allowedMPsValue. "
} catch {
	$output += "Failed to update AllowedMPs: $_. "
}

Start-Sleep 3

# 4. Remove TrustedRootKey instance from root\ccm\locationservices
try {
	$trustedRootKey = Get-WmiObject -Namespace 'root\ccm\locationservices' -Class 'TrustedRootKey' -ErrorAction SilentlyContinue
	if ($trustedRootKey) {
		$trustedRootKey.Delete()
		$output += 'TrustedRootKey instance removed. '
	} else {
		$output += 'No TrustedRootKey instance found. '
	}
} catch {
	$output += "Failed to remove TrustedRootKey instance: $_. "
}

Start-Sleep 3

# 5. Remove entries in SMS_MPInformation instance from namespace root\ccm\locationservices
try {
	$mpInfoInstances = Get-WmiObject -Namespace 'root\ccm\locationservices' -Class 'SMS_MPInformation' -ErrorAction SilentlyContinue
	if ($mpInfoInstances) {
		foreach ($instance in $mpInfoInstances) {
			$instance.Delete()
		}
		$output += 'SMS_MPInformation instances removed. '
	} else {
		$output += 'No SMS_MPInformation instances found. '
	}
} catch {
	$output += "Failed to remove SMS_MPInformation instances: $_. "
}
Start-Sleep 2
# 6. Finally Restart SMS Agent host service
try {
	Restart-Service -Name 'CcmExec' -Force
	$output += 'CcmExec service restarted. '
} catch {
	$output += "Failed to restart CcmExec service: $_. "
}

# Output the aggregated results
Write-Output $output
