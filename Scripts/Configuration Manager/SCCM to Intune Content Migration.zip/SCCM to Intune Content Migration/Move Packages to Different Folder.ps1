﻿
<#
.Synopsis
   As part of SCCM decomission initiave, this script helps you to move the packages that no longer required in SCCM and also no migration. Such apps will be moved to decom folder in SCCM.
   
.DESCRIPTION
    Move the packages to different folder (decom/sunset) that helps to focus on the important apps for intune migration.
    
      Author: Eswar Koneti
      Dated: 24-Jan-2025 (www.eskonr.com)
  #>
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$date_time = (Get-Date).tostring("yyyy-MM-dd-HH-mm-ss")

# Function to log messages
function Log-Message {
    param([string]$message)
    $logEntry = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $message"
    $logEntry | Out-File -Append -FilePath $logFilePath
}

# Define the folder
$folderPath = "$dir"
$logFileName = "MovePackages.log"
$logFilePath = Join-Path $folderPath $logFileName


# Site configuration
$SiteCode = "CB1" # Site code 
$ProviderMachineName = "SG-CMCB01.eskonr.com" # SMS Provider machine name

# Customizations
$initParams = @{}
# Do not change anything below this line

# Import the ConfigurationManager.psd1 module 
if((Get-Module ConfigurationManager) -eq $null) {
    Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams
}

# Connect to the site's drive if it is not already present
if((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null) {
    New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams
}

# Set the current location to be the site code.
Set-Location "$($SiteCode):\" @initParams

$Packages=gc "$dir\packages.txt"
foreach ($app in $Packages)
{
$appname = Get-CMPackage -Name "$app" -Fast
if ($appname){
#remove any deployments associated with this package
remove-CMPackageDeployment -Name $app -Force -Confirm:$false -ErrorAction SilentlyContinue
#$packageID=$appname.PackageId
#$deployments=get-CMPackageDeployment -PackageId $packageID
try
{
#move the package to decomission folder
Move-CMObject -FolderPath "$($SiteCode):\Package\Decom" -ObjectId $appname.PackageID
}
catch
{
Log-Message "Failed to move '$($app)' to 'Decom' folder."
}

}
else
{
Log-Message "Cannot find '$($app)'."
}
}