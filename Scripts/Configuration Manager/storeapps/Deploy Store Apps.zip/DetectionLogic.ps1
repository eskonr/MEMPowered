﻿if( (Get-AppxPackage -AllUsers | Where-Object Name -like 'Microsoft.Todos' | Select-Object Name).Name)
{
Write-Host "installed"
}
else
{
}