﻿<#
Name: Install Microsoft To-Do Store app for users
Date:03-March-2022
The apps can be downloaded from the store for business.
#>
#Get the script directory
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
#XML file
$license="Microsoft.Todos_8wekyb3d8bbwe_b7add246-4cf8-3e59-4d3e-18da8ae3c88d.xml"
#check if To-do app is not installed
if(!( (Get-AppxPackage -AllUsers | Where-Object Name -like 'Microsoft.Todos' | Select-Object Name).Name))
{

Add-AppxProvisionedPackage -online -PackagePath:"$dir\Microsoft.NET.Native.Framework.2.2_2.2.29512.0_x64__8wekyb3d8bbwe.Appx" -LicensePath:"$dir\$license"
Add-AppxProvisionedPackage -online -PackagePath:"$dir\Microsoft.NET.Native.Runtime.2.2_2.2.28604.0_x64__8wekyb3d8bbwe.Appx" -LicensePath:"$dir\$license"
Add-AppxProvisionedPackage -online -PackagePath:"$dir\Microsoft.UI.Xaml.2.7_7.2109.13004.0_x64__8wekyb3d8bbwe.Appx" -LicensePath:"$dir\$license"
Add-AppxProvisionedPackage -online -PackagePath:"$dir\Microsoft.VCLibs.140.00_14.0.30704.0_x64__8wekyb3d8bbwe.Appx" -LicensePath:"$dir\$license"
Add-AppxProvisionedPackage -online -PackagePath:"$dir\Microsoft.Todos_2.64.5521.0_neutral___8wekyb3d8bbwe.AppxBundle" -LicensePath:"$dir\$license"
}