
Function Test-Exclusions {
##########################################################################################################
<#
.SYNOPSIS
   Determine if the update should be excluded or not.

.DESCRIPTION
   Compare the update metadata against the exclusion filters and return true if the update should be
   excluded and return false if not.

#>
##########################################################################################################
    Param(
        [Microsoft.UpdateServices.Administration.IUpdate] $Update
    )

    #Exclusions by title.
    ForEach ($Title In $ExcludeByTitle){
        If ($Update.Title -ilike $Title){Return $True}
    }

    #Exclusions by product.
    ForEach ($Product In $ExcludeByProduct){
        If (($Update.ProductTitles -ilike $Product) -or ($Update.ProductFamilyTitles -ilike $Product)){Return $True}
    }

    #Inclusions by product.  The product must be found.
    ForEach ($Product In $IncludeByProduct){
        If (($Update.ProductTitles -inotlike $Product) -and ($Update.ProductFamilyTitles -inotlike $Product)){Return $True}
    }

    Return $False
}
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath

    [reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration") | out-null
    #$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($UpdateServer, $UseSSL, $Port);
	$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer();
   $ActiveUpdates1= $wsus.GetUpdates()
   $ActiveUpdates=$ActiveUpdates1 | Where-Object {$_.IsDeclined -eq $False}


    $DeclineUpdates = @{}
    $WindowsX86Updates = ($ActiveUpdates | Where{($_.Title -notlike '*.NET*') -and ($_.Title -ilike '*x86*') -and ($_.ProductTitles -ilike '*Windows*') -and (!$_.ProductTitles.Contains('Windows Server 2008'))})
    #WINDOWS7CLIENT-KB982799-X86-308159-23798
    #WINDOWS7EMBEDDED-KB2124261-X86-325274-25932
    #KB4099989-Windows10Rs3Client-RTM-ServicingStackUpdate-X86-TSL-World
    #KB947821-Win7-SP1-X86-TSL
    #WINDOWS6-1-KB975891-X86-294176

    #Loop through the updates and decline any that match the version.
    ForEach ($Update in $WindowsX86Updates) {
     "$($Update.Title) $($Update.Id.UpdateId) Windows X86 (32-bit)" | Out-File "$dir\Decline-Winx86-Minus2008-$(get-date -format dd-MM-yyyy-HHmmss).csv" -Append
     #   $DeclineUpdates.Set_Item($Update.Id.UpdateId,"Windows X86 (32-bit)")
    }
    Return $DeclineUpdates
