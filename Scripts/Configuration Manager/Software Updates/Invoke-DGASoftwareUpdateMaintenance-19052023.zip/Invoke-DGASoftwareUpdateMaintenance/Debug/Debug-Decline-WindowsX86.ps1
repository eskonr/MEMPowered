<#
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
#>
Function Test-Exclusions {
##########################################################################################################
<#
.SYNOPSIS
   Determine if the update should be excluded or not.

.DESCRIPTION
   Compare the update metadata against the exclusion filters and return true if the update should be
   excluded and return false if not.

#>
##########################################################################################################
    Param(
        [Microsoft.UpdateServices.Administration.IUpdate] $Update
    )

    #Exclusions by title.
    ForEach ($Title In $ExcludeByTitle){
        If ($Update.Title -ilike $Title){Return $True}
    }

    #Exclusions by product.
    ForEach ($Product In $ExcludeByProduct){
        If (($Update.ProductTitles -ilike $Product) -or ($Update.ProductFamilyTitles -ilike $Product)){Return $True}
    }

    #Inclusions by product.  The product must be found.
    ForEach ($Product In $IncludeByProduct){
        If (($Update.ProductTitles -inotlike $Product) -and ($Update.ProductFamilyTitles -inotlike $Product)){Return $True}
    }

    Return $False
}
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath

    [reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration") | out-null
    #$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($UpdateServer, $UseSSL, $Port);
	$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer();
   $ActiveUpdates1= $wsus.GetUpdates()
   $ActiveUpdates=$ActiveUpdates1 | Where-Object {$_.IsDeclined -eq $False}

$SupportedWinX86Versions = @('Windows Server 2003, Datacenter Edition', 'Windows Server 2003', 'Windows Server 2008', 'Windows XP', 'Windows 7')
#KnownWinX86Versions = @('Windows Server 2003, Datacenter Edition','Windows Server 2003','Windows Server 2008','Windows XP','Windows 7','Windows 8','Windows 8.1','Windows 10')


	[CmdletBinding()]
	$DeclineUpdates = @{}
	$WindowsX86Updates = ($ActiveUpdates | Where {($_.LegacyName -notlike '*DOTNET*-X86-TSL') -and ($_.LegacyName -like 'WSUS*_x86' -or $_.LegacyName -like '*WINDOWS*-KB*-X86-*' -or $_.LegacyName -like 'KB*-*-X86-TSL')})
	#WINDOWS7CLIENT-KB982799-X86-308159-23798
	#WINDOWS7EMBEDDED-KB2124261-X86-325274-25932
	#KB4099989-Windows10Rs3Client-RTM-ServicingStackUpdate-X86-TSL-World
	#KB947821-Win7-SP1-X86-TSL
	#WINDOWS6-1-KB975891-X86-294176
	
	#Loop through the updates and decline any that match the version.
	ForEach ($update in $WindowsX86Updates) {
		If (($update.ProductTitles | Select-String -pattern $SupportedWinX86Versions -SimpleMatch -List).Count -eq 0) {
 "$($Update.Title) $($Update.Id.UpdateId) Unsupported OS: $($update.ProductTitles)" | Out-File "$dir\Decline-Winx86-$(get-date -format dd-MM-yyyy-HHmmss).csv" -Append			
#$DeclineUpdates.Set_Item($Update.Id.UpdateId, "Unsupported OS: $($update.ProductTitles) (32-bit)")
		}
	}
	Write-Debug -Message 'Explore $Updates, $DeclineUpdates, $WindowsX86Updates and $SupportedWinX86Versions'
	Return $DeclineUpdates
