Function Test-Exclusions {
##########################################################################################################
<#
.SYNOPSIS
   Determine if the update should be excluded or not.

.DESCRIPTION
   Compare the update metadata against the exclusion filters and return true if the update should be
   excluded and return false if not.

#>
##########################################################################################################
    Param(
        [Microsoft.UpdateServices.Administration.IUpdate] $Update
    )

    #Exclusions by title.
    ForEach ($Title In $ExcludeByTitle){
        If ($Update.Title -ilike $Title){Return $True}
    }

    #Exclusions by product.
    ForEach ($Product In $ExcludeByProduct){
        If (($Update.ProductTitles -ilike $Product) -or ($Update.ProductFamilyTitles -ilike $Product)){Return $True}
    }

    #Inclusions by product.  The product must be found.
    ForEach ($Product In $IncludeByProduct){
        If (($Update.ProductTitles -inotlike $Product) -and ($Update.ProductFamilyTitles -inotlike $Product)){Return $True}
    }

    Return $False
}
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath

    [reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration") | out-null
    #$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($UpdateServer, $UseSSL, $Port);
	$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer();
   $ActiveUpdates1= $wsus.GetUpdates()
   $ActiveUpdates=$ActiveUpdates1 | Where-Object {$_.IsDeclined -eq $False}



#Un-comment and add elements to this array for editions you support.  Be sure to add a comma at the end in order to avoid confusion between editions.
$SupportedEditions = @("Feature update to Windows 10 Enterprise,","Feature update to Windows 10 \(business editions\),")

#If Microsoft decides to change their naming scheme you will need to udpate this variable to support the new scheme.  Note that commas are used to prevent mismatches.
$KnownEditions=@("Feature update to Windows 10 Pro,","Feature update to Windows 10 Pro N,","Feature update to Windows 10 Enterprise,","Feature update to Windows 10 Enterprise N,", "Feature update to Windows 10 Education,","Feature update to Windows 10 Education N,","Feature update to Windows 10 Team,","Feature update to Windows 10 \(business editions\),", "Feature update to Windows 10 \(consumer editions\),")
    
    $DeclineUpdates = @{}
    If (!$SupportedEditions){Return $DeclineUpdates}    


    $Windows10Updates = $ActiveUpdates | Where{$_.ProductTitles.Contains('Windows 10') -or $_.ProductTitles.Contains('Windows 10, version 1903 and later') -or $_.ProductTitles.Contains('Windows Insider Pre-Release')}
    
    #Loop through the updates and decline any that match the version.
    ForEach ($Update in $Windows10Updates){

        #Verify that the title matches one of the known edition.  If not then skip the update.
        $EditionFound=$False
        ForEach ($Edition in $KnownEditions){
            If ($Update.Title -match $Edition){$EditionFound=$True}
        }
        If(!$EditionFound){Continue} #Skip to the next update.

        #Verify that the title does not match any of the editions the user supports.
        $EditionFound=$False
        ForEach ($Edition in $SupportedEditions){
            If ($Update.Title -match $Edition){$EditionFound=$True}
        }
        
        #If one of the supported editions was found then skip to the next update.
        If($EditionFound -or (Test-Exclusions $Update)){
            Continue #Skip to the next update.
        } Else {
        "$($Update.Title) $($Update.Id.UpdateId) Windows 10 Edition" | Out-File "$dir\Decline-Win10Editions-$(get-date -format dd-MM-yyyy-HHmmss).csv" -Append
       # write-host "$($Update.Title) $($Update.Id.UpdateId) Windows 10 Edition" #| Out-File "$dir\declineWin10Editions.csv" -Append
           # $DeclineUpdates.Set_Item($Update.Id.UpdateId,"Windows 10 Edition")
        }        
    }
    Return $DeclineUpdates

