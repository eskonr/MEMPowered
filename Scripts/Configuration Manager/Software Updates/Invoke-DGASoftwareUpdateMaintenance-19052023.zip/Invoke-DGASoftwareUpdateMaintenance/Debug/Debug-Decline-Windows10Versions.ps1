﻿Function Test-Exclusions {
##########################################################################################################
<#
.SYNOPSIS
   Determine if the update should be excluded or not.

.DESCRIPTION
   Compare the update metadata against the exclusion filters and return true if the update should be
   excluded and return false if not.

#>
##########################################################################################################
    Param(
        [Microsoft.UpdateServices.Administration.IUpdate] $Update
    )

    #Exclusions by title.
    ForEach ($Title In $ExcludeByTitle){
        If ($Update.Title -ilike $Title){Return $True}
    }

    #Exclusions by product.
    ForEach ($Product In $ExcludeByProduct){
        If (($Update.ProductTitles -ilike $Product) -or ($Update.ProductFamilyTitles -ilike $Product)){Return $True}
    }

    #Inclusions by product.  The product must be found.
    ForEach ($Product In $IncludeByProduct){
        If (($Update.ProductTitles -inotlike $Product) -and ($Update.ProductFamilyTitles -inotlike $Product)){Return $True}
    }

    Return $False
}
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$date=(get-date -format dd-MM-yyyy-HHmmss)

    [reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration") | out-null
    #$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($UpdateServer, $UseSSL, $Port);
	$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer();
   $ActiveUpdates1= $wsus.GetUpdates()
   $ActiveUpdates=$ActiveUpdates1 | Where-Object {$_.IsDeclined -eq $False}

#Un-comment and add elements to this array for versions you no longer support.
$UnsupportedVersions = @("1507", "1511", "1607", "1703", "1709", "1803", "1809", "1903", "1909", "2004")
    $DeclineUpdates = @{}
    If (!$UnsupportedVersions){Return $DeclineUpdates}

    $Windows10Updates = $ActiveUpdates | Where {$_.ProductTitles.Contains('Windows 10') -or $_.ProductTitles.Contains('Windows 10, version 1903 and later') -or $_.ProductTitles.Contains('Windows Insider Pre-Release')  -or ($_.Title -ilike "Windows 7 and 8.1 upgrade to Windows 10*") -or $_.ProductTitles.Contains('Windows 10 Language Interface Packs')}

    #Loop through the updates and decline any that match the version.
    ForEach ($Update in $Windows10Updates){

        #If the title contains a version number.
        If ($Update.Title -match "Version \d\d\d\d" -and (! (Test-Exclusions $Update))){

            #Capture the version number.
            $Version = $matches[0].Substring($matches[0].Length - 4)

            #If the version number is in the list then decline it.
            If ($UnsupportedVersions.Contains($Version)){
            "$($Update.Title) $($Update.Id.UpdateId) Windows 10 Version:$($Version)" | Out-File "$dir\Decline-Win10versions-$($date).csv" -Append
            #    $DeclineUpdates.Set_Item($Update.Id.UpdateId,"Windows 10 Version: $($Version)")
            }
        }
    }
    Return $DeclineUpdates
