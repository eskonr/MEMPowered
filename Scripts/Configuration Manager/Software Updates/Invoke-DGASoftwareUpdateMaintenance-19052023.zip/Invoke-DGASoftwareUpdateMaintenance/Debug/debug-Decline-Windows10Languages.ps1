﻿
Function Test-Exclusions {
##########################################################################################################
<#
.SYNOPSIS
   Determine if the update should be excluded or not.

.DESCRIPTION
   Compare the update metadata against the exclusion filters and return true if the update should be
   excluded and return false if not.

#>
##########################################################################################################
    Param(
        [Microsoft.UpdateServices.Administration.IUpdate] $Update
    )

    #Exclusions by title.
    ForEach ($Title In $ExcludeByTitle){
        If ($Update.Title -ilike $Title){Return $True}
    }

    #Exclusions by product.
    ForEach ($Product In $ExcludeByProduct){
        If (($Update.ProductTitles -ilike $Product) -or ($Update.ProductFamilyTitles -ilike $Product)){Return $True}
    }

    #Inclusions by product.  The product must be found.
    ForEach ($Product In $IncludeByProduct){
        If (($Update.ProductTitles -inotlike $Product) -and ($Update.ProductFamilyTitles -inotlike $Product)){Return $True}
    }

    Return $False
}
$scriptPath = $script:MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath

    [reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration") | out-null
    #$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($UpdateServer, $UseSSL, $Port);
	$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer();
   $ActiveUpdates1= $wsus.GetUpdates()
   $ActiveUpdates=$ActiveUpdates1 | Where-Object {$_.IsDeclined -eq $False}

        $DeclineUpdates = @{}
    
    #Determine how to create the supported update language array.
            $SupportedUpdateLanguages=@("en","all","zh""zh-hk","zh-tw","ja","ja-jp","en-us","fr","fr-fr")
       

    #Get the Windows 10 updates.
    $Windows10Updates = $ActiveUpdates | Where{($_.ProductTitles.Contains('Windows 10')) -or $_.ProductTitles.Contains('Windows 10, version 1903 and later') -or $_.ProductTitles.Contains('Windows Insider Pre-Release') -or ($_.Title -ilike "Windows 7 and 8.1 upgrade to Windows 10*")}
    
    #Loop through the updates and decline any that don't support the defined languages.
    ForEach ($Update in $Windows10Updates){
        
        #Loop through the updates's languages and determine if one of the defined languages is found.
        $LanguageFound = $False
        ForEach ($Language in $Update.GetSupportedUpdateLanguages()){
            If ($SupportedUpdateLanguages.Contains($Language)) {$LanguageFound=$True }
        }

        #If none of the defined languages were found then decline the update.
        If (! $LanguageFound -and (! (Test-Exclusions $Update))){ 
      "$($Update.Title) $($Update.Id.UpdateId) with Windows 10 Language:$($Update.GetSupportedUpdateLanguages())" | Out-File "$dir\Decline-Win10languages-$(get-date -format dd-MM-yyyy-HHmmss).csv" -Append
          #  $DeclineUpdates.Set_Item($Update.Id.UpdateId,"Windows 10 Language: $($Update.GetSupportedUpdateLanguages())")
        }
    }
    Return $DeclineUpdates