﻿

$CDGuid=(Get-AzureADUser | where {$_.Surname -eq "Dewar"}).ObjectID

$BostonITStaffIDs = (Get-AzureADUser | where {$_.department -eq "IT" -and $_.city -eq "Boston" -and $_.JobTitle -eq "ITPro"}).ObjectID

Foreach ($ID in $BostonITStaffIDs) {
 Set-AzureADUserManager -ObjectId $ID -RefObjectId $CDGuid
 }

