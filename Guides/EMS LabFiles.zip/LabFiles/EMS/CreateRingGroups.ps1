﻿$msolcred=Get-Credential
Connect-AzureAD -Credential $msolcred

#Create groups

New-AzureADGroup -DisplayName "Update Ring 1 Users" -MailEnabled $false -SecurityEnabled $true -MailNickName "URing1Users"
New-AzureADGroup -DisplayName "Update Ring 2 Users" -MailEnabled $false -SecurityEnabled $true -MailNickName "URing2Users"
New-AzureADGroup -DisplayName "Update Ring 5 Users" -MailEnabled $false -SecurityEnabled $true -MailNickName "URing5Users"