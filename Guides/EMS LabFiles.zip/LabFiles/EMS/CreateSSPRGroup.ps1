﻿$msolcred=Get-Credential

Connect-AzureAD -Credential $msolcred

New-AzureADGroup -DisplayName "SSPR Users" -MailEnabled $false -SecurityEnabled $true -MailNickName "SSPRUsers"

$SSPRUsersGroupGUID = (Get-AzureADGroup -Filter "DisplayName eq 'SSPR Users'").ObjectId

$SSPRUserIDs=(Get-AzureADUser | where {$_.department -eq "Sales"}).ObjectID

Foreach ($ID in $SSPRUserIDs) {
 Add-AzureADGroupMember -ObjectId $SSPRUsersGroupGUID -RefObjectId $ID
 }

 $MobileUsersGUID = (Get-AzureADGroup -Filter "DisplayName eq 'Mobile Users'").ObjectId

 Foreach ($ID in $SSPRUserIDs) {
 Add-AzureADGroupMember -ObjectId $MobileUsersGUID -RefObjectId $ID
 }