﻿	$folder='C:\ProgramData\Microsoft\Windows\Start Menu\Programs'
		#Create Start Menu folder Structure
		$Destination = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs"
	    $Source = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Workforce 2.0\Microsoft Office 2016"
		If(!(test-path $Destination)) {
      		New-Item -ItemType Directory -Force -Path $Destination
		}
      	Copy-Item "$source\Access.lnk" "$Destination\Access.lnk" -force -ErrorAction SilentlyContinue
      	Copy-Item "$source\Excel.lnk" "$Destination\Excel.lnk" -force -ErrorAction SilentlyContinue
      	Copy-Item "$source\OneNote.lnk" "$Destination\OneNote 2016.lnk" -force -ErrorAction SilentlyContinue
		Copy-Item "$source\Outlook.lnk" "$Destination\Outlook.lnk" -force -ErrorAction SilentlyContinue
      	Copy-Item "$source\PowerPoint.lnk" "$Destination\PowerPoint.lnk" -force -ErrorAction SilentlyContinue
      	Copy-Item "$source\Publisher.lnk" "$Destination\Publisher.lnk" -force -ErrorAction SilentlyContinue
      	Copy-Item "$source\Word.lnk" "$Destination\Word.lnk" -force -ErrorAction SilentlyContinue
      
        	