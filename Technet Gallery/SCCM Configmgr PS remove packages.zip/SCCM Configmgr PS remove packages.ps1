#######################################################################
#Name: Remove multiple packages ,applications,drivers,Images etc from Configmgr 2012
#Author: Eswar Koneti
#Date Created:22-July-2014
#Avilable At:www.eskonr.com

#######################################################################

#Import Module
$CMModulepath=$Env:SMS_ADMIN_UI_PATH.ToString().Substring(0,$Env:SMS_ADMIN_UI_PATH.Length -  5)+"\ConfigurationManager.psd1"
import-module $CMModulepath -force
#Change the site Code 
CD PRI:
#Change output File Location to store the results
$Outputpath='C:\Users\eswar\Desktop\Removed-packages.txt'
#Change the input filename ,make sure you supply the information in correct format

Import-Csv C:\Users\eswar\Desktop\Remove-packages.csv |`
    ForEach-Object {
        $PackageType = $_.PackageType
        $PackageName = $_.PackageName
        			
# For Packages

            If($PackageType -eq "Package")
			   {
			#Check if the supplied package exist in CM12
            if ( Get-CMPackage -Name "$PackageName")
                     {
			Remove-CMPackage -Name  "$PackageName" -Force
            #Check if the supplied package deleted or not from CM12
            if (!( Get-CMPackage -Name "$PackageName"))
                        {
            "Package " +  $PackageName + " "+ "Deleted " | Out-File -FilePath $Outputpath -Append
                         }
            else
                         {
            "Package " +  $PackageName + " "+ "Not Deleted ,Fix the problem and delete manually " | Out-File -FilePath $Outputpath -Append
                         }
			          }
               }

#For Applications

			If($PackageType -eq "Application")
			    {
            #Check if the supplied Application exist in CM12
            if ( Get-CMApplication -Name "$PackageName")
                    {				
            Remove-CMApplication -Name  "$PackageName" -Force
            #Check if the supplied Application deleted or not from CM12
            if (!( Get-CMApplication -Name "$PackageName"))
                         {
            "Application " +  $PackageName + " "+ "Deleted " | Out-File -FilePath $Outputpath -Append                    
                         }
            else
                         {
            "Application " +  $PackageName + " "+ "not Deleted ,Fix the problem and delete Manually " | Out-File -FilePath $Outputpath -Append                    
                         }
                      }


                }

#For Driver Packages
			
			If($PackageType -eq "Driver")
			{
			 #Check if the supplied Driver Package exist in CM12
            if ( Get-CMDriverPackage -Name "$PackageName")
                    {				
			Remove-CMDriverPackage -Name  "$PackageName" -Force
            #Check if the supplied Driver Package deleted or not from CM12
            if (!( Get-CMDriverPackage -Name "$PackageName"))
                       {
            "Driver " +  $PackageName + " "+ "Deleted " | Out-File -FilePath $Outputpath -Append
                       }
            else
                       {
            "Driver " +  $PackageName + " "+ "not Deleted ,Fix the problem and delete Manually " | Out-File -FilePath $Outputpath -Append
                       }

			        }
            }

#For BootImages

			If($PackageType -eq "BootImage")
			{
			#Check if the supplied Boot Image exist in CM12
            if ( Get-CMBootImage -Name "$PackageName")
                    {				
			Remove-CMBootImage -Name  "$packagename" -Force
             #Check if the supplied Boot Image deleted or not from CM12
            if (!( Get-CMDriverPackage -Name "$PackageName"))
                        {
            "BootImage " +  $PackageName + " "+ "Deleted " | Out-File -FilePath $Outputpath -Append
                        }
            else
                        {
            "BootImage " +  $PackageName + " "+ "not Deleted ,Fix the problem and delete Manually " | Out-File -FilePath $Outputpath -Append
                        }
                     }
            }

            			
#For OSImage
			
            If($PackageType -eq "OSImage")
            {
            #Check if the supplied OS Image exist in CM12
            if ( Get-CMOperatingSystemImage -Name "$PackageName")
                    {				
		    Remove-CMOperatingSystemImage -Name "$packagename" -Force
            #Check if the supplied OS Image deleted or not from CM12
            if (!( Get-CMOperatingSystemImage -Name "$PackageName"))
                         {
            "OSImage " +  $PackageName + " "+ "Deleted " | Out-File -FilePath $Outputpath -Append
                         }
            else
                         { 
            "OSImage " +  $PackageName + " "+ "not Deleted ,Fix the problem and delete Manually " | Out-File -FilePath $Outputpath -Append
                          }

                   }
            }

            
#For SUPPackages
			
            If($PackageType -eq "SUP")
            {
            #Check if the supplied SUP Package exist in CM12
            if ( Get-CMSoftwareUpdateDeploymentPackage -Name "$PackageName")
                    {				
		    Remove-CMSoftwareUpdateDeploymentPackage -Name  "$packagename" -Force
            #Check if the supplied SUP Package exist in CM12
            if (!( Get-CMSoftwareUpdateDeploymentPackage -Name "$PackageName"))
                         {
            "SUP " +  $PackageName + " "+ "Deleted " | Out-File -FilePath $Outputpath -Append
                         }
            else
                        {
            "SUP  " +  $PackageName + " "+ "not Deleted ,Fix the problem and delete Manually " | Out-File -FilePath $Outputpath -Append
                        }
                    }
             }

			
}
