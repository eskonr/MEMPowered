﻿
 #############################################################################
# Author  : Eswar Koneti 
# Website : www.eskonr.com
# Twitter : @eskonr
# Created : 08/Sep/2017
# Purpose : This script will delete all the maintanance windows that are part of collection.Input the collection ID to text file and run the script.
#############################################################################

Try
{
  import-module (Join-Path $(Split-Path $env:SMS_ADMIN_UI_PATH) ConfigurationManager.psd1)
  $SiteCode=Get-PSDrive -PSProvider CMSITE
  cd ((Get-PSDrive -PSProvider CMSite).Name + ':')

}
Catch
{
  Write-Host "[ERROR]`t SCCM Module couldn't be loaded. Script will stop!"
  Exit 1
}

# Determine script location
$ScriptDir = Split-Path $script:MyInvocation.MyCommand.Path

ForEach ($Collection in Get-Content $ScriptDir"\CollectionIDs.txt")
{
   
   $MWs=(Get-CMMaintenanceWindow -CollectionID $Collection)
   foreach($MW in $MWs)
   {
   
        Remove-CMMaintenanceWindow -Name $MW.Name -CollectionId $Collection -Force
   }

}