﻿<#
Title:Assign Teams DID number to users
Use This script will read the information from CSV file and assign the numbers
Date:07-Nov-2019

#>
#Run this oneliner to save the password of the account into secure file that help to connect to skypeonlineconnector.
#Read-Host -Prompt "Enter your tenant password" -AsSecureString | ConvertFrom-SecureString | Out-File "D:\Sources\Scripts\PW.key"


$scriptpath = Split-Path $script:MyInvocation.MyCommand.Path
$date = (get-date -f dd-MM-yyyy-HHMMss)
$TenantUname = "account@eskonr.com"
#change the password key file that you saved.
$TenantPass = cat "D:\Sources\Scripts\PW.key" | ConvertTo-SecureString
$TenantCredentials = new-object -typename System.Management.Automation.PSCredential -argumentlist $TenantUname, $TenantPass
#make sure you install sfbo powershell module
Import-Module "C:\Program Files\Common Files\Skype for Business Online\Modules\SkypeOnlineConnector\SkypeOnlineConnector.psd1"
Import-Module SkypeOnlineConnector
#create new session .Change the office365 tenant info below,.
$session=New-CsOnlineSession -OverrideAdminDomain eswar.onmicrosoft.com -credential $tenantcredentials
Import-PSSession $session 
#output file name to save the results.
$Outfile = "Teams-DID-status-"+$date+".txt"
#input file to read the content from CSV file for email,number and Callingplan.
#The CSV files are placed in one folder each for each country for ex: Singapore,hongkong,vietnam,malaysia.
#Read the CSV file in singapore and run through the script ,assign numbers and send email to singapore team (the requesters email address is constant).
#Access to the CSV files are given only to specific people so that we can send email to only these people.
$Inputfiles=Get-ChildItem "\\sharefolder\Teams$\*.csv" -Recurse | select directory ,FullName
#Email address used to send email with output.
$from = "Engineering@eskonr.com"
$msg = @"

Hello Requestor,

Please refer to the attached file for teams number assignment status. 
Do read the attached file carefully as it may have failures for those users who 
a) do not have licenses; 
b) do not have any Email Address in AD (check in Active Directory) or 
c) the number you are trying to assign to them is already assigned to someone else. 

If there is an error in number assignment because the number is already assigned to someone else, please refer to the site to find out if the number is already assigned to someone else:
http://sccmreport/Reports/Pages/Report.aspx?ItemPath=%2fCustom+Reports%2fRT%2fO365%2fTeams+DID+Numbers

If you have any queries please reach out to Teams@eskonr.com.

Regards,
Engineering Team

"@
#checking if there is any error and clear it before the actual portion runs.

if ($error -ne $null)
{
$error.Clear()
}
else {}
#

foreach ($file in $Inputfiles)
{
    $dir=$File.Directory.FullName #Directory name is very importnant here because the directory name contains the name of the country.
    #for example ,if the folder name is singpapore then email send to singapore team.
    $vars=Import-CSV $file.fullname
    #Check if there are any output files and move them to backup folder for reference
    $Backup="$dir\Backup"
    if(!(Test-Path -Path $Backup )){New-Item -ItemType directory -Path $Backup}
    Move-Item $dir\*.txt $Backup -Force
 #check if the CSV file contain any entries of not.IF the CSV file is empty then skip and go to next CSV File.
 If (($vars | Measure-Object).count -ge 1)
 {
 
 
 foreach ($var in $vars)
{
#read the mail from CSV
 $Email=$var.Email 
 #read the number from CSV . Adding + sign to CSV is not easy unless you change the properties of the field . So we ask users to key in number (countrycode & number) ,we add + in the script.
 $DID="+"+$var.Number 
 #read the calling plan
 $CallingPlan=$Var.Plan
 
   #Check if the task is to assign number or remove number.
   #below syntax check if the DID supplied in CSV is number of not.
   #To remove the number for leaver ,number will be $null in CSV File.
   If ($var.Number -match "^\d+$")
 {
 
 #assign number based on the CSV file.
 Set-CsUser -Identity $Email -EnterpriseVoiceEnabled $true -HostedVoiceMail $true -OnPremLineURI tel:$DID 
 #chek the error details
   if ($error) {

         if ($error| select-string -Pattern 'failed to return unique result')
           {
           #I kepe the write-host here to debug incase something goes wrong.
            Write-Host "Teams number $DID already taken by someone,please supply unique value"
            "Teams number $DID already taken by someone,please supply unique value"| Out-File $dir"\"$Outfile -append
          }

         elseif ($error| select-string -Pattern 'Management object not found for')
         {
         Write-Host "Email address not found for $email"
         "Email address not found for $Email to assign $DID"| Out-File $dir"\"$Outfile -append
      
         }
         elseif ($error| select-string -Pattern 'restricted for the user service plan')
         {
         Write-Host "User $EMail do not have teams voice licence assigned"
         "User $EMail do not have teams Voice licence to assign $DID"| Out-File $dir"\"$Outfile -append
     
         }
         else
         {
         Write-Host "cannot assign $DID number to $Email,contact teams admin"
         "cannot assign $DID number to $Email,contact teams admin"| Out-File $dir"\"$Outfile -append
         
         }
      }
   #if no error
    else
    {
    #assign the routing policy
  Grant-CsOnlineVoiceRoutingPolicy -Identity $Email -PolicyName $CallingPlan
   Write-Host "Teams number $DID assigned to $Email"
    "Teams number $DID assigned to $Email" | Out-File $dir"\"$Outfile -append
  }
  }
  #if the request is to remove the number
    else
    { write-host "Request is to move the number for $email"
    #set the number to null
     Set-CsUser -Identity $Email -EnterpriseVoiceEnabled $true -HostedVoiceMail $true -OnPremLineURI $null
        "Teams number removed for $Email" | Out-File $dir"\"$Outfile -append
    }
    }
   #check if there is any error and clear the error 
if ($error -ne $null)
{
$error.Clear()
}
else {}

} 
#now take the output file and send email.
#To send email, we look for folder name ,if singapore then send email to singapore team ,if vietnam ,email goes to vietnam team.
if ($dir -like '*Vietnam*' -and (Get-ChildItem "$dir\*.txt"))
{
Send-MailMessage -From $from -Subject "Vietnam Teams Number assignment status" -To "vietnamUser1@eskonr.com" -Cc "TeamsAdmin@eskonr.com", "Teamsadmin2@eskonr.com" -SmtpServer "mail.eskonr.com" -Port "25" -Attachments $dir"\"$Outfile -Body $msg
}
elseif ($dir -like '*Malaysia*' -and (Get-ChildItem "$dir\*.txt"))
{
Send-MailMessage -From $from -Subject "Malaysia Teams Number assignment status" -To "MalaysiaUser1@eskonr.com" -Cc "TeamsAdmin@eskonr.com", "Teamsadmin2@eskonr.com" -SmtpServer "mail.eskonr.com" -Port "25" -Attachments $dir"\"$Outfile -Body $msg
}
#repeat the task for each country that you want to send email
else {}
#once the email is sent ,clear the content of the CSV except the header row
(Get-Content $file.fullname| select -first 1) | Set-Content $file.fullname
}
#remove the pssession that was imported after the script executed .
get-pssession |Remove-PSSession

