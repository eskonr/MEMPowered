﻿import-module F:\sccm\AdminConsole\bin\ConfigurationManager.psd1 
$SiteCode = "ESK" 
$DPserver =GC "C:\script\srvlist.txt" 
foreach ($Server in $DPserver) 
{ 
    $PackageID = "ESK006A4" 
    $distpoints = Get-WmiObject -Namespace "root\SMS\Site_$($SiteCode)" -Query "Select * From SMS_DistributionPoint WHERE PackageID='$PackageID' and serverNALPath like '%$Server%'" 
       foreach ($dp in $distpoints) 
                {  
            $dp.RefreshNow = $true  
           $dp.Put() 
          "Pkg:" + $PackageID + " "+ "Refreshed On" + " "+ "Server:" +$server | Out-File -FilePath C:C:\Script\refresh-results.txt -Append     
              } 
}