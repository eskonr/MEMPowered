import-module F:\sccm\AdminConsole\bin\ConfigurationManager.psd1
#Change the site Code 
$SiteCode = "P01"
#Change File Location 
Import-Csv C:\Users\eswar\Desktop\add-packages.csv |` 
    ForEach-Object { 
        $PackageType = $_.PackageType 
        $PackageName = $_.PackageName 
        $ServerName = $_.ServerName 
        
            
            #For packages 
            If($PackageType -eq "Package") 
            { 
                #echo "This is a Package" 
                start-CMContentDistribution -PackageName  "$PackageName" -DistributionPointName "$ServerName" 
            } 
                
            #For applications 
            If($PackageType -eq "Application") 
            { 
                #echo "This is an Application" 
                start-CMContentDistribution -ApplicationName  "$PackageName" -DistributionPointName "$ServerName" 
            } 
            
            #For Driverpackages 
            If($PackageType -eq "Driver") 
            { 
                #echo "This is a Driver" 
                Start-CMContentDistribution -DriverPackageName  "$PackageName" -DistributionPointName "$ServerName" 
            } 
           
            #For BootImages 
            If($PackageType -eq "BootImage") 
            { 
                #echo "This is a BootImage" 
                Start-CMContentDistribution -BootImageName  "$packagename" -DistributionPointName "$server"
            } 
            
            #For OSImage 
            If($PackageType -eq "OSImage") 
            { 
                #echo "This is a OSimage" 
                Start-CMContentDistribution �OperatingSystemImageName  "$packagename" -DistributionPointName "$server" 
             }
            }