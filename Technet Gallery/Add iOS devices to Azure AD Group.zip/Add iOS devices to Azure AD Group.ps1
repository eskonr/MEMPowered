﻿<#
Title:Add Intune enrolled iOS devices with OS version < 12.4.1 into Azure AD group.
Author:Eswar Koneti
Date:15-Sep-2019
#>
$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
$date = (get-date -f dd-MM-yyyy-hhmmss)
$Outfile = "$dir\DeviceList-"+$date+".csv"
#connect to AzureAD module
Connect-AzureAD #-Credential $TenantCredentials
#If you have Azure AD group ,please key in the group ID else create AAD group with membership type assigned.
$AADGroupID="KeyinAzureADGroup ID here"
#DeviceOSType -eq "IPhone" is only for intune enrolled devices .for MAM registered devices ,DeviceOSType will be iOS.
$devices=Get-AzureADDevice -All $true | where-Object {$_.DeviceOSType -eq "IPhone" -and $_.DeviceOSVersion -lt "12.4.1"}
# Explore Device Object
$devices | Get-Member
# Get the count of devices
$devices.count
# Create a custom Device object and start getting some details
$DeviceInfo = @()
ForEach ($aadDevice in $devices)
 {
  $device = New-Object -TypeName PSObject
  $device | Add-Member -Type NoteProperty -Name ObjectId -Value $aadDevice.ObjectId
  $device | Add-Member -Type NoteProperty -Name DeviceOSType -Value $aadDevice.DeviceOSType
  $device | Add-Member -Type NoteProperty -Name DeviceOSVersion -Value $aadDevice.DeviceOSVersion
  $device | Add-Member -Type NoteProperty -Name DisplayName -Value $aadDevice.DisplayName
  $device | Add-Member -Type NoteProperty -Name IsCompliant -Value $aadDevice.IsCompliant
  $device | Add-Member -Type NoteProperty -Name IsManaged -Value $aadDevice.IsManaged
  If ($aadDevice.ApproximateLastLogonTimeStamp) {$device | Add-Member -Type NoteProperty -Name ApproximateLastLogonTimeStamp -Value ([datetime]$aadDevice.ApproximateLastLogonTimeStamp) }
  $deviceOwner = Get-AzureADDeviceRegisteredOwner -ObjectId $aadDevice.ObjectId
  If ($deviceOwner) {$device | Add-Member -Type NoteProperty -Name OwnerUserPrincipalName -Value $deviceOwner.UserPrincipalName}
  $deviceUser = Get-AzureADDeviceRegisteredUser -ObjectId $aadDevice.ObjectId
  If ($deviceUser) {$device | Add-Member -Type NoteProperty -Name RegisteredUserUserPrincipalName -Value $deviceUser.UserPrincipalName}
  $DeviceInfo += $device
}
# Export to CSV file
$DeviceInfo | Select ObjectId,DeviceOSType,DeviceOSVersion,DisplayName,IsCompliant,IsManaged,ApproximateLastLogonTimeStamp,OwnerUserPrincipalName,RegisteredUserUserPrincipalName | Export-Csv $Outfile -Encoding UTF8 -NoTypeInformation -Delimiter ";"
#Add devices to Azure AD Group
if ($Devices)
{ 
      foreach ($device in $devices)
      {
      Add-AzureADGroupMember -ObjectId $AADGroupID -RefObjectId $device.ObjectId
      }
} 