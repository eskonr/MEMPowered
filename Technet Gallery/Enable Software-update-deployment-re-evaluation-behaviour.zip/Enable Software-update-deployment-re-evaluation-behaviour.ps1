﻿#############################################################################
# Author  : Eswar Koneti 
# Website : www.eskonr.com
# Twitter : @eskonr
# Created : 02/March/2017
# Purpose : This script enable the software update deployment re-evalution behaviour upon restart option which is valid only for Configmgr 1606 and above
#
#############################################################################

# Determine script location and create log file to store the results
$ScriptDir = Split-Path $script:MyInvocation.MyCommand.Path
$log      = "$ScriptDir\RequirePostRebootFullScan.log"
$date     = Get-Date -Format "dd-MM-yyyy hh:mm:ss"

$date     = Get-Date -Format "dd-MM-yyyy hh:mm:ss"
"------------------------------- Script Started on $date ------------------------------------------" + "`r`n" | Out-File $log -append

Try
{
  import-module (Join-Path $(Split-Path $env:SMS_ADMIN_UI_PATH) ConfigurationManager.psd1)
  cd ((Get-PSDrive -PSProvider CMSite).Name + ':')
  $SiteCode = Get-PSDrive -PSProvider CMSITE
}
Catch
{
  Write-Host "[ERROR]`t SCCM Module couldn't be loaded. Script will stop!"
  Exit 1
}
#Get list of all software update deployments
$Deployments= Get-WmiObject -Namespace root\sms\site_$SiteCode -Class 'SMS_UpdateGroupAssignment'
#Check each deployment if RequirePostRebootFullScan is set to false or not .
foreach( $deployment in $Deployments)
{
    if ($Deployment.RequirePostRebootFullScan -eq $false)
    {
      $Deployment.RequirePostRebootFullScan = $True
      $Deployment.Put()
      Write-Host "RequirePostRebootFullScan is enabled for : $($Deployment.assignmentname)"
                    "$date [INFO]`t RequirePostRebootFullScan is enabled for : $($Deployment.assignmentname)" | Out-File $log -append
    }
 else
    {
    Write-Host "No deployments available to check RequirePostRebootFullScan"
                    "$date [INFO]`t No deployments available to enable RequirePostRebootFullScan" | Out-File $log -append
    }
"--------------------------------- Script finished on $date ------------------------------------------" + "`r`n" | Out-File $log -append
 
}
