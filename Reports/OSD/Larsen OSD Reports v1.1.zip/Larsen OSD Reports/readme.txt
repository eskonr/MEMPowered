Command:

& '.\Upload Reports v3.ps1' -webServiceUrl http://your-report-server 

this will upload the reports to a folder called "Larsen Reports" on your report server.
this can be changed by adding the -reportFolder parameter