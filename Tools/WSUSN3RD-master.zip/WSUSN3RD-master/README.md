# WSUSN3RD
Dump of useful items for software updates, usually WSUS items. 

This is just stuff I occasionally use in my lab. Maybe I'll be shamed into uploading more stuff eventually. 
Feel free to edit. I typically go for the most straight forward and quickest method that solves whatever problem I had. 
A.K.A. I don't like to futz around with making stuff pretty or usable by everyone and their brother's uncle. ¯&#92;\_(ツ)_/¯
