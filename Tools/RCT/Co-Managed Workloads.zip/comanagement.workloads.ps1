﻿[CmdletBinding()]
param(
[parameter(Mandatory=$true)]
$SiteServer,
[parameter(Mandatory=$true)]
$RSRID
)

function Load-Form {
	$Form.Controls.Add($ResultsGrid)
    $Form.Add_Shown({Get-DeviceComplianceStatus})
	$Form.Add_Shown({$Form.Activate()})
	[void]$Form.ShowDialog()
}
# Get the Site Code
function Get-CMSiteCode {
    $CMSiteCode = Get-WmiObject -Namespace "root\SMS" -Class SMS_ProviderLocation -ComputerName $SiteServer | Select-Object -ExpandProperty SiteCode
    return $CMSiteCode
}

# Convert WMI Time
Function Get-NormalDateTime {
 	param(
    	$WMIDateTime
    )
	$NormalDateTime = [management.managementDateTimeConverter]::ToDateTime($WMIDateTime)
	return $NormalDateTime
}
# Get Device Update Compliance Status
function Get-DeviceComplianceStatus {
$Data=Get-WmiObject -computername $SiteServer -namespace root\SMS\site_$(Get-CMSiteCode) -Query "select co.name,sys.LastLogonUserName,cdr.ClientVersion,cdr.LastPolicyRequest,cdr.LastHardwareScan,
co.ComgmtPolicyPresent,co.HybridAADJoined,co.AADJoined,co.MDMWorkloads
From SMS_Client_ComanagementState co
inner join SMS_CombinedDeviceResources cdr on cdr.MachineID=co.ResourceID
inner join sms_r_system sys on sys.resourceid=co.resourceid
where co.resourceid='$RSRID'"
#$results = @()
foreach ($update in $data)
{
$name=$update.co.Name
$LastLogonUserName=$update.sys.LastLogonUserName
$LastPolicyRequest=Get-NormalDateTime $update.cdr.LastPolicyRequest
$LastHardwareScan=Get-NormalDateTime $update.cdr.LastHardwareScan
$HybridAADJoined= $update.co.HybridAADJoined
$AADJoined=$update.co.AADJoined
$ComgmtPolicyPresent=$update.co.ComgmtPolicyPresent
[int]$capability= $($update.co.MDMWorkloads)
        # Example array of capabilities
   # $capability = 12351

    # Create enumurator for workload flags // ConfigMgr 2111+
    [flags()] Enum workloads {
        CoMgmt_Enabled = 8193
        Compliance_Policies = 2
        Resource_Access_Policies = 4
        Device_Configuration = 8
        Windows_Update_Policies = 16
        Client_Apps = 64
        Office_Click2Run_Apps = 128
        Endpoint_Protection = 4128
    }

    # Create an array to capture all capabilities
    $allCapabilities = @()

    ForEach ($capNum in $capability) {

        # Evaluate capabilities 
        If ($capNum -eq 1) {
            $capResult = "CoMgmt_Disabled"
        }
        elseif ($capNum -eq 8193) {
            $capResult = "CoMgmt_Enabled_NoWorkloads"
        }
        elseif ($capNum -lt 8193) {
            $capResult = "Invalid_Workload_Value"
        }
        else {
            Try {
                $workload = [workloads]$capNum

                # Build data if a valid flag is matched
                If ($workload -like "*_*") {

                    # Filter out CoMgmt_Enabled value - we assume it is enabled if we have a workload match
                    $capabilities = $workload -split ', ' -notmatch 'CoMgmt_Enabled'

                    # Tidy up and export capabilities sorted to a comma-separated string
                    $capResult = $capabilities -join ', '
                }
            }
            Catch {
                # Do Nothing, ignore invalid values
            }
        }

        # Add the result to the array
        $allCapabilities += $capResult
    }

    # Display the output as comma-separated values
   $load=$allCapabilities -join ','
   
write-host "$load"
$RowIndex = $ResultsGrid.Rows.Add($name,$LastLogonUserName,$LastPolicyRequest,$HybridAADJoined,$AADJoined,$ComgmtPolicyPresent,$load)
		If($load -eq "Invalid_Workload_Value")
		 {
		   $ResultsGrid.Rows.Item($RowIndex).DefaultCellStyle.BackColor = "Red"
		 }
		}
}

# Assemblies
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

# Form
$Form = New-Object System.Windows.Forms.Form    
$Form.Size = New-Object System.Drawing.Size(1400,200)  
$Form.MinimumSize = New-Object System.Drawing.Size(1400,200)
$Form.MaximumSize = New-Object System.Drawing.Size (1400,200)
$Form.SizeGripStyle = "Hide"
$Form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($PSHome + "\powershell.exe")
$Form.Text = "Co-Mgmt Workloads (www.eskonr.com)"
$Form.ControlBox = $true
$Form.TopMost = $true
$Form.AutoSizeMode = "GrowAndShrink"
$Form.StartPosition = "CenterScreen"

# DataGriView
$ResultsGrid = New-Object System.Windows.Forms.DataGridView
$ResultsGrid.Location = New-Object System.Drawing.Size(20,30)
$ResultsGrid.Size = New-Object System.Drawing.Size(1350,170)
$ResultsGrid.ColumnCount = 7
$ResultsGrid.ColumnHeadersVisible = $true
$ResultsGrid.Columns[0].Name = "Name"
$ResultsGrid.Columns[0].AutoSizeMode = "Fill"
$ResultsGrid.Columns[1].Name = "UserName"
$ResultsGrid.Columns[1].AutoSizeMode = "Fill"
$ResultsGrid.Columns[2].Name = "LastPolicyRequest"
$ResultsGrid.Columns[2].AutoSizeMode = "Fill"
$ResultsGrid.Columns[3].Name = "HybridAADJoined"
$ResultsGrid.Columns[3].AutoSizeMode = "Fill"
$ResultsGrid.Columns[4].Name = "AADJoined"
$ResultsGrid.Columns[4].AutoSizeMode = "Fill"
$ResultsGrid.Columns[5].Name = "ComgmtPolicyPresent"
$ResultsGrid.Columns[5].AutoSizeMode = "Fill"
$ResultsGrid.Columns[6].Name = "Workloads"
$ResultsGrid.Columns[6].AutoSizeMode = "Fill"
$ResultsGrid.AllowUserToAddRows = $false
$ResultsGrid.AllowUserToDeleteRows = $false
$ResultsGrid.ReadOnly = $True
#$ResultsGrid.ColumnHeadersHeightSizeMode = "DisableResizing"
#$ResultsGrid.RowHeadersWidthSizeMode = "DisableResizing"

# Load form
Load-Form
