﻿[CmdletBinding()]
param(
[parameter(Mandatory=$true)]
$SiteServer,
[parameter(Mandatory=$true)]
$RSRID
)

function Load-Form {
	$Form.Controls.Add($ResultsGrid)
    $Form.Add_Shown({Get-DeviceComplianceStatus})
	$Form.Add_Shown({$Form.Activate()})
	[void]$Form.ShowDialog()
}
# Get the Site Code
function Get-CMSiteCode {
    $CMSiteCode = Get-WmiObject -Namespace "root\SMS" -Class SMS_ProviderLocation -ComputerName $SiteServer | Select-Object -ExpandProperty SiteCode
    return $CMSiteCode
}

# Convert WMI Time
Function Get-NormalDateTime {
 	param(
    	$WMIDateTime
    )
	$NormalDateTime = [management.managementDateTimeConverter]::ToDateTime($WMIDateTime)
	return $NormalDateTime
}
# Get Device Update Compliance Status
function Get-DeviceComplianceStatus {
$Data=Get-WmiObject -computername $SiteServer -namespace root\SMS\site_$(Get-CMSiteCode) -Query "select co.name,sys.LastLogonUserName,cdr.ClientVersion,cdr.LastPolicyRequest,cdr.LastHardwareScan,
co.ComgmtPolicyPresent,co.HybridAADJoined,co.AADJoined,co.MDMWorkloads
From SMS_Client_ComanagementState co
inner join SMS_CombinedDeviceResources cdr on cdr.MachineID=co.ResourceID
inner join sms_r_system sys on sys.resourceid=co.resourceid
where co.resourceid='$RSRID'"
#$results = @()
foreach ($update in $data)
{
$name=$update.co.Name
$LastLogonUserName=$update.sys.LastLogonUserName
$LastPolicyRequest=Get-NormalDateTime $update.cdr.LastPolicyRequest
$LastHardwareScan=Get-NormalDateTime $update.cdr.LastHardwareScan
$HybridAADJoined= $update.co.HybridAADJoined
$AADJoined=$update.co.AADJoined
$ComgmtPolicyPresent=$update.co.ComgmtPolicyPresent
$workload = switch ( $update.co.mdmworkloads )
{
 1 {'Co-Mgmt Enabled'}
3 {'Compliance policies'}
5 {'Resource access Policies'}
7 {'Resource access Policies,Compliance Policies'}
9 {'Device Configuration'}
11 {'Device Configuration,Compliance Policies'}
13 {'Device Configuration,Resource access Policies'}
15 {'Device Configuration,Resource access Policies,Compliance Policies'}
17 {'Windows Updates Policies'}
19 {'Windows Updates Policies,Compliance Policies'}
21 {'Windows Updates Policies,Resource access Policies'}
23 {'Windows Updates Policies,Resource access Policies,Compliance Policies'}
25 {'Device Configuration,Windows Updates Policies'}
27 {'Device Configuration,Windows Updates Policies,Compliance Policies'}
29 {'Device Configuration,Windows Updates Policies,Resource access Policies'}
31 {'Device Configuration,Windows Updates Policies,Resource access Policies,Compliance Policies'}
33 {'Endpoint Protection'}
35 {'Compliance Policies,Endpoint Protection'}
37 {'Resource access Policies,Endpoint Protection'}
39 {'Resource access Policies,Compliance Policies,Endpoint Protection'}
41 {'Device Configuration,Endpoint Protection'}
43 {'Device Configuration,Compliance Policies,Endpoint Protection'}
45 {'Device Configuration,Resource access Policies,Endpoint Protection'}
47 {'Device Configuration,Resource access Policies,Compliance Policies,Endpoint Protection'}
49 {'Windows Updates Policies,Endpoint Protection'}
51 {'Windows Updates Policies,Compliance Policies,Endpoint Protection'}
53 {'Windows Updates Policies,Resource access Policies,Endpoint Protection'}
55 {'Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
57 {'Device Configuration,Windows Updates Policies,Endpoint Protection'}
59 {'Device Configuration,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
61 {'Device Configuration,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
63 {'Device Configuration,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
65 {'Client Apps'}
67 {'Client Apps,Compliance Policies'}
69 {'Client Apps,Resource access Policies'}
71 {'Client Apps,Resource access Policies,Compliance Policies'}
73 {'Client Apps,Device Configuration'}
75 {'Client Apps,Device Configuration,Compliance Policies'}
77 {'Client Apps,Device Configuration,Resource access Policies'}
79 {'Client Apps,Device Configuration,Resource access Policies,Compliance Policies'}
81 {'Client Apps,Windows Updates Policies'}
83 {'Client Apps,Windows Updates Policies,Compliance Policies'}
85 {'Client Apps,Windows Updates Policies,Resource access Policies'}
87 {'Client Apps,Windows Updates Policies,Resource access Policies,Compliance Policies'}
89 {'Client Apps,Device Configuration,Windows Updates Policies'}
91 {'Client Apps,Device Configuration,Windows Updates Policies,Compliance Policies'}
93 {'Client Apps,Device Configuration,Windows Updates Policies,Resource access Policies'}
95 {'Client Apps,Device Configuration,Windows Updates Policies,Resource access Policies,Compliance Policies'}
97 {'Client Apps,Endpoint Protection'}
99 {'Client Apps,Compliance Policies,Endpoint Protection'}
101 {'Client Apps,Resource access Policies,Endpoint Protection'}
103 {'Client Apps,Resource access Policies,Compliance Policies,Endpoint Protection'}
105 {'Client Apps,Device Configuration,Endpoint Protection'}
107 {'Client Apps,Device Configuration,Compliance Policies,Endpoint Protection'}
109 {'Client Apps,Device Configuration,Resource access Policies,Endpoint Protection'}
111 {'Client Apps,Device Configuration,Resource access Policies,Compliance Policies,Endpoint Protection'}
113 {'Client Apps,Windows Updates Policies,Endpoint Protection'}
115 {'Client Apps,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
117 {'Client Apps,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
119 {'Client Apps,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
121 {'Client Apps,Device Configuration,Windows Updates Policies,Endpoint Protection'}
123 {'Client Apps,Device Configuration,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
125 {'Client Apps,Device Configuration,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
127 {'Client Apps,Device Configuration,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
129 {'Office Click-to-Run Apps'}
131 {'Office Click-to-Run Apps,Compliance Policies'}
133 {'Office Click-to-Run Apps,Resource access Policies'}
135 {'Office Click-to-Run Apps,Resource access Policies,Compliance Policies'}
137 {'Device Configuration,Office Click-to-Run Apps'}
139 {'Device Configuration,Office Click-to-Run Apps,Compliance Policies'}
141 {'Device Configuration,Office Click-to-Run Apps,Resource access Policies'}
143 {'Device Configuration,Office Click-to-Run Apps,Resource access Policies,Compliance Policies'}
145 {'Office Click-to-Run Apps,Windows Updates Policies'}
147 {'Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies'}
149 {'Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies'}
151 {'Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies'}
153 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies'}
155 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies'}
157 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies'}
159 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies'}
161 {'Office Click-to-Run Apps,Endpoint Protection'}
163 {'Office Click-to-Run Apps,Compliance Policies,Endpoint Protection'}
165 {'Office Click-to-Run Apps,Resource access Policies,Endpoint Protection'}
167 {'Office Click-to-Run Apps,Resource access Policies,Compliance Policies,Endpoint Protection'}
169 {'Device Configuration,Office Click-to-Run Apps,Endpoint Protection'}
171 {'Device Configuration,Office Click-to-Run Apps,Compliance Policies,Endpoint Protection'}
173 {'Device Configuration,Office Click-to-Run Apps,Resource access Policies,Endpoint Protection'}
175 {'Device Configuration,Office Click-to-Run Apps,Resource access Policies,Compliance Policies,Endpoint Protection'}
177 {'Office Click-to-Run Apps,Windows Updates Policies,Endpoint Protection'}
179 {'Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
181 {'Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
183 {'Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
185 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Endpoint Protection'}
187 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
189 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
191 {'Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
193 {'Client Apps,Office Click-to-Run Apps'}
195 {'Client Apps,Office Click-to-Run Apps,Compliance Policies'}
197 {'Client Apps,Office Click-to-Run Apps,Resource access Policies'}
199 {'Client Apps,Office Click-to-Run Apps,Resource access Policies,Compliance Policies'}
201 {'Client Apps,Device Configuration,Office Click-to-Run Apps'}
203 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Compliance Policies'}
205 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Resource access Policies'}
207 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Resource access Policies,Compliance Policies'}
209 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies'}
211 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies'}
213 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies'}
215 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies'}
217 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies'}
219 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies'}
221 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies'}
223 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies'}
225 {'Client Apps,Office Click-to-Run Apps,Endpoint Protection'}
227 {'Client Apps,Office Click-to-Run Apps,Compliance Policies,Endpoint Protection'}
229 {'Client Apps,Office Click-to-Run Apps,Resource access Policies,Endpoint Protection'}
231 {'Client Apps,Office Click-to-Run Apps,Resource access Policies,Compliance Policies,Endpoint Protection'}
233 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Endpoint Protection'}
235 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Compliance Policies,Endpoint Protection'}
237 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Resource access Policies,Endpoint Protection'}
239 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Resource access Policies,Compliance Policies,Endpoint Protection'}
241 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
243 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
245 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
247 {'Client Apps,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
249 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Endpoint Protection'}
251 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Compliance Policies,Endpoint Protection'}
253 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Endpoint Protection'}
255 {'Client Apps,Device Configuration,Office Click-to-Run Apps,Windows Updates Policies,Resource access Policies,Compliance Policies,Endpoint Protection'}
8193 {'Not Co-Managed'}
}
write-host $update.co.mdmworkloads
$RowIndex = $ResultsGrid.Rows.Add($name,$LastLogonUserName,$LastPolicyRequest,$HybridAADJoined,$AADJoined,$ComgmtPolicyPresent,$workload)
		If($workload -eq "Not Co-Managed")
		 {
		   $ResultsGrid.Rows.Item($RowIndex).DefaultCellStyle.BackColor = "Red"
		 }
		}
}

# Assemblies
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

# Form
$Form = New-Object System.Windows.Forms.Form    
$Form.Size = New-Object System.Drawing.Size(1400,200)  
$Form.MinimumSize = New-Object System.Drawing.Size(1400,200)
$Form.MaximumSize = New-Object System.Drawing.Size (1400,200)
$Form.SizeGripStyle = "Hide"
$Form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($PSHome + "\powershell.exe")
$Form.Text = "Co-Mgmt Workloads (www.eskonr.com)"
$Form.ControlBox = $true
$Form.TopMost = $true
$Form.AutoSizeMode = "GrowAndShrink"
$Form.StartPosition = "CenterScreen"

# DataGriView
$ResultsGrid = New-Object System.Windows.Forms.DataGridView
$ResultsGrid.Location = New-Object System.Drawing.Size(20,30)
$ResultsGrid.Size = New-Object System.Drawing.Size(1350,170)
$ResultsGrid.ColumnCount = 7
$ResultsGrid.ColumnHeadersVisible = $true
$ResultsGrid.Columns[0].Name = "Name"
$ResultsGrid.Columns[0].AutoSizeMode = "Fill"
$ResultsGrid.Columns[1].Name = "UserName"
$ResultsGrid.Columns[1].AutoSizeMode = "Fill"
$ResultsGrid.Columns[2].Name = "LastPolicyRequest"
$ResultsGrid.Columns[2].AutoSizeMode = "Fill"
$ResultsGrid.Columns[3].Name = "HybridAADJoined"
$ResultsGrid.Columns[3].AutoSizeMode = "Fill"
$ResultsGrid.Columns[4].Name = "AADJoined"
$ResultsGrid.Columns[4].AutoSizeMode = "Fill"
$ResultsGrid.Columns[5].Name = "ComgmtPolicyPresent"
$ResultsGrid.Columns[5].AutoSizeMode = "Fill"
$ResultsGrid.Columns[6].Name = "Workload"
$ResultsGrid.Columns[6].AutoSizeMode = "Fill"
$ResultsGrid.AllowUserToAddRows = $false
$ResultsGrid.AllowUserToDeleteRows = $false
$ResultsGrid.ReadOnly = $True
#$ResultsGrid.ColumnHeadersHeightSizeMode = "DisableResizing"
#$ResultsGrid.RowHeadersWidthSizeMode = "DisableResizing"

# Load form
Load-Form